# 分單助手（Chrome MV3 擴充）

獨立的蝦皮賣家訂單分類工具：連動雲端小幫手（USale，ec.mallbic.com）即時拉訂單，
依「商品/SKU、物流方式、圖示、儲位區（any/all/單區/跨區）、訂單金額」條件把新訂單分類，
供**揀貨與包裝分流**；分好的類別可一鍵移入 ERP 暫存區（本工具專屬的「訂單分類」群組）。

**原則：查詢/分類自動跑；「移入暫存區」等會改訂單狀態的動作，一律由使用者按確認才執行。**

## 與「蝦皮助手」的關係

- 本擴充是**獨立產品**，可與 `Shopee_Helper/`（蝦皮助手）**同時安裝、互不干擾**：
  - 訊息識別字串全部用 `ORDER_CLASSIFY` / `order-classify` 前綴（蝦皮助手用 `USALE_LOCAL`）。
  - chrome.storage 本來就是各擴充獨立，分類規則互不相通。
- **暫存區只讀不建**：對應暫存區直接用 ERP「**分單助手**」群組**現有**的選項（未分類、第0層_低價訂單…等），
  由使用者在 ERP 端自行維護。編輯頁只提供「↻ 同步暫存區」按鈕重新抓最新清單（有新增/刪除才提示變動），
  不提供工具內新增/刪除暫存區，避免誤刪。
- `bridge/page.js` 引擎完整沿用 `Shopee_Helper/dispatch/page.js`（HELPER_VERSION 40，實戰驗證版），
  只改守衛旗標與訊息型別。**改引擎行為時請兩邊同步維護。**

## 專案結構

```
manifest.json            # MV3：只需要 ec.mallbic.com 權限 + storage/tabs/scripting
background.js            # 點擴充圖示 → 開/聚焦分類主視窗（app/classify_list.html）
bridge/
  content.js             # isolated world 橋接（chrome 訊息 ↔ window.postMessage）
  page.js                # MAIN world 引擎（AjaxPro proxy 呼叫，繞過 WAF 403）
app/
  classify_list.html/.js # 主畫面：分類卡片清單（同步/查看/移入暫存區/拖曳排序）
  classify_edit.html/.js # 編輯分類（動態條件列、暫存區管理、排序方式）
  classify_common.js     # 共用：條件欄位 registry、儲存、跨視窗呼叫
  classify.css
icons/                   # 藍底白「分類」二字（與未取貨助手的綠底區隔）
```

## 使用流程

1. 先開啟並登入 `ec.mallbic.com` 的訂單頁（引擎注入在該分頁）。
2. 點擴充圖示開「分單助手」視窗。
3. 「＋ 新增分類」設定條件與對應暫存區 →「同步訂單」→ 各卡片顯示命中筆數。
4. 「查看」把該分類的訂單畫到 ERP 主畫面（可依儲位標籤/建立時間/物流排序，列印同順序）；
   「移入暫存區」需按確認，把該分類訂單搬進對應暫存區。

## 開發 / 載入

```text
1. chrome://extensions → 開發人員模式 → 載入未封裝項目 → 選本資料夾
2. 改 bridge/*.js 後：擴充「↻ 重新載入」+ 對 ERP 分頁按 F5（引擎是分頁載入時注入的快照）
3. 改 app/*、background.js 後：擴充「↻ 重新載入」即可
4. UI 有引擎版本握手（EXPECTED_HELPER_VERSION）：ERP 分頁跑舊引擎會直接提示 F5
```

無建置步驟、無相依套件（純原生 JS）。⚠️ 專案若放 OneDrive，注意同步延遲可能載到舊檔。

## 維護備忘（踩雷區）

- 一切 ERP 呼叫**必須走 MAIN world 的頁面 proxy**（`Mallbic.U.Sale.Ajax.*` callback 式），
  不要自拼 fetch、不要模擬點擊——詳見 `~/.claude/skills/usale-erp-api/`。
- 取消/退貨類方法在 `TxnUtil` 不在 `OrderUtil`；搬暫存區要用原生 `row.TxnKey` 物件；去重用 `TxnKeyStr`。
- 暫存區清單/筆數是「最終一致」，剛異動完馬上查常是舊值，UI 已內建重試等待。
