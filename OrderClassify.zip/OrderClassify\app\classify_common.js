// app/classify_common.js — 「分單助手」共用工具，被 classify_list.js 與 classify_edit.js 一起載入。
// 移植自 Shopee_Helper/dispatch/classify_common.js，差異：
//   1. storage key 換成本擴充自己的（不同擴充本來就各自一份 chrome.storage，這裡只是命名清楚）。
//   2. 訊息 target 換成 order-classify-page-helper（對應 bridge/content.js）。
//
// 暫存區政策（依使用者要求）：本工具**只讀取、不新增/不刪除** ERP 暫存區。
// 暫存區來源就是 ERP「分單助手」群組現有的那些選項（未分類、第0層_低價訂單…等），
// 使用者在 ERP 自己維護暫存區；本工具的編輯頁只提供「同步暫存區」按鈕重新抓最新清單。
//
// 通訊模式：本頁是獨立視窗（跟 ERP 分頁不同視窗），用 chrome.tabs.sendMessage 找到
// ec.mallbic.com 分頁裡的 bridge/content.js 橋接到 bridge/page.js。
// 注意：找分頁時不能限定 currentWindow（本視窗跟 ERP 分頁通常不在同一個瀏覽器視窗），
// 要用 chrome.tabs.query({ url }) 全視窗搜尋。

const CLASSIFY_STORAGE_KEY = "order_classify_categories_v1";
const CLASSIFY_SEED_VERSION_KEY = "order_classify_seed_version"; // 記錄本機已套用的「內建規格版本」
const CLASSIFY_QUEUE_GROUP = "分單助手";
const USALE_URL_PATTERNS = ["https://ec.mallbic.com/*", "http://ec.mallbic.com/*"];

async function usaleGetTab() {
  const tabs = await chrome.tabs.query({ url: USALE_URL_PATTERNS });
  const tab = tabs && tabs[0];
  if (!tab) throw new Error("找不到 ERP 分頁，請先開啟並登入 ec.mallbic.com 的訂單頁。");
  return tab;
}

async function usaleCallHelper(action, payload = {}) {
  const tab = await usaleGetTab();
  const withTimeout = (promise, ms = 180000) => Promise.race([
    promise,
    new Promise((_, reject) => window.setTimeout(() => reject(new Error(`逾時：${action}`)), ms))
  ]);
  let response;
  try {
    response = await withTimeout(chrome.tabs.sendMessage(tab.id, { target: "order-classify-page-helper", action, payload }));
  } catch (error) {
    const message = String(error?.message || "");
    if (!/Receiving end does not exist/i.test(message)) throw error;
    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ["bridge/content.js"] });
    response = await withTimeout(chrome.tabs.sendMessage(tab.id, { target: "order-classify-page-helper", action, payload }));
  }
  if (!response?.ok) throw new Error(response?.message || "OrderClassify page helper failed.");
  if (response.result?.ok === false) throw new Error(response.result?.message || "OrderClassify page helper action failed.");
  return response.result;
}

// 打包內建的預設分類與版本（default_categories.js 提供）。
function classifyDefaultSeed() {
  const s = (typeof window !== "undefined") ? window.CLASSIFY_DEFAULT_CATEGORIES : null;
  return Array.isArray(s) ? s : [];
}
function classifyDefaultVersion() {
  const v = (typeof window !== "undefined") ? Number(window.CLASSIFY_DEFAULT_VERSION) : 0;
  return Number.isFinite(v) ? v : 0;
}

// 載入分類：以「內建規格版本」統一各機規則——
//  - 全新安裝（沒存過）→ 種入內建規格。
//  - 內建規格版本 > 本機已套用版本（管理者更新了檔案並給員工覆蓋）→ 覆蓋成內建最新規格。
//  - 版本相同 → 用本機現有（員工兩次更新之間自行的增修保留，直到下次管理者升版才被統一覆蓋）。
function classifyLoadCategories() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get([CLASSIFY_STORAGE_KEY, CLASSIFY_SEED_VERSION_KEY], (d) => {
        const saved = d?.[CLASSIFY_STORAGE_KEY];
        const savedVer = Number(d?.[CLASSIFY_SEED_VERSION_KEY] || 0);
        const seed = classifyDefaultSeed();
        const seedVer = classifyDefaultVersion();
        if (seed.length && (!Array.isArray(saved) || seedVer > savedVer)) {
          try { chrome.storage.local.set({ [CLASSIFY_STORAGE_KEY]: seed, [CLASSIFY_SEED_VERSION_KEY]: seedVer }); } catch { /* ignore */ }
          resolve(seed);
          return;
        }
        resolve(Array.isArray(saved) ? saved : seed);
      });
    } catch {
      resolve(classifyDefaultSeed());
    }
  });
}

function classifySaveCategories(categories) {
  return new Promise((resolve) => {
    try { chrome.storage.local.set({ [CLASSIFY_STORAGE_KEY]: categories }, () => resolve()); }
    catch { resolve(); }
  });
}

function classifyNewId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

function classifyEscapeHtml(text) {
  return String(text || "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);
}
function classifyEscapeAttr(text) {
  return classifyEscapeHtml(text).replace(/`/g, "&#96;");
}

// ---------------------------------------------------------------------
// 條件欄位 registry：新增一種分類條件只要在這裡加一筆，
// classify_edit.js（動態條件列編輯器）跟 classify_list.js（卡片摘要文字）共用同一份。
// ---------------------------------------------------------------------
const CLASSIFY_FIELD_ORDER = ["goods", "freight", "shop", "icon", "stock", "amount", "spec"];
const CLASSIFY_FIELD_DEFS = {
  stock: {
    label: "儲位區資訊",
    make: () => ({ type: "stock", values: [], matchMode: "any" }),
    summary: (cond) => {
      if (cond.matchMode === "cross") return "儲位區：跨區（商品分散在 2 個以上不同儲位區，自動判斷，不用選標籤）";
      if (!cond.values?.length) return "儲位區：（未填）";
      const modeText = cond.matchMode === "all" ? "只能是這些儲位（可跨區）"
        : cond.matchMode === "single" ? "只能在同一個儲位區（不可跨區）"
        : "至少一項符合";
      return `儲位區：${cond.values.join("、")}｜${modeText}`;
    },
    // 標籤用上/下箭頭調整順序：這個順序給分類卡片的「排序方式」選「依儲位區標籤順序」時使用
    // （查看/列印排序是分類層級的設定，不是這個條件本身的事，見 classify_edit.html 的排序方式區塊）。
    // 配對方式用白話文字讓員工清楚，共四種：
    //  any    ＝訂單只要有一項在這些儲位就算，可以還有別的儲位
    //  all    ＝訂單只能是這些儲位，不能有別的（但可以跨好幾個清單內的區）
    //  single ＝訂單所有商品都要在「同一個」儲位區，不能跨區，而且那個區要在清單內
    //  cross  ＝訂單商品分散在 2 個以上不同的儲位區（用代碼開頭字元自動判斷，21/22 算同區，2/3 算不同區），
    //           不用設標籤清單，勾選就直接用，方便跟「單區」那張分類搭配當作「漏掉的都算跨區」
    // 輸入框有 datalist 引導：選項是即時從 ERP「庫存管理 > 儲位管理」主檔抓的區碼（'-' 前的值）。
    renderValue: (cond, _options, rowIndex) => `
      <div class="usp-stock-editor" data-role="stock-editor">
        <div class="usp-stock-tags" data-role="stock-tags">
          ${(cond.values || []).map((v, i, arr) => `
            <span class="usp-tag" data-value="${classifyEscapeAttr(v)}">
              ${classifyEscapeHtml(v)}
              <button type="button" class="usp-tag-move" data-value="${classifyEscapeAttr(v)}" data-dir="up" aria-label="往前移" ${i === 0 ? "disabled" : ""}>▲</button>
              <button type="button" class="usp-tag-move" data-value="${classifyEscapeAttr(v)}" data-dir="down" aria-label="往後移" ${i === arr.length - 1 ? "disabled" : ""}>▼</button>
              <button type="button" class="usp-tag-remove" data-value="${classifyEscapeAttr(v)}" aria-label="移除">×</button>
            </span>`).join("")}
        </div>
        <div class="usp-stock-add">
          <input type="text" class="usp-cond-value usp-stock-input" list="stock-area-list" placeholder="輸入儲位區代碼，例如 A、02；用 + 合併多個代碼成同一區，例如 H1+H2" />
          <button type="button" class="usp-btn usp-btn-sm" data-role="stock-add-btn" disabled>＋ 加入標籤</button>
        </div>
        <div class="usp-radio-group" data-role="stock-mode">
          <label class="usp-check">
            <input type="radio" name="stock-mode-${rowIndex}" data-role="stock-mode-any" ${cond.matchMode === "any" || !cond.matchMode ? "checked" : ""} />
            <span>訂單只要有一項在這些儲位就算（可以還有別的儲位）</span>
          </label>
          <label class="usp-check">
            <input type="radio" name="stock-mode-${rowIndex}" data-role="stock-mode-all" ${cond.matchMode === "all" ? "checked" : ""} />
            <span>訂單只能是這些儲位（不能有別的儲位，但可以跨好幾個清單內的區）</span>
          </label>
          <label class="usp-check">
            <input type="radio" name="stock-mode-${rowIndex}" data-role="stock-mode-single" ${cond.matchMode === "single" ? "checked" : ""} />
            <span>訂單所有商品都要在同一個儲位區（不能跨區），且那個區要在清單內</span>
          </label>
          <label class="usp-check">
            <input type="radio" name="stock-mode-${rowIndex}" data-role="stock-mode-cross" ${cond.matchMode === "cross" ? "checked" : ""} />
            <span>跨區：訂單商品分散在 2 個以上不同儲位區（自動判斷，21/22 算同區、2/3 算不同區，不用選標籤）</span>
          </label>
        </div>
        ${cond.matchMode === "cross" ? `<div class="usp-hint">已選「跨區」：這個模式自動判斷，上面的標籤清單不會用到，可以留空。</div>` : ""}
      </div>`,
    collect: (row) => {
      const values = Array.from(row.querySelectorAll('[data-role="stock-tags"] .usp-tag')).map((t) => t.dataset.value);
      const matchMode = row.querySelector('[data-role="stock-mode-single"]')?.checked ? "single"
        : row.querySelector('[data-role="stock-mode-cross"]')?.checked ? "cross"
        : row.querySelector('[data-role="stock-mode-all"]')?.checked ? "all" : "any";
      return { type: "stock", values, matchMode };
    }
  },
  icon: {
    label: "圖示",
    make: () => ({ type: "icon", values: [] }),
    summary: (cond) => `圖示：${(cond.values || []).join("、") || "（未選）"}`,
    renderValue: (cond, options) => {
      const icons = options?.icons || [];
      if (!icons.length) {
        const saved = (cond.values || []).length ? `　目前已選：${classifyEscapeHtml(cond.values.join("、"))}（儲存不會清除）` : "";
        return `<div class="usp-hint">尚未讀到 ERP 圖示選項，按下面「重新讀取選項」。${saved}</div>`;
      }
      return `<div class="usp-checks" data-role="icon-checks">
        ${icons.map((f) => `
          <label class="usp-check">
            <input type="checkbox" value="${classifyEscapeAttr(f.label)}" ${cond.values?.includes(f.label) ? "checked" : ""} />
            <span>${classifyEscapeHtml(f.label)}</span>
          </label>`).join("")}
      </div>`;
    },
    collect: (row) => {
      const box = row.querySelector('[data-role="icon-checks"]');
      // 選項還沒載入時畫的是提示、沒有勾選框 → 回 null，讓呼叫端保留原本已選的圖示，不要洗成空
      if (!box) return null;
      return { type: "icon", values: Array.from(box.querySelectorAll("input:checked")).map((n) => n.value) };
    }
  },
  goods: {
    label: "商品/SKU",
    make: () => ({ type: "goods", values: [], matchMode: "any" }),
    summary: (cond) => {
      const mode = cond.matchMode === "all" ? "只能是這些商品"
        : cond.matchMode === "single" ? "單品訂單且在清單內"
        : "至少一項符合";
      return `商品/SKU：${(cond.values || []).length} 項｜${mode}`;
    },
    // 配對方式比照「儲位區資訊」的多選配置，但針對商品：
    //  any    ＝訂單只要有一項是這些商品就算（可以還有別的商品）
    //  all    ＝訂單只能是這些商品（不能有清單外的商品）
    //  single ＝訂單只有一種商品，且是清單內的（單品訂單）
    renderValue: (cond, _options, rowIndex) => `
      <div class="usp-stock-tags" data-role="goods-tags">
        ${(cond.values || []).map((v) => `
          <span class="usp-tag" data-value="${classifyEscapeAttr(v)}">
            ${classifyEscapeHtml(v)}
            <button type="button" class="usp-tag-remove" data-value="${classifyEscapeAttr(v)}" aria-label="移除">×</button>
          </span>`).join("")}
      </div>
      <div class="usp-stock-add">
        <input type="text" class="usp-cond-value usp-goods-input" placeholder="輸入商品編號/條碼，例如 D134；可逗號分隔多筆，按 Enter 或＋加入" />
        <button type="button" class="usp-btn usp-btn-sm" data-role="goods-add-btn" disabled>＋ 加入標籤</button>
      </div>
      <div class="usp-radio-group" data-role="goods-mode">
        <label class="usp-check">
          <input type="radio" name="goods-mode-${rowIndex}" data-role="goods-mode-any" ${cond.matchMode === "any" || !cond.matchMode ? "checked" : ""} />
          <span>訂單只要有一項是這些商品就算（可以還有別的商品）</span>
        </label>
        <label class="usp-check">
          <input type="radio" name="goods-mode-${rowIndex}" data-role="goods-mode-all" ${cond.matchMode === "all" ? "checked" : ""} />
          <span>訂單只能是這些商品（不能有清單外的商品）</span>
        </label>
        <label class="usp-check">
          <input type="radio" name="goods-mode-${rowIndex}" data-role="goods-mode-single" ${cond.matchMode === "single" ? "checked" : ""} />
          <span>訂單只有一種商品，且是清單內的（單品訂單）</span>
        </label>
      </div>`,
    collect: (row) => {
      const values = Array.from(row.querySelectorAll('[data-role="goods-tags"] .usp-tag')).map((t) => t.dataset.value);
      const matchMode = row.querySelector('[data-role="goods-mode-all"]')?.checked ? "all"
        : row.querySelector('[data-role="goods-mode-single"]')?.checked ? "single" : "any";
      return { type: "goods", values, matchMode };
    }
  },
  freight: {
    label: "物流方式",
    make: () => ({ type: "freight", values: [] }),
    summary: (cond) => `物流：${(cond.values || []).join("、") || "（未選）"}`,
    renderValue: (cond, options) => {
      const freights = options?.freights || [];
      if (!freights.length) {
        const saved = (cond.values || []).length ? `　目前已選：${classifyEscapeHtml(cond.values.join("、"))}（儲存不會清除）` : "";
        return `<div class="usp-hint">尚未讀到 ERP 物流選項，按下面「重新讀取選項」。${saved}</div>`;
      }
      return `<div class="usp-checks" data-role="freight-checks">
        ${freights.map((f) => `
          <label class="usp-check">
            <input type="checkbox" value="${classifyEscapeAttr(f.label)}" ${cond.values?.includes(f.label) ? "checked" : ""} />
            <span>${classifyEscapeHtml(f.label)}</span>
          </label>`).join("")}
      </div>`;
    },
    collect: (row) => {
      const box = row.querySelector('[data-role="freight-checks"]');
      // 選項還沒載入時畫的是提示、沒有勾選框 → 回 null，讓呼叫端保留原本已選的物流，不要洗成空
      if (!box) return null;
      return { type: "freight", values: Array.from(box.querySelectorAll("input:checked")).map((n) => n.value) };
    }
  },
  shop: {
    label: "店家／賣場",
    make: () => ({ type: "shop", values: [] }),
    summary: (cond) => `店家：${(cond.values || []).join("、") || "（未選）"}`,
    renderValue: (cond, options) => {
      const shops = options?.shops || [];
      if (!shops.length) {
        const saved = (cond.values || []).length ? `　目前已選：${classifyEscapeHtml(cond.values.join("、"))}（儲存不會清除）` : "";
        return `<div class="usp-hint">尚未讀到 ERP 店家選項，按下面「重新讀取選項」。${saved}</div>`;
      }
      // 有勾選＝訂單只要是其中任一店家就算（OR）
      return `<div class="usp-checks" data-role="shop-checks">
        ${shops.map((s) => `
          <label class="usp-check">
            <input type="checkbox" value="${classifyEscapeAttr(s.label)}" ${cond.values?.includes(s.label) ? "checked" : ""} />
            <span>${classifyEscapeHtml(s.label)}</span>
          </label>`).join("")}
      </div>`;
    },
    collect: (row) => {
      const box = row.querySelector('[data-role="shop-checks"]');
      // 選項還沒載入時畫的是提示、沒有勾選框 → 回 null，讓呼叫端保留原本已選的店家，不要洗成空
      if (!box) return null;
      return { type: "shop", values: Array.from(box.querySelectorAll("input:checked")).map((n) => n.value) };
    }
  },
  amount: {
    label: "訂單金額（商品總計）",
    make: () => ({ type: "amount", min: null, max: null }),
    summary: (cond) => {
      if (cond.min != null && cond.max != null) return `金額：${cond.min}～${cond.max}`;
      if (cond.min != null) return `金額：≥${cond.min}`;
      if (cond.max != null) return `金額：≤${cond.max}`;
      return "金額：（未設定範圍）";
    },
    renderValue: (cond) => `
      <div class="usp-amount-row">
        <input type="number" class="usp-cond-value" data-role="amount-min" value="${cond.min ?? ""}" placeholder="大於等於" />
        <span>～</span>
        <input type="number" class="usp-cond-value" data-role="amount-max" value="${cond.max ?? ""}" placeholder="小於等於" />
      </div>`,
    collect: (row) => {
      const minRaw = String(row.querySelector('[data-role="amount-min"]')?.value || "").trim();
      const maxRaw = String(row.querySelector('[data-role="amount-max"]')?.value || "").trim();
      return { type: "amount", min: minRaw === "" ? null : Number(minRaw), max: maxRaw === "" ? null : Number(maxRaw) };
    }
  },
  spec: {
    label: "規格款數",
    make: () => ({ type: "spec", min: null, max: null }),
    summary: (cond) => {
      if (cond.min != null && cond.max != null) return `規格款數：${cond.min}～${cond.max}`;
      if (cond.min != null) return `規格款數：≥${cond.min}`;
      if (cond.max != null) return `規格款數：≤${cond.max}`;
      return "規格款數：（未設定範圍）";
    },
    renderValue: (cond) => `
      <div class="usp-amount-row">
        <input type="number" class="usp-cond-value" data-role="spec-min" value="${cond.min ?? ""}" placeholder="大於等於" />
        <span>～</span>
        <input type="number" class="usp-cond-value" data-role="spec-max" value="${cond.max ?? ""}" placeholder="小於等於" />
      </div>`,
    collect: (row) => {
      const minRaw = String(row.querySelector('[data-role="spec-min"]')?.value || "").trim();
      const maxRaw = String(row.querySelector('[data-role="spec-max"]')?.value || "").trim();
      return { type: "spec", min: minRaw === "" ? null : Number(minRaw), max: maxRaw === "" ? null : Number(maxRaw) };
    }
  }
};

// 把分類的條件陣列轉成 classifyByLayers 吃的扁平層 payload。
// 同欄位類型若出現多列，值會合併：goods/freight 取聯集，amount 取最嚴格的上下限。
function classifyCategoryToLayerPayload(cat) {
  const codes = [];
  const delivery = [];
  const shops = [];
  const icons = [];
  const storage = [];
  let stockMode = "any"; // 用第一條「儲位區資訊」條件的配對方式（一般只會有一條）
  let stockModeSet = false;
  let goodsMode = "any"; // 用第一條「商品/SKU」條件的配對方式
  let goodsModeSet = false;
  let amountMin = null;
  let amountMax = null;
  let specMin = null;
  let specMax = null;
  (cat.conditions || []).forEach((c) => {
    if (c.type === "goods") {
      codes.push(...(c.values || []));
      if (!goodsModeSet) {
        goodsMode = ["all", "single"].includes(c.matchMode) ? c.matchMode : "any";
        goodsModeSet = true;
      }
    }
    else if (c.type === "freight") delivery.push(...(c.values || []));
    else if (c.type === "shop") shops.push(...(c.values || []));
    else if (c.type === "icon") icons.push(...(c.values || []));
    else if (c.type === "stock") {
      storage.push(...(c.values || []));
      if (!stockModeSet) {
        stockMode = ["all", "single", "cross"].includes(c.matchMode) ? c.matchMode : "any";
        stockModeSet = true;
      }
    } else if (c.type === "amount") {
      if (c.min != null) amountMin = amountMin == null ? c.min : Math.max(amountMin, c.min);
      if (c.max != null) amountMax = amountMax == null ? c.max : Math.min(amountMax, c.max);
    } else if (c.type === "spec") {
      if (c.min != null) specMin = specMin == null ? c.min : Math.max(specMin, c.min);
      if (c.max != null) specMax = specMax == null ? c.max : Math.min(specMax, c.max);
    }
  });
  return { name: cat.name, codes, delivery, shops, icons, storage, stockMode, goodsMode, amountMin: amountMin ?? "", amountMax: amountMax ?? "", specMin: specMin ?? "", specMax: specMax ?? "" };
}

// 把所有分類展開成 classifyByLayers 要的 layers 陣列，並回傳 refs 對照（每個 layer 對應哪張卡）。
// 一般分類與兩段式的「父層」都各 1 個 layer。
// 兩段式的「子分類」不在整批同步時計算——它們是「從父層暫存區讀取」的獨立操作（見 fanoutFromParentQueue），
// 所以這裡一律把子分類筆數清成 null（畫面顯示「--」），避免拿目前來源去算出誤導的數字，
// 也不會像以前那樣把整個來源切成父層暫存區、害其他卡片歸零。
function classifyBuildLayerSpecs(categories) {
  const layers = [];
  const refs = [];
  (categories || []).forEach((cat) => {
    layers.push(classifyCategoryToLayerPayload(cat));
    refs.push({ cat, child: null });
    if (cat.twoStage && Array.isArray(cat.children)) {
      cat.children.forEach((child) => { child._count = null; child._layerId = null; });
      cat._fanoutTotal = null; // 父層暫存區總數（供子分類「其他」計算），整批同步時一併清掉
    }
  });
  return { layers, refs };
}

// 取出這個分類「儲位區資訊」條件的標籤順序（沒有這個條件就回傳空陣列）。
// 只有分類的「排序方式」選了「依儲位區標籤順序」時才會真的拿去用，見 classifyCategorySortPayload。
function classifyCategoryStockOrder(cat) {
  const cond = (cat.conditions || []).find((c) => c.type === "stock" && c.values?.length);
  return cond ? cond.values.slice() : [];
}

// 分類卡片的「排序方式」（category 層級設定，跟有沒有設儲位區條件無關）：
// 「不排序」已移除，預設 "date-asc"（依建立時間舊到新）；"stock" ＝依儲位區標籤順序（需該分類有設「儲位區資訊」條件）；
// "spec-asc" ＝依規格款數少到多；"freight" ＝依物流方式。舊資料存的 "none" 一律當作 date-asc。
// 轉成 showLayerInMainTable 看得懂的 payload 欄位。
function classifyCategorySortPayload(cat) {
  const mode = cat.sortMode || "date-asc";
  if (mode === "stock") {
    const stockOrder = classifyCategoryStockOrder(cat);
    if (stockOrder.length) return { sortMode: "stock", stockOrder };
    return { sortMode: "date-asc" }; // 選了依儲位區排序但沒設標籤，退回預設（依建立時間），不報錯
  }
  if (mode === "spec-asc") return { sortMode: "spec-asc" };
  if (mode === "count-desc") return { sortMode: "count-desc" };
  if (mode === "freight") return { sortMode: "freight" };
  return { sortMode: "date-asc" }; // date-asc 或舊的 none 一律依建立時間
}

// 開啟/聚焦獨立小視窗（視窗唯一化：同一個 URL 已開著就聚焦，不重複開）。
function classifyOpenWindow(url, width = 900, height = 640) {
  chrome.tabs.query({ url }, (tabs) => {
    const t = tabs && tabs[0];
    if (t) {
      chrome.tabs.update(t.id, { active: true });
      chrome.windows.update(t.windowId, { focused: true });
      return;
    }
    const sw = (window.screen && window.screen.availWidth) || 1280;
    const sh = (window.screen && window.screen.availHeight) || 800;
    const W = Math.min(width, sw);
    const H = Math.min(height, sh);
    chrome.windows.create({
      url, type: "popup", width: W, height: H,
      left: Math.max(0, Math.round((sw - W) / 2)),
      top: Math.max(0, Math.round((sh - H) / 2))
    });
  });
}
