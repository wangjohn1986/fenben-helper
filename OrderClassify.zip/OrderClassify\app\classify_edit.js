// app/classify_edit.js — 「分單助手」編輯畫面（動態條件列 + 兩段式分類）。
// 用 ?id=xxx 帶入要編輯的分類 id，?id=new 代表新增。
// 儲存時重新讀一次最新的分類清單（read-modify-write），只更新/新增這一筆，避免跟主畫面互相覆蓋。
//
// 條件編輯器泛化：主分類與每個子分類共用同一套「條件列」邏輯。
//  - 每個條件容器是 .usp-cond-list[data-owner]，owner="main" 代表主分類，其餘是子分類 id。
//  - 條件之間是 AND、順序不影響比對，所以子分類的條件列不提供「拖曳排序」（只有主分類保留拖曳）。

(() => {
  const params = new URLSearchParams(location.search);
  const editId = params.get("id") || "new";
  const isNew = editId === "new";

  const state = {
    // draft = { id, name, queue, sortMode, conditions, twoStage, children:[{id,name,queue,conditions}] }
    draft: null,
    options: { freights: [], shops: [], icons: [], queues: [], stockPrefixes: [] },
    dragRowIdx: null // 主分類條件列拖曳中的原始索引（子分類不拖曳）
  };

  const els = {
    form: document.querySelector(".usp-form"),
    status: document.querySelector("#cls-status"),
    name: document.querySelector("#f-name"),
    condList: document.querySelector("#cond-list"),
    queue: document.querySelector("#f-queue"),
    queueField: document.querySelector("#queue-field"),
    twoStageToggle: document.querySelector("#two-stage-toggle"),
    childrenSection: document.querySelector("#children-section"),
    childrenList: document.querySelector("#children-list"),
    addChild: document.querySelector("#add-child"),
    sortModeGroup: document.querySelector("#sort-mode-group"),
    stockAreaList: document.querySelector("#stock-area-list"),
    addCond: document.querySelector("#add-cond"),
    save: document.querySelector("#f-save"),
    cancel: document.querySelector("#f-cancel")
  };

  function setStatus(text, isError = false) {
    els.status.textContent = text;
    els.status.classList.toggle("cls-error", !!isError);
  }

  function fieldSelectOptions(selected) {
    return CLASSIFY_FIELD_ORDER.map((key) =>
      `<option value="${key}" ${key === selected ? "selected" : ""}>${CLASSIFY_FIELD_DEFS[key].label}</option>`
    ).join("");
  }

  function cloneCond(c) {
    return { ...c, values: Array.isArray(c.values) ? [...c.values] : c.values };
  }

  function makeDefaultChild() {
    // 子分類預設帶一條「物流方式」條件（最常見的分流依據）
    return { id: classifyNewId("child"), name: "", queue: "", conditions: [CLASSIFY_FIELD_DEFS.freight.make()] };
  }

  function childById(id) {
    return (state.draft.children || []).find((c) => c.id === id) || null;
  }

  // 依 owner 取得對應的條件陣列（main = 主分類；其餘 = 子分類 id）
  function ownerConditions(owner) {
    if (owner === "main") return state.draft.conditions;
    const child = childById(owner);
    return child ? child.conditions : null;
  }

  // ---- 暫存區下拉（父層 + 子分類共用同一份名稱清單） ----
  function queueNames() {
    return (state.options.queues || [])
      .filter((q) => q.group === CLASSIFY_QUEUE_GROUP)
      .map((q) => q.name)
      .filter(Boolean);
  }
  function queueOptionsHtml(selected) {
    const names = queueNames();
    const opts = [`<option value="">（請選擇）</option>`];
    // 已存的暫存區若不在目前清單（選項還沒載入，或 ERP 已改名/移除），仍補上該選項並選中，
    // 避免每次開編輯就被洗成「請選擇」而需重挑；真的找不到時加註提示讓使用者判斷是否重挑。
    if (selected && !names.includes(selected)) {
      opts.push(`<option value="${classifyEscapeAttr(selected)}" selected>${classifyEscapeHtml(selected)}（清單中找不到）</option>`);
    }
    opts.push(...names.map((n) => `<option value="${classifyEscapeAttr(n)}" ${n === selected ? "selected" : ""}>${classifyEscapeHtml(n)}</option>`));
    return opts.join("");
  }
  function renderQueueSelect() {
    const wanted = String(els.queue.value || state.draft?.queue || "");
    els.queue.innerHTML = queueOptionsHtml(wanted);
    els.queue.value = wanted; // queueOptionsHtml 已保證含 wanted 選項（即使暫時不在清單），不再重設成空
  }

  function renderStockAreaList() {
    const codes = state.options.stockPrefixes || [];
    els.stockAreaList.innerHTML = codes.map((n) => `<option value="${classifyEscapeAttr(n)}"></option>`).join("");
  }

  // ---- 條件列泛化：渲染 / 讀回，吃 (容器, 條件陣列, owner) ----
  // owner 用來讓 stock-mode radio 的 name 在不同容器/不同列之間不衝突，並讓事件能找回是哪個 owner。
  function renderCondScope(container, conditions, owner) {
    const rows = conditions.map((cond, i) => `
      <div class="usp-cond-row" data-idx="${i}">
        <div class="usp-cond-row-top">
          ${owner === "main" ? `<span class="usp-cond-handle" draggable="true" title="拖曳調整順序" aria-label="拖曳調整條件${i + 1}的順序">⠿</span>` : ""}
          <span class="usp-cond-label">條件${i + 1}</span>
          <select class="usp-cond-type" data-idx="${i}">${fieldSelectOptions(cond.type)}</select>
          <button type="button" class="usp-cond-remove" data-idx="${i}" title="移除這條件">－</button>
        </div>
        <div class="usp-cond-value-wrap">${CLASSIFY_FIELD_DEFS[cond.type].renderValue(cond, state.options, `${owner}-${i}`)}</div>
      </div>`).join("");
    const emptyHint = owner === "main"
      ? `<div class="usp-hint">尚未加任何條件，會接住全部訂單。</div>`
      : `<div class="usp-hint">尚未加任何條件，這個子分類會接住父層全部訂單。</div>`;
    container.innerHTML = rows || emptyHint;
  }

  function syncScope(container, conditions) {
    container.querySelectorAll(".usp-cond-row").forEach((row) => {
      const idx = Number(row.dataset.idx);
      const type = row.querySelector(".usp-cond-type")?.value;
      const def = CLASSIFY_FIELD_DEFS[type];
      if (!def || !conditions[idx]) return;
      const collected = def.collect(row);
      // collect 回 null＝這列的值編輯器沒真的渲染（例如物流/圖示選項尚未從 ERP 載入，畫的是提示），
      // 這時保留原值不要覆蓋，避免把已設定好的物流/圖示洗成空（資料遺失 bug）。
      if (collected != null) conditions[idx] = collected;
    });
  }

  // 主分類（放在固定容器 els.condList，owner="main"）
  function renderConditions() { renderCondScope(els.condList, state.draft.conditions, "main"); }
  function syncMainFromDom() { syncScope(els.condList, state.draft.conditions); }

  // 儲位區標籤：加入一個（去重、轉大寫），寫回指定 conditions 後重畫該容器。
  // 支援用「+」合併多個代碼成同一個標籤（例如「H1+H2」）。防呆：每段要嘛等於某真實代碼、要嘛是其前綴。
  function addStockTagInto(conditions, rowIdx, rawValue, container, owner) {
    const parts = String(rawValue || "").split("+").map((s) => s.trim().toUpperCase()).filter(Boolean);
    if (!parts.length) return;
    const validCodes = state.options.stockPrefixes || [];
    if (!validCodes.length) {
      setStatus("尚未讀到 ERP 儲位區代碼，請先按「重新讀取 ERP 選項」再試。", true);
      return;
    }
    const invalid = parts.filter((p) => !validCodes.some((code) => code.startsWith(p)));
    if (invalid.length) {
      setStatus(`查無以「${invalid.join("、")}」開頭的儲位區代碼，請從輸入框的建議清單中選擇，或改打某個代碼的開頭（例如「2」代表 21/22，「H1+H2」代表合併 H1 跟 H2 為同一區）。`, true);
      return;
    }
    const value = parts.join("+");
    const cond = conditions[rowIdx];
    if (!cond || cond.type !== "stock") return;
    if (!cond.values.includes(value)) cond.values.push(value);
    renderCondScope(container, conditions, owner);
  }

  // 商品/SKU 標籤：加入一或多個（逗號可分隔多筆、去重、轉大寫）。商品不需驗證/合併/排序，比儲位單純。
  function addGoodsTagInto(conditions, rowIdx, rawValue, container, owner) {
    const vals = String(rawValue || "").split(/[,，\n]/).map((s) => s.trim().toUpperCase()).filter(Boolean);
    if (!vals.length) return;
    const cond = conditions[rowIdx];
    if (!cond || cond.type !== "goods") return;
    vals.forEach((v) => { if (!cond.values.includes(v)) cond.values.push(v); });
    renderCondScope(container, conditions, owner);
  }

  // ---- 子分類渲染 ----
  function renderChildren() {
    const list = state.draft.children || [];
    els.childrenList.innerHTML = list.map((child) => `
      <div class="usp-child" data-child-id="${classifyEscapeAttr(child.id)}">
        <div class="usp-child-top">
          <input type="text" class="usp-child-name" value="${classifyEscapeAttr(child.name)}" placeholder="子分類名稱，例如：新竹物流" />
          <select class="usp-child-queue">${queueOptionsHtml(child.queue)}</select>
          <button type="button" class="usp-btn usp-btn-sm usp-btn-danger usp-child-remove" title="刪除這個子分類">✕</button>
        </div>
        <div class="usp-cond-list" data-owner="${classifyEscapeAttr(child.id)}"></div>
        <button type="button" class="usp-btn usp-btn-sm usp-child-addcond">＋ 新增子分類條件</button>
      </div>`).join("");
    list.forEach((child) => {
      const cont = els.childrenList.querySelector(`.usp-cond-list[data-owner="${CSS.escape(child.id)}"]`);
      if (cont) renderCondScope(cont, child.conditions, child.id);
    });
  }

  // 從 DOM 把子分類的名稱/暫存區/條件都讀回 state（重畫前或存檔前呼叫，避免丟失使用者已輸入的值）
  function syncChildrenFromDom() {
    (state.draft.children || []).forEach((child) => {
      const block = els.childrenList.querySelector(`.usp-child[data-child-id="${CSS.escape(child.id)}"]`);
      if (!block) return;
      const nameEl = block.querySelector(".usp-child-name");
      const queueEl = block.querySelector(".usp-child-queue");
      if (nameEl) child.name = String(nameEl.value).trim();
      if (queueEl) child.queue = String(queueEl.value);
      const scope = block.querySelector(".usp-cond-list");
      if (scope) syncScope(scope, child.conditions);
    });
  }

  // 把畫面上所有條件（主 + 子）讀回 state
  function syncAllFromDom() {
    syncMainFromDom();
    if (state.draft.twoStage) syncChildrenFromDom();
  }

  function applyTwoStageVisibility() {
    // 父層暫存區欄一律顯示：兩段式的父層本身也是一般分類卡（查看／移入暫存區／編輯／刪除）。
    els.queueField.hidden = false;
    els.childrenSection.hidden = !state.draft.twoStage;
  }

  async function refreshOptions() {
    // 開啟編輯時在背景自動載入，成功不顯示訊息（避免「選項已更新」雜訊）；只有失敗才提示。
    try {
      const res = await usaleCallHelper("getRuleOptions", {});
      state.options.freights = res.freights || [];
      state.options.shops = res.shops || [];
      state.options.icons = res.icons || [];
      state.options.queues = res.queues || [];
    } catch (error) {
      setStatus(`讀取選項失敗：${error?.message || "請確認目前在 ERP 訂單頁。"}`, true);
    }
    try {
      const stockRes = await usaleCallHelper("getStockAreaCodes", {});
      state.options.stockPrefixes = stockRes.prefixes || [];
    } catch {
      // 儲位區代碼讀不到不擋其他選項，輸入框照樣可以手動填
    }
    renderQueueSelect();
    renderStockAreaList();
    renderConditions();
    if (state.draft.twoStage) { syncChildrenFromDom(); renderChildren(); }
  }

  async function init() {
    const all = await classifyLoadCategories();
    const existing = isNew ? null : all.find((c) => c.id === editId);
    if (existing) {
      state.draft = {
        id: existing.id,
        name: existing.name,
        queue: existing.queue || "",
        sortMode: existing.sortMode || "date-asc",
        conditions: (existing.conditions || []).map(cloneCond),
        twoStage: !!existing.twoStage,
        children: (existing.children || []).map((ch) => ({
          id: ch.id || classifyNewId("child"),
          name: ch.name || "",
          queue: ch.queue || "",
          conditions: (ch.conditions || []).map(cloneCond)
        }))
      };
    } else {
      state.draft = { id: classifyNewId("cat"), name: `分類 ${all.length + 1}`, queue: "", sortMode: "date-asc", conditions: [], twoStage: false, children: [] };
    }
    els.name.value = state.draft.name;
    // 「不排序」已移除，預設依建立時間；舊分類存的 none（或找不到對應選項）也退回 date-asc，避免沒有任何選項被選中
    const sortRadio = els.sortModeGroup.querySelector(`input[value="${state.draft.sortMode}"]`)
      || els.sortModeGroup.querySelector('input[value="date-asc"]');
    if (sortRadio) sortRadio.checked = true;
    els.twoStageToggle.checked = state.draft.twoStage;
    applyTwoStageVisibility();
    renderConditions();
    renderChildren();
    refreshOptions(); // 背景讀，不擋畫面
  }

  // ---- 新增條件（主分類 / 子分類各一顆） ----
  els.addCond.addEventListener("click", () => {
    syncMainFromDom();
    state.draft.conditions.push(CLASSIFY_FIELD_DEFS[CLASSIFY_FIELD_ORDER[0]].make());
    renderConditions();
  });

  // ---- 兩段式開關 ----
  els.twoStageToggle.addEventListener("change", () => {
    // 取消兩段式：若子分類已實際設了名稱/暫存區/條件值，先問是否清除；取消就把勾勾還原、不縮回
    if (!els.twoStageToggle.checked) {
      syncChildrenFromDom(); // 先把目前子分類的輸入讀回來再判斷
      const hasContent = (state.draft.children || []).some((ch) =>
        (ch.name && ch.name.trim()) ||
        (ch.queue && ch.queue.trim()) ||
        (ch.conditions || []).some((c) => (c.values && c.values.length) || c.min != null || c.max != null)
      );
      if (hasContent && !window.confirm("取消「兩段式分類」會清除已設定的子分類，確定嗎？")) {
        els.twoStageToggle.checked = true; // 使用者按取消 → 保持勾選、不清除
        return;
      }
      state.draft.children = []; // 確定關閉 → 清空子分類
    }
    syncMainFromDom();
    state.draft.twoStage = els.twoStageToggle.checked;
    if (state.draft.twoStage && (!state.draft.children || !state.draft.children.length)) {
      state.draft.children = [makeDefaultChild()];
    }
    applyTwoStageVisibility();
    renderChildren();
  });

  els.addChild.addEventListener("click", () => {
    syncChildrenFromDom();
    if (!Array.isArray(state.draft.children)) state.draft.children = [];
    state.draft.children.push(makeDefaultChild());
    renderChildren();
  });

  // ---- 條件列事件：主 + 子共用，掛在 .usp-form 上，用 closest(.usp-cond-list) 找回 owner ----
  els.form.addEventListener("click", (event) => {
    const scope = event.target.closest(".usp-cond-list");
    if (!scope) return;
    const owner = scope.dataset.owner;
    const conditions = ownerConditions(owner);
    if (!conditions) return;

    const removeBtn = event.target.closest(".usp-cond-remove");
    if (removeBtn) {
      syncScope(scope, conditions);
      conditions.splice(Number(removeBtn.dataset.idx), 1);
      renderCondScope(scope, conditions, owner);
      return;
    }
    const addTagBtn = event.target.closest('[data-role="stock-add-btn"]');
    if (addTagBtn) {
      const row = addTagBtn.closest(".usp-cond-row");
      const idx = Number(row.dataset.idx);
      syncScope(scope, conditions); // 先把本容器目前狀態存回，再加入新標籤
      addStockTagInto(conditions, idx, row.querySelector(".usp-stock-input")?.value, scope, owner);
      return;
    }
    const goodsAddBtn = event.target.closest('[data-role="goods-add-btn"]');
    if (goodsAddBtn) {
      const row = goodsAddBtn.closest(".usp-cond-row");
      const idx = Number(row.dataset.idx);
      syncScope(scope, conditions);
      addGoodsTagInto(conditions, idx, row.querySelector(".usp-goods-input")?.value, scope, owner);
      return;
    }
    const removeTagBtn = event.target.closest(".usp-tag-remove");
    if (removeTagBtn) {
      const row = removeTagBtn.closest(".usp-cond-row");
      const idx = Number(row.dataset.idx);
      syncScope(scope, conditions);
      const cond = conditions[idx];
      if (cond) cond.values = cond.values.filter((v) => v !== removeTagBtn.dataset.value);
      renderCondScope(scope, conditions, owner);
      return;
    }
    const moveTagBtn = event.target.closest(".usp-tag-move");
    if (moveTagBtn) {
      const row = moveTagBtn.closest(".usp-cond-row");
      const idx = Number(row.dataset.idx);
      syncScope(scope, conditions);
      const cond = conditions[idx];
      if (!cond) return;
      const pos = cond.values.indexOf(moveTagBtn.dataset.value);
      const swapWith = moveTagBtn.dataset.dir === "up" ? pos - 1 : pos + 1;
      if (pos < 0 || swapWith < 0 || swapWith >= cond.values.length) return;
      [cond.values[pos], cond.values[swapWith]] = [cond.values[swapWith], cond.values[pos]];
      renderCondScope(scope, conditions, owner);
    }
  });

  els.form.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    const isStock = event.target.classList.contains("usp-stock-input");
    const isGoods = event.target.classList.contains("usp-goods-input");
    if (!isStock && !isGoods) return;
    event.preventDefault();
    if (!String(event.target.value || "").trim()) return;
    const scope = event.target.closest(".usp-cond-list");
    if (!scope) return;
    const owner = scope.dataset.owner;
    const conditions = ownerConditions(owner);
    if (!conditions) return;
    const row = event.target.closest(".usp-cond-row");
    const idx = Number(row.dataset.idx);
    syncScope(scope, conditions);
    if (isStock) addStockTagInto(conditions, idx, event.target.value, scope, owner);
    else addGoodsTagInto(conditions, idx, event.target.value, scope, owner);
  });

  // 防呆：儲位/商品輸入框沒內容時對應的「＋加入標籤」保持停用
  els.form.addEventListener("input", (event) => {
    const isStock = event.target.classList.contains("usp-stock-input");
    const isGoods = event.target.classList.contains("usp-goods-input");
    if (!isStock && !isGoods) return;
    const row = event.target.closest(".usp-cond-row");
    const addBtn = row?.querySelector(isStock ? '[data-role="stock-add-btn"]' : '[data-role="goods-add-btn"]');
    if (addBtn) addBtn.disabled = !String(event.target.value || "").trim();
  });

  // 換條件類型：這一列換成新類型的預設值（值型別不同，直接重置最單純安全）
  els.form.addEventListener("change", (event) => {
    const sel = event.target.closest(".usp-cond-type");
    if (!sel) return;
    const scope = sel.closest(".usp-cond-list");
    const owner = scope.dataset.owner;
    const conditions = ownerConditions(owner);
    if (!conditions) return;
    syncScope(scope, conditions);
    conditions[Number(sel.dataset.idx)] = CLASSIFY_FIELD_DEFS[sel.value].make();
    renderCondScope(scope, conditions, owner);
  });

  // ---- 子分類層級事件（新增子條件 / 刪除子分類）掛在 childrenList 上 ----
  els.childrenList.addEventListener("click", (event) => {
    const addCondBtn = event.target.closest(".usp-child-addcond");
    if (addCondBtn) {
      const block = addCondBtn.closest(".usp-child");
      const child = childById(block?.dataset.childId);
      if (!child) return;
      const scope = block.querySelector(".usp-cond-list");
      syncScope(scope, child.conditions);
      child.conditions.push(CLASSIFY_FIELD_DEFS.freight.make()); // 子分類新增條件預設物流
      renderCondScope(scope, child.conditions, child.id);
      return;
    }
    const removeChildBtn = event.target.closest(".usp-child-remove");
    if (removeChildBtn) {
      const block = removeChildBtn.closest(".usp-child");
      syncChildrenFromDom(); // 先保住其他子分類已輸入的值
      state.draft.children = (state.draft.children || []).filter((c) => c.id !== block?.dataset.childId);
      renderChildren();
    }
  });

  // ---- 主分類條件列拖曳排序（只有主分類有拖曳把手；純視覺，不影響 AND 比對）----
  els.condList.addEventListener("dragstart", (event) => {
    const handle = event.target.closest(".usp-cond-handle");
    if (!handle) return;
    state.dragRowIdx = Number(handle.closest(".usp-cond-row")?.dataset.idx);
    event.dataTransfer.effectAllowed = "move";
  });
  els.condList.addEventListener("dragover", (event) => {
    if (state.dragRowIdx != null && event.target.closest(".usp-cond-row")) event.preventDefault();
  });
  els.condList.addEventListener("drop", (event) => {
    const targetRow = event.target.closest(".usp-cond-row");
    if (!targetRow || state.dragRowIdx == null) return;
    event.preventDefault();
    const fromIdx = state.dragRowIdx;
    const toIdx = Number(targetRow.dataset.idx);
    state.dragRowIdx = null;
    if (fromIdx === toIdx) return;
    syncMainFromDom();
    const [moved] = state.draft.conditions.splice(fromIdx, 1);
    state.draft.conditions.splice(toIdx, 0, moved);
    renderConditions();
  });

  els.cancel.addEventListener("click", () => window.close());

  els.save.addEventListener("click", async () => {
    syncAllFromDom();
    const name = String(els.name.value || "").trim();
    if (!name) { setStatus("請輸入分類名稱。", true); return; }
    state.draft.name = name;
    state.draft.queue = String(els.queue.value || "").trim();
    state.draft.sortMode = els.sortModeGroup.querySelector("input:checked")?.value || "date-asc";
    state.draft.twoStage = !!els.twoStageToggle.checked;

    let children = [];
    if (state.draft.twoStage) {
      // 子分類要「從父層暫存區讀取再分流」，所以父層一定要先有一個對應暫存區當中繼
      if (!state.draft.queue) {
        setStatus("兩段式的子分類會從「父層暫存區」讀取，所以父層必須先選一個對應暫存區（上面「對應暫存區」）。", true);
        return;
      }
      children = (state.draft.children || []).map((ch) => ({
        id: ch.id,
        name: (ch.name || "子分類").trim(),
        queue: ch.queue || "",
        conditions: ch.conditions,
        _count: null,
        _layerId: null
      }));
      if (!children.length) { setStatus("兩段式至少要有一個子分類，或關閉「兩段式分類」。", true); return; }
    }

    const all = await classifyLoadCategories();
    const idx = all.findIndex((c) => c.id === state.draft.id);
    const saved = {
      id: state.draft.id,
      name: state.draft.name,
      queue: state.draft.queue,
      sortMode: state.draft.sortMode,
      conditions: state.draft.conditions,
      twoStage: state.draft.twoStage,
      children,
      _count: null,
      _layerId: null
    };
    if (idx >= 0) all[idx] = saved; else all.push(saved);
    await classifySaveCategories(all);
    window.close();
  });

  init();
})();
