// app/classify_list.js — 「分單助手」主畫面（分類清單）。
// 移植自 Shopee_Helper/dispatch/classify_list.js，差異：進度訊息 target、編輯頁路徑改為本擴充的。
// 每張卡片就有「查看」「移入暫存區」，不用開別的視窗就能操作。
// 「編輯」只開另一個獨立小視窗（app/classify_edit.html），編輯完存檔後，
// 本頁靠 chrome.storage.onChanged 自動重新整理，不用手動刷新或訊息往返。

(() => {
  const DEFAULT_SOURCE_QUEUE = "未分類";
  // 跟 bridge/page.js 的 HELPER_VERSION 對齊：ERP 分頁裡的引擎是「該分頁載入當下」注入的舊版快照，
  // 重新載入 Chrome 擴充功能不會讓已經開著的 ERP 分頁自動換成新版引擎——只有對那個分頁按 F5 才會。
  // 沒有這個檢查的話，舊引擎收到新設定會看不懂、直接當作沒設定處理，靜默算出錯的筆數。
  const EXPECTED_HELPER_VERSION = 67;

  const state = {
    categories: [],
    busy: false,
    queueCounts: {}, // { 暫存區名稱: 筆數 }，供來源下拉跟卡片「暫存區」那行一起顯示筆數
    lastClassifyDone: 0, // 上次 classifyAll 完成的時間戳；queue-changed 監聽用來避免重覆重算
    unclassifiedCount: null // 上次同步的未分類筆數（null＝還沒同步過，顯示「--」）
  };

  // 未分類：常駐顯示。>0 時做成可點連結（點了在 ERP 顯示未分類訂單）；0 或未同步時顯示純文字。
  function renderUnclassified() {
    if (!els.unclassifiedVal) return;
    const n = state.unclassifiedCount;
    if (n == null) { els.unclassifiedVal.textContent = "--"; return; }
    if (n > 0) {
      els.unclassifiedVal.innerHTML = `<a href="#" class="cls-status-link" data-action="view-unclassified">${n} 筆</a>`;
    } else {
      els.unclassifiedVal.textContent = "0 筆";
    }
  }

  const els = {
    status: document.querySelector("#cls-status"),
    list: document.querySelector("#cls-list"),
    source: document.querySelector("#cls-source"),
    classifyBtn: document.querySelector("#cls-classify"),
    addBtn: document.querySelector("#cls-add"),
    exportBtn: document.querySelector("#cls-export"),
    updateBtn: document.querySelector("#cls-check-update"),
    rulesUpdated: document.querySelector("#cls-rules-updated"),
    unclassifiedVal: document.querySelector("#cls-unclassified-val")
  };

  function setStatus(text, isError = false) {
    els.status.textContent = text;
    els.status.classList.toggle("cls-error", !!isError);
  }

  function setBusy(busy) {
    state.busy = busy;
    els.classifyBtn.disabled = busy;
    els.addBtn.disabled = busy;
    els.source.disabled = busy;
    els.list.querySelectorAll("button").forEach((b) => { b.disabled = busy; });
  }

  function render() {
    if (!state.categories.length) {
      els.list.innerHTML = `<div class="usp-empty">尚未新增任何分類規則，按下面「＋ 新增分類」建立第一條。</div>`;
      return;
    }
    els.list.innerHTML = state.categories.map((cat) => {
      const conds = (cat.conditions || []).map((c) => CLASSIFY_FIELD_DEFS[c.type]?.summary(c) || c.type);
      const condText = conds.length ? conds.join("　") : "（尚未設定條件，會接住全部訂單）";
      const count = cat._count != null ? `${cat._count} 筆` : "--";
      const sortText = cat.sortMode === "stock" ? "依儲位區標籤順序"
        : cat.sortMode === "spec-asc" ? "依規格款數（少到多）"
        : cat.sortMode === "count-desc" ? "依訂單件數（多到少）"
        : cat.sortMode === "freight" ? "依照物流方式"
        : "依建立時間（舊到新）";

      const head = `
        <div class="cls-card-top">
          <span class="cls-card-handle" draggable="true" title="拖曳調整順序" aria-label="拖曳調整「${classifyEscapeAttr(cat.name)}」的順序">⠿</span>
          <span class="cls-card-name">${classifyEscapeHtml(cat.name)}</span>
          <span class="cls-card-count">${count}</span>
        </div>
        <div class="cls-card-cond">${classifyEscapeHtml(condText)}</div>
        <div class="cls-card-cond">排序：${sortText}</div>`;

      if (cat.twoStage) {
        // 兩段式：父層＝一般分類卡；子分類從「父層暫存區」讀取後再分流入暫存。
        // 子分類只有在按過「從父層暫存區讀取」（來源＝父層暫存區）後才有筆數；否則顯示「--」。
        const children = cat.children || [];
        const childrenComputed = children.some((ch) => ch._count != null);
        const childSum = children.reduce((s, ch) => s + Number(ch._count || 0), 0);
        // 「其他」＝父層暫存區總數 − 各子分類；用 fanout 讀到的暫存區總數（cat._fanoutTotal），不是父層在新訂單的數字
        const other = (childrenComputed && cat._fanoutTotal != null) ? Math.max(0, Number(cat._fanoutTotal) - childSum) : null;
        const childRows = children.map((ch) => {
          const cCount = ch._count != null ? `${ch._count} 筆` : "--";
          const qText = ch.queue
            ? `→ ${classifyEscapeHtml(ch.queue)} (${state.queueCounts[ch.queue] ?? 0})`
            : "→ （未設暫存區）";
          return `
          <div class="cls-child" data-child-id="${classifyEscapeAttr(ch.id)}">
            <div class="cls-child-top">
              <span class="cls-child-name">${classifyEscapeHtml(ch.name || "子分類")}</span>
              <span class="cls-child-count">${cCount}</span>
            </div>
            <div class="cls-child-queue">${qText}</div>
            <div class="cls-card-actions">
              <button type="button" class="usp-btn" data-action="view-child">查看</button>
              <button type="button" class="usp-btn" data-action="stage-child">移入暫存區</button>
              <button type="button" class="usp-btn cls-icon-btn" data-action="edit-child" aria-label="編輯這個子分類" title="編輯">✎</button>
              <button type="button" class="usp-btn cls-icon-btn usp-btn-danger" data-action="delete-child" aria-label="刪除這個子分類" title="刪除">✕</button>
            </div>
          </div>`;
        }).join("");
        const otherRow = other && other > 0
          ? `<div class="cls-child cls-child-other">其他（未被子分類接到）：${other} 筆——請檢查是否要補子分類，這批不會自動入庫。</div>`
          : "";
        return `
        <div class="cls-card cls-card-two" data-id="${classifyEscapeHtml(cat.id)}">
          ${head}
          <div class="cls-card-queue">暫存區：${cat.queue
            ? `${classifyEscapeHtml(cat.queue)} (${state.queueCounts[cat.queue] ?? 0})`
            : "（未設定）"}</div>
          <div class="cls-card-actions">
            <button type="button" class="usp-btn" data-action="view">查看</button>
            <button type="button" class="usp-btn" data-action="stage">移入暫存區</button>
            <button type="button" class="usp-btn cls-icon-btn" data-action="edit" aria-label="編輯這個分類" title="編輯">✎</button>
            <button type="button" class="usp-btn cls-icon-btn usp-btn-danger" data-action="delete" aria-label="刪除這個分類" title="刪除">✕</button>
          </div>
          <div class="cls-children">
            <div class="cls-children-head">
              <span class="cls-children-title">分流入暫存</span>
              <button type="button" class="usp-btn usp-btn-sm" data-action="fanout" title="把來源切到父層暫存區，子分類改從那裡讀取再分流">↧ 從父層暫存區讀取</button>
            </div>
            ${(children.length && !childrenComputed) ? `<div class="usp-hint">子分類筆數要先把父層訂單「移入暫存區」，再按上方「↧ 從父層暫存區讀取」才會出現。</div>` : ""}
            ${childRows || `<div class="usp-hint">尚未設定子分類，按「編輯」新增。</div>`}
            ${otherRow}
          </div>
        </div>`;
      }

      return `
      <div class="cls-card" data-id="${classifyEscapeHtml(cat.id)}">
        ${head}
        <div class="cls-card-queue">暫存區：${cat.queue
          ? `${classifyEscapeHtml(cat.queue)} (${state.queueCounts[cat.queue] ?? 0})`
          : "（未設定）"}</div>
        <div class="cls-card-actions">
          <button type="button" class="usp-btn" data-action="view">查看</button>
          <button type="button" class="usp-btn" data-action="stage">移入暫存區</button>
          <button type="button" class="usp-btn cls-icon-btn" data-action="edit" aria-label="編輯這個分類" title="編輯">✎</button>
          <button type="button" class="usp-btn cls-icon-btn usp-btn-danger" data-action="delete" aria-label="刪除這個分類" title="刪除">✕</button>
        </div>
      </div>`;
    }).join("");
  }

  async function refresh() {
    state.categories = await classifyLoadCategories();
    render();
  }

  // ── 線上規則同步（GitHub raw）──
  // 開啟工具時抓管理者放在 GitHub 的規格檔；版本(version，用匯出當下的時間戳)比本機已套用的新就覆蓋，
  // 讓各機自動統一到管理者最新規則。抓不到（離線/網址錯/私庫）就沿用本機，不擋工具。
  const ONLINE_CONFIG_URL = "https://raw.githubusercontent.com/wangjohn1986/fenben-config/main/categories.json";
  const ONLINE_VERSION_KEY = "order_classify_online_version";
  async function syncFromOnline() {
    try {
      const res = await fetch(`${ONLINE_CONFIG_URL}?t=${Date.now()}`, { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      const cats = Array.isArray(data) ? data : (Array.isArray(data?.categories) ? data.categories : null);
      const onlineVer = Number(data?.version || 0);
      if (!Array.isArray(cats) || !(onlineVer > 0)) return;
      const localVer = await new Promise((r) => { try { chrome.storage.local.get(ONLINE_VERSION_KEY, (d) => r(Number(d?.[ONLINE_VERSION_KEY] || 0))); } catch { r(0); } });
      if (onlineVer > localVer) {
        await classifySaveCategories(cats);
        await new Promise((r) => { try { chrome.storage.local.set({ [ONLINE_VERSION_KEY]: onlineVer }, r); } catch { r(); } });
        setStatus("已從線上同步最新分類規則。");
        renderRulesUpdated();
      }
    } catch { /* 離線或抓取失敗 → 沿用本機規則，不影響使用 */ }
  }

  // 抓「分單助手」群組所有暫存區目前的筆數，存進 state.queueCounts（來源下拉、卡片「暫存區」那行共用同一份）
  async function refreshQueueCounts() {
    try {
      const counts = await usaleCallHelper("getQueueCounts", {});
      state.queueCounts = counts?.counts || {};
    } catch {
      // 讀不到就維持原本的數字，不清空（避免畫面數字突然消失）
    }
  }

  // ERP 的暫存區筆數是「最終一致」：剛搬完訂單，馬上查常常還是舊數字。
  // 這裡搬單後改用「等到數字真的變了才罷休」的重試，而不是查一次就相信，避免畫面卡在移入前的舊筆數。
  async function waitForQueueCountChange(queueName, beforeCount, tries = 6, delayMs = 1000) {
    for (let i = 0; i < tries; i += 1) {
      await refreshQueueCounts();
      if (Number(state.queueCounts[queueName] || 0) !== Number(beforeCount || 0)) return true;
      if (i < tries - 1) await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
    return false;
  }

  // 更新下拉選項既有的「(筆數)」文字，不重建整個選單（不會打斷使用者正在操作/已選的值）
  function updateSourceOptionTexts() {
    Array.from(els.source.options).forEach((opt) => {
      if (!opt.value.startsWith("queue:")) return;
      const name = opt.value.slice(6);
      opt.textContent = `${name} (${state.queueCounts[name] ?? 0})`;
    });
  }

  // 訂單來源下拉：「新訂單」＋ ERP「分單助手」群組現有的所有暫存區（只讀，不自動建立）。
  // 若該群組現有「未分類」就預設選它，否則預設「新訂單」。每個選項後面加 (筆數)。
  async function refreshSourceOptions() {
    let queues = [];
    try {
      const res = await usaleCallHelper("getRuleOptions", {});
      queues = (res.queues || []).filter((q) => q.group === CLASSIFY_QUEUE_GROUP).map((q) => q.name).filter(Boolean);
    } catch {
      // 讀不到選項時至少保留「新訂單」可選
    }

    let newOrderCount = null;
    try {
      const info = await usaleCallHelper("refresh", {});
      newOrderCount = Number(info?.total ?? 0);
    } catch { /* 讀不到就先不顯示筆數 */ }
    await refreshQueueCounts();

    const label = (name, count) => count == null ? name : `${name} (${count})`;
    const options = [`<option value="new">${classifyEscapeHtml(label("新訂單", newOrderCount))}</option>`]
      .concat(queues.map((n) => `<option value="queue:${classifyEscapeAttr(n)}">${classifyEscapeHtml(label(n, state.queueCounts[n] ?? 0))}</option>`));
    const wanted = els.source.value || "";
    els.source.innerHTML = options.join("");
    if (wanted && Array.from(els.source.options).some((o) => o.value === wanted)) {
      els.source.value = wanted; // 重新整理選項時保留使用者原本選的來源，不要每次都跳回預設
    } else {
      els.source.value = queues.includes(DEFAULT_SOURCE_QUEUE) ? `queue:${DEFAULT_SOURCE_QUEUE}` : "new";
    }
    render(); // 卡片「暫存區」那行的筆數也跟著更新
  }

  function selectedSource() {
    const raw = String(els.source.value || "new");
    if (raw.startsWith("queue:")) return { type: "queue", name: raw.slice(6) };
    return { type: "new" };
  }

  async function classifyAll() {
    if (state.busy) return;
    if (!state.categories.length) {
      setStatus("尚未新增任何分類規則。", true);
      return;
    }
    const source = selectedSource();
    const sourceLabel = source.type === "queue" ? `暫存區「${source.name}」` : "新訂單";
    setBusy(true);
    setStatus(`讀取${sourceLabel}並同步分類中…`);
    try {
      // 引擎版本握手：ERP 分頁還在跑舊引擎就直接點名要求 F5，不要讓員工對著錯誤的 0 筆猜半天
      try {
        const pong = await usaleCallHelper("ping", {});
        if (Number(pong?.version || 0) < EXPECTED_HELPER_VERSION) {
          setStatus("這個 ERP 分頁還在跑舊版引擎，請「對這個 ERP 分頁」按 F5 重新整理後再按一次「同步訂單」（重新載入擴充功能不會讓已開啟的分頁自動更新引擎）。", true);
          setBusy(false);
          return;
        }
      } catch {
        setStatus("無法確認 ERP 引擎版本，請確認 ec.mallbic.com 分頁已開啟並登入。", true);
        setBusy(false);
        return;
      }
      // 整批同步只算父層/一般卡；兩段式子分類一律清成「--」（子分類改由「從父層暫存區讀取」獨立計算）。
      const { layers, refs } = classifyBuildLayerSpecs(state.categories);
      // independent: true → 每個 layer 各自獨立比對（父層＝整批、子分類＝父層之內再篩），同一筆符合多個就都算
      const res = await usaleCallHelper("classifyByLayers", { layers, limit: 0, source, independent: true });
      (res.layers || []).forEach((ly, i) => {
        const ref = refs[i];
        if (!ref) return;
        const target = ref.child || ref.cat; // 子分類的 id/count 存在子物件上，父層/一般分類存在 cat 上
        target._layerId = ly.id;
        // 筆數一律用 ERP 的「明細列數」(detailCount)，跟 ERP 畫面上那個數字一致；不用「訂單筆數」(count)
        target._count = ly.detailCount ?? ly.count ?? 0;
      });
      await classifySaveCategories(state.categories);
      setStatus(`同步完成（來源：${sourceLabel}）：共 ${res.detailCount ?? "--"} 筆`);
      state.unclassifiedCount = Number(res.unclassified ?? 0); // 未分類改由常駐區顯示（見 renderUnclassified）
      renderUnclassified();
      render();
      // 把這次同步抓到的整批來源資料畫到 ERP 主畫面，讓 ERP 畫面跟這次同步的結果保持一致
      try { await usaleCallHelper("showAllInMainTable", { label: sourceLabel }); } catch { /* 畫面同步失敗不影響分類結果，靜默略過 */ }
      // 這裡要 await，不能背景 fire-and-forget：如果呼叫端（例如 stageCategory）在這之後還有自己的
      // 暫存區筆數重試流程，沒 await 的話兩邊會搶著寫 state.queueCounts，較晚resolve的反而把正確答案蓋掉。
      await refreshSourceOptions();
    } catch (error) {
      setStatus(`同步失敗：${error?.message || "未知錯誤"}`, true);
    } finally {
      setBusy(false);
      state.lastClassifyDone = Date.now(); // 供 queue-changed 監聽判斷「剛剛才重算過就別重覆」
    }
  }

  // 查看：把某個 layer（父層/一般卡＝cat；子分類＝child）畫到 ERP 主畫面。
  // 排序一律用「父層/該卡」的排序設定（子分類沿用父層排序，讓物流子集也照撿貨順序）。
  async function viewLayer(layerId, label, sortCat, fanoutKey) {
    if (!layerId) { setStatus("請先按「同步訂單」再查看。", true); return; }
    setBusy(true);
    try {
      const sortPayload = classifyCategorySortPayload(sortCat);
      // fanoutKey：子分類帶父層暫存區名，讓引擎用該獨立快照槽（不受上層卡片重新同步影響、也不影響上層）
      const res = await usaleCallHelper("showLayerInMainTable", { layerId, label, fanoutKey: fanoutKey || null, ...sortPayload });
      const orderNote = sortPayload.sortMode === "stock" ? "，已依儲位區標籤順序排列"
        : sortPayload.sortMode === "date-asc" ? "，已依建立時間排列（舊到新）"
        : sortPayload.sortMode === "spec-asc" ? "，已依規格款數排列（少到多）"
        : sortPayload.sortMode === "count-desc" ? "，已依訂單件數排列（多到少）"
        : sortPayload.sortMode === "freight" ? "，已依物流方式排列"
        : "";
      setStatus(`已在 ERP 顯示「${label}」（${res.units ?? res.count} 筆）${orderNote}`);
    } catch (error) {
      setStatus(`檢視失敗：${error?.message || "未知錯誤"}`, true);
    } finally {
      setBusy(false);
    }
  }
  function viewCategory(cat) { return viewLayer(cat._layerId, cat.name, cat); }
  function viewChild(cat, child) {
    if (!child._layerId) { setStatus("子分類要先按「↧ 從父層暫存區讀取」才有資料可查看（父層需先把訂單移入暫存區）。", true); return; }
    return viewLayer(child._layerId, `${cat.name}／${child.name || "子分類"}`, cat, cat.queue); // fanoutKey＝父層暫存區名
  }

  // 移入暫存區：父層一般卡與子分類共用。layerId/count/queue/label 由呼叫端帶入。
  // resync：搬完後怎麼重算。一般卡/父層 → classifyAll（重讀新訂單）；子分類 → 重新 fanout（重讀父層暫存區），
  // 這樣移入某個子分類後，其他子分類的數值會保留、被移走的那個變 0，而不是全部清成「--」。
  async function doStage({ layerId, count, queue, label, resync, fanoutKey, sortPayload, persistQueue }) {
    if (!layerId) { setStatus("請先按「同步訂單」再移入暫存區。", true); return; }
    if (!queue) { setStatus("這個分類還沒設定對應暫存區，請按「編輯」設定。", true); return; }

    // 暫存區只讀不建：若選的暫存區已被 ERP 端刪除/改名，跳出「用最新清單重挑」，找不到可取消，不靜默失敗。
    let targetQueue = queue;
    if (!(targetQueue in state.queueCounts)) await refreshQueueCounts(); // 先重抓，排除只是清單過期
    if (!(targetQueue in state.queueCounts)) {
      const groupNames = await loadGroupQueueNames(); // 只挑「分單助手」群組的暫存區
      const picked = await promptRepickQueue(targetQueue, Array.isArray(groupNames) ? groupNames : Object.keys(state.queueCounts));
      if (!picked) return;                        // 取消：不移入、不動任何訂單
      targetQueue = picked;
      if (typeof persistQueue === "function") {   // 寫回卡片並存檔，之後不用再挑
        persistQueue(picked);
        await classifySaveCategories(state.categories);
      }
    }

    if (!window.confirm(`把「${label}」目前分類到的 ${count ?? 0} 筆移入暫存區「${targetQueue}」？`)) return;

    setBusy(true);
    const beforeCount = Number(state.queueCounts[targetQueue] ?? 0);
    let movedCount = 0;
    try {
      const branchId = `${layerId}_b`;
      const res = await usaleCallHelper("stageScopes", { groups: [{ branchId, queueName: targetQueue, label }], fanoutKey: fanoutKey || null });
      // 顯示暫存區時套用排序。儲位排序走 ERP 伺服器端「儲位區資訊」排序（照實際儲位代碼分組，例 O2-01 集中）
      // → 連列印都照著印、不跑掉。（ERP 畫面沒開這欄的排序鈕，但伺服器接受這個 SortText，實測有效。）
      // 其餘排序仍走 client-side（只排畫面）。
      const erpSortText = sortPayload && sortPayload.sortMode === "stock" ? "儲位區資訊" : "";
      await usaleCallHelper("showQueueInMainTable", { queueName: targetQueue, erpSortText, ...(sortPayload || {}) });
      movedCount = res.orders ?? res.moved ?? 0;
    } catch (error) {
      setStatus(`移入暫存區失敗：${error?.message || "未知錯誤"}`, true);
      setBusy(false);
      return;
    }
    setBusy(false); // ★必須在呼叫 classifyAll/resync 前先解除 busy（它們自己管理 busy）

    // 訂單已搬離來源清單，一定要重算：來源筆數與各卡片筆數才會扣掉，而且搬單時引擎把 lastScan 設為 null，
    // 靠這次重算重建快照，之後「查看」才不會報「快照已失效」。
    // 子分類走 resync（重讀父層暫存區）：只更新這張卡的子分類、保留其他子分類數值；一般卡走 classifyAll。
    if (typeof resync === "function") await resync();
    else await classifyAll();

    // 這個暫存區的筆數確認放到最後：背景繼續每 0.4 秒查一次，最多 5 次（約 2 秒）。
    if (movedCount > 0) {
      await waitForQueueCountChange(targetQueue, beforeCount, 5, 400);
      render();
    }
  }
  // 只列「分單助手」群組的暫存區（跟編輯頁/來源下拉一致；state.queueCounts 含所有群組，不能直接用）
  async function loadGroupQueueNames() {
    try {
      const res = await usaleCallHelper("getRuleOptions", {});
      return (res.queues || []).filter((q) => q.group === CLASSIFY_QUEUE_GROUP).map((q) => q.name).filter(Boolean);
    } catch { return null; } // null＝讀取失敗
  }

  // 暫存區找不到時的重挑 modal：回傳選到的暫存區名，或 null（取消）。names＝分單助手群組最新清單。
  function promptRepickQueue(missingName, names) {
    return new Promise((resolve) => {
      const list = Array.isArray(names) ? names : [];
      const overlay = document.createElement("div");
      overlay.className = "usp-modal-overlay";
      overlay.innerHTML = `
        <div class="usp-modal">
          <p class="usp-modal-msg">暫存區「${classifyEscapeHtml(missingName)}」在 ERP 找不到（可能已刪除或改名）。<br>請重新選擇要移入的暫存區：</p>
          <select class="usp-modal-select">
            <option value="">（請選擇）</option>
            ${list.map((n) => `<option value="${classifyEscapeAttr(n)}">${classifyEscapeHtml(n)} (${state.queueCounts[n] ?? 0})</option>`).join("")}
          </select>
          <div class="usp-modal-actions">
            <button type="button" class="usp-btn usp-btn-primary usp-modal-ok">確定移入</button>
            <button type="button" class="usp-btn usp-modal-cancel">取消</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const sel = overlay.querySelector(".usp-modal-select");
      const done = (val) => { overlay.remove(); resolve(val); };
      overlay.querySelector(".usp-modal-ok").addEventListener("click", () => { if (!sel.value) { sel.focus(); return; } done(sel.value); });
      overlay.querySelector(".usp-modal-cancel").addEventListener("click", () => done(null));
      overlay.addEventListener("click", (e) => { if (e.target === overlay) done(null); }); // 點遮罩＝取消
      sel.focus();
    });
  }

  function stageCategory(cat) { return doStage({ layerId: cat._layerId, count: cat._count, queue: cat.queue, label: cat.name, sortPayload: classifyCategorySortPayload(cat), persistQueue: (q) => { cat.queue = q; } }); }
  function stageChild(cat, child) {
    if (!child._layerId) { setStatus("子分類要先按「↧ 從父層暫存區讀取」才能移入（父層需先把訂單移入暫存區）。", true); return; }
    // 移入子分類後重讀父層暫存區（re-fanout），保留其他子分類數值、被移走的變 0。
    // fanoutKey＝父層暫存區名：讓 stageScopes 從 fanout 快照槽讀取要搬的訂單（不受主快照影響）。
    return doStage({
      layerId: child._layerId, count: child._count, queue: child.queue,
      label: `${cat.name}／${child.name || "子分類"}`,
      fanoutKey: cat.queue,
      sortPayload: classifyCategorySortPayload(cat), // 子分類沿用父層排序（列印時暫存區也照這個排）
      resync: () => fanoutFromParentQueue(cat),
      persistQueue: (q) => { child.queue = q; } // 重挑後寫回子分類暫存區
    });
  }

  // 從父層暫存區讀取（獨立操作）：只針對「這張卡」，去父層暫存區把它的子分類算出來。
  // 刻意「不」動最上面的來源下拉、也「不」重算其他卡片——這張兩段式卡就是獨立區域。
  // 做法：另開一次 classifyByLayers，來源＝父層暫存區、layers 只含這張卡的子分類條件，只回填這張卡的子分類。
  // 注意：引擎一次只留一份快照，這次讀取後快照會變成「父層暫存區」的——所以之後子分類的查看/移入可用；
  //       但其他卡片/父層的查看/移入要等下次「同步訂單」才會恢復（數字仍留著、只是快照換了）。
  async function fanoutFromParentQueue(cat) {
    if (state.busy) return;
    if (!cat.queue) {
      setStatus("這張卡還沒設定父層暫存區。請先按「編輯」設定父層暫存區，並把訂單「移入暫存區」，再讀取。", true);
      return;
    }
    const children = cat.children || [];
    if (!children.length) { setStatus("這張卡還沒有子分類，請按「編輯」新增。", true); return; }

    setBusy(true);
    setStatus(`從父層暫存區「${cat.queue}」讀取「${cat.name}」的子分類…`);
    try {
      const pong = await usaleCallHelper("ping", {});
      if (Number(pong?.version || 0) < EXPECTED_HELPER_VERSION) {
        setStatus("這個 ERP 分頁還在跑舊版引擎，請「對這個 ERP 分頁」按 F5 後再試。", true);
        setBusy(false);
        return;
      }
      // 來源已是父層暫存區（都是跨區），子分類只要用「子分類自己的條件」（物流）即可
      const layers = children.map((ch) =>
        classifyCategoryToLayerPayload({ name: `${cat.name}／${ch.name || "子分類"}`, conditions: ch.conditions })
      );
      const res = await usaleCallHelper("classifyByLayers", {
        layers, limit: 0, source: { type: "queue", name: cat.queue }, independent: true,
        fanoutKey: cat.queue // 存進獨立快照槽，不蓋掉主快照 lastScan（上層卡片查看/移入仍可用）
      });
      (res.layers || []).forEach((ly, i) => {
        const ch = children[i];
        if (!ch) return;
        ch._layerId = ly.id;
        ch._count = ly.detailCount ?? ly.count ?? 0;
      });
      cat._fanoutTotal = Number(res.detailCount ?? 0); // 暫存區總明細列數，供「其他」＝總數−Σ子分類
      await classifySaveCategories(state.categories);
      await refreshQueueCounts();
      render();
      setStatus(`已讀取「${cat.name}」子分類（父層暫存區「${cat.queue}」共 ${res.detailCount ?? "--"} 筆）。`);
    } catch (error) {
      setStatus(`從父層暫存區讀取失敗：${error?.message || "未知錯誤"}`, true);
    } finally {
      setBusy(false);
      // 標記「剛剛才重算過」：讓 queue-changed 監聽跳過它的 classifyAll（否則移入子分類觸發的 queue-changed
      // 會在 ~600ms 後 classifyAll，把剛 re-fanout 好的子分類數值又清成「--」）。
      state.lastClassifyDone = Date.now();
    }
  }

  function openEdit(id) {
    const url = chrome.runtime.getURL(`app/classify_edit.html?id=${encodeURIComponent(id)}`);
    classifyOpenWindow(url, 640, 720);
  }

  async function deleteCategory(id) {
    const cat = state.categories.find((c) => c.id === id);
    if (!cat) return;
    if (!window.confirm(`刪除分類「${cat.name}」？（只是刪除這裡的規則，不影響 ERP 暫存區本身）`)) return;
    state.categories = state.categories.filter((c) => c.id !== id);
    await classifySaveCategories(state.categories);
    render();
  }

  async function deleteChild(cat, child) {
    if (!window.confirm(`刪除子分類「${child.name || "子分類"}」？（只刪這裡的規則，不影響 ERP 暫存區本身）`)) return;
    cat.children = (cat.children || []).filter((c) => c.id !== child.id);
    await classifySaveCategories(state.categories);
    render();
  }

  // ── 匯出規則檔（管理者用）──
  // 匯出後改名成 categories.json 上傳到 GitHub 覆蓋 → 員工端靠線上同步自動更新（匯入已由線上同步取代而移除）。
  function exportCategories() {
    try {
      const stamp = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      const dateStr = `${stamp.getFullYear()}${pad(stamp.getMonth() + 1)}${pad(stamp.getDate())}_${pad(stamp.getHours())}${pad(stamp.getMinutes())}`;
      // version＝匯出當下時間戳（單調遞增）：上傳到 GitHub 後，較新的版本會自動蓋過各機舊版
      const payload = { _type: "order_classify_categories", version: stamp.getTime(), exportedAt: stamp.toISOString(), count: state.categories.length, categories: state.categories };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `分單助手規格_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setStatus(`已匯出 ${state.categories.length} 張分類規格檔（下載資料夾）。`);
    } catch (error) {
      setStatus(`匯出失敗：${error?.message || error}`, true);
    }
  }

  // 顯示「規則更新時間」：值來自線上同步版本 order_classify_online_version（＝規則匯出當下的時間戳），
  // 讓使用者一眼知道目前規則同步到哪一版；沒同步過（內建預設/離線首裝）則標示內建預設。
  function renderRulesUpdated() {
    if (!els.rulesUpdated) return;
    try {
      chrome.storage.local.get(ONLINE_VERSION_KEY, (d) => {
        const v = Number(d?.[ONLINE_VERSION_KEY] || 0);
        if (v > 0) {
          const dt = new Date(v);
          const pad = (n) => String(n).padStart(2, "0");
          els.rulesUpdated.textContent = `規則更新時間：${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
        } else {
          els.rulesUpdated.textContent = "規則更新時間：內建預設（尚未線上同步）";
        }
      });
    } catch { /* ignore */ }
  }

  // ── 檢查更新（程式碼版本）──
  // 比對 GitHub 上的 version.json 與目前 manifest 版本；有新版就一鍵開下載頁。
  // 註：未封裝擴充無法自我覆蓋，下載後仍需解壓覆蓋資料夾＋chrome://extensions 重新整理（或用「更新.bat」）。
  const UPDATE_VERSION_URL = "https://raw.githubusercontent.com/wangjohn1986/fenben-helper/main/version.json";
  function isNewerVersion(a, b) {
    const pa = String(a || "").split("."), pb = String(b || "").split(".");
    for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
      const x = Number(pa[i] || 0), y = Number(pb[i] || 0);
      if (x > y) return true;
      if (x < y) return false;
    }
    return false;
  }
  async function checkForUpdate() {
    setStatus("正在檢查更新…");
    try {
      const res = await fetch(`${UPDATE_VERSION_URL}?t=${Date.now()}`, { cache: "no-store" });
      if (!res.ok) throw new Error("讀取版本資訊失敗");
      const info = await res.json();
      const latest = String(info?.version || "");
      const current = chrome.runtime.getManifest().version;
      if (!latest) throw new Error("版本資訊格式不正確");
      if (isNewerVersion(latest, current)) {
        const notes = info?.notes ? `\n更新內容：${info.notes}` : "";
        if (window.confirm(`有新版本 v${latest}（目前 v${current}）。${notes}\n\n要開啟下載頁嗎？下載後解壓覆蓋原本資料夾，再到 chrome://extensions 對「分單助手」按「重新整理」即可。`)) {
          window.open(info?.url || "https://github.com/wangjohn1986/fenben-helper/releases/latest", "_blank");
        }
        setStatus(`有新版本 v${latest}（目前 v${current}）。`);
      } else {
        setStatus(`已是最新版（v${current}）。`);
      }
    } catch (e) {
      setStatus(`檢查更新失敗：${e?.message || e}（請確認網路，或稍後再試）`, true);
    }
  }

  els.classifyBtn.addEventListener("click", classifyAll);
  els.addBtn.addEventListener("click", () => openEdit("new"));
  els.exportBtn?.addEventListener("click", exportCategories);
  els.updateBtn?.addEventListener("click", checkForUpdate);

  // 點常駐「未分類 N 筆」連結 → 在 ERP 顯示未分類訂單（layerId=__rest 是引擎存的未分類明細清單）
  document.querySelector("#cls-unclassified")?.addEventListener("click", (event) => {
    const link = event.target.closest('[data-action="view-unclassified"]');
    if (!link) return;
    event.preventDefault();
    viewLayer("__rest", "未分類", {});
  });

  els.list.addEventListener("click", (event) => {
    const node = event.target.closest("[data-action]");
    if (!node) return;
    const card = node.closest(".cls-card");
    const id = card?.dataset.id;
    const cat = state.categories.find((c) => c.id === id);
    if (!cat) return;
    const action = node.dataset.action;
    if (action === "view") viewCategory(cat);
    else if (action === "stage") stageCategory(cat);
    else if (action === "edit") openEdit(cat.id);
    else if (action === "delete") deleteCategory(cat.id);
    else if (action === "fanout") fanoutFromParentQueue(cat);
    else if (action === "view-child" || action === "stage-child" || action === "edit-child" || action === "delete-child") {
      const childId = node.closest(".cls-child")?.dataset.childId;
      const child = (cat.children || []).find((c) => c.id === childId);
      if (!child) return;
      if (action === "view-child") viewChild(cat, child);
      else if (action === "stage-child") stageChild(cat, child);
      else if (action === "edit-child") openEdit(cat.id); // 子分類在父層的編輯頁裡編輯
      else if (action === "delete-child") deleteChild(cat, child);
    }
  });

  // 分類卡片拖曳排序（用左上角的 ⠿ 把手）：由上往下第一個符合的分類接住，順序會影響分類結果，
  // 拖完立刻存檔，主畫面按「同步訂單」會照新順序重新分類。
  let dragCardId = null;
  els.list.addEventListener("dragstart", (event) => {
    const handle = event.target.closest(".cls-card-handle");
    if (!handle) return;
    dragCardId = handle.closest(".cls-card")?.dataset.id || null;
    event.dataTransfer.effectAllowed = "move";
  });
  els.list.addEventListener("dragover", (event) => {
    if (dragCardId && event.target.closest(".cls-card")) event.preventDefault();
  });
  els.list.addEventListener("drop", async (event) => {
    const targetCard = event.target.closest(".cls-card");
    if (!targetCard || !dragCardId) return;
    event.preventDefault();
    const targetId = targetCard.dataset.id;
    const fromIdx = state.categories.findIndex((c) => c.id === dragCardId);
    const toIdx = state.categories.findIndex((c) => c.id === targetId);
    dragCardId = null;
    if (fromIdx < 0 || toIdx < 0 || fromIdx === toIdx) return;
    const [moved] = state.categories.splice(fromIdx, 1);
    state.categories.splice(toIdx, 0, moved);
    render();
    await classifySaveCategories(state.categories);
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[CLASSIFY_STORAGE_KEY]) refresh();
  });

  // 暫存區有變動（移入/移出）就「全自動重新分類」：bridge/page.js 掛了鉤子，只要有人（在 ERP 手動置入/移出、
  // 或我們自己的工具搬單）呼叫到 ERP 原生的置入/移出暫存區 API，就會廣播 queue-changed 訊息。
  // 依使用者要求：偵測到就即時重算，讓各卡片數字互扣（移入）/互加（移出）。
  //   ⚠️ classifyAll 會重讀新訂單（ensureNewOrderTab），若當下在別的 ERP 頁面會被切回新訂單頁——這是「全自動」的代價，使用者已同意。
  //   防重覆：我們自己移入時 doStage 已經重算過，這裡若偵測到「剛剛(1.2 秒內)才重算過」或正忙就跳過重算，只輕量刷新暫存區數字。
  let queueChangeTimer = null;
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.target !== "order-classify-progress" || message.action !== "queue-changed") return;
    window.clearTimeout(queueChangeTimer);
    queueChangeTimer = window.setTimeout(async () => {
      if (state.busy || Date.now() - (state.lastClassifyDone || 0) < 1200) {
        // 剛剛才重算過（例如自己移入）或正在忙 → 不重覆重算，只把暫存區數字更新一下
        await refreshQueueCounts();
        updateSourceOptionTexts();
        render();
        return;
      }
      await classifyAll(); // 重讀新訂單 → 更新所有卡片數字（移出互加/移入互扣）＋刷新暫存區數字
    }, 600);
  });

  // 背景定期刷新暫存區筆數（queue-changed 即時通知之外的保險網）。
  // 注意：不能在這裡背景呼叫 "refresh" 動作——它會強制把 ERP 切回「新訂單」分頁（ensureNewOrderTab），
  // 如果使用者正在 ERP 看別的頁面（例如已出貨、統計報表），每 15 秒就會被打斷跳回去，體驗很差。
  // 「新訂單」筆數只在使用者主動按「同步訂單」時才更新；這裡背景只做不需要切頁的暫存區筆數。
  async function refreshLiveCountsOnly() {
    await refreshQueueCounts();
    updateSourceOptionTexts();
    render();
  }
  window.setInterval(() => { if (!state.busy) refreshLiveCountsOnly(); }, 15000);

  (async () => {
    await syncFromOnline();   // 開啟時先從 GitHub 同步規則（版本較新才覆蓋），再載入
    await refresh();
    refreshSourceOptions();
    renderRulesUpdated();     // 顯示目前規則的更新時間
  })();
})();
