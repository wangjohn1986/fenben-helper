// OrderClassify/background.js — service worker。
// 唯一職責：點擴充圖示 → 開（或聚焦）分類主視窗。視窗唯一化比照
// Shopee_Helper 分單作業既有做法：同 URL 已開著就聚焦，不重複開。
const APP_URL = chrome.runtime.getURL("app/classify_list.html");

chrome.action.onClicked.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: APP_URL });
  const existing = tabs && tabs[0];
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
    return;
  }
  // service worker 沒有 window.screen，用固定尺寸置中交給系統
  await chrome.windows.create({ url: APP_URL, type: "popup", width: 720, height: 760 });
});

// ── 擴充圖示右鍵選單：「🔄 重新載入」──
// contexts:["action"] 會把選項掛到「擴充圖示自己的右鍵選單」（就是圖示右鍵那張清單）。
// 點了呼叫 chrome.runtime.reload() 重載整個擴充，等同 chrome://extensions 那顆 ↻，改完檔案免進設定頁。
const RELOAD_MENU_ID = "order-classify-reload";

// service worker 每次啟動都重建選單：直接在頂層呼叫，因為 chrome.runtime.reload() 重載後
// onInstalled/onStartup 都「不會」觸發——只掛在那兩個事件的話，用一次「重新載入」選單就消失了。
// 頂層在「安裝、瀏覽器啟動、事件喚醒、reload 之後」每次 SW 啟動都會跑；先 removeAll 再建，冪等不重複。
function setupMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create(
      { id: RELOAD_MENU_ID, title: "🔄 重新載入", contexts: ["action"] },
      () => void chrome.runtime.lastError
    );
  });
}
setupMenus();

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === RELOAD_MENU_ID) chrome.runtime.reload();
});
