// OrderClassify/bridge/content.js — isolated world 橋接。
// 作法沿用 Shopee_Helper/dispatch/content.js：content-script 直接 fetch 會被 mallbic WAF 擋 403，
// 所以這裡只負責把 UI 視窗的請求（chrome.runtime 訊息）轉成 window.postMessage 丟給
// MAIN world 的 bridge/page.js 引擎，再把回應接力回去。
// 訊息型別/識別字串都用 ORDER_CLASSIFY 前綴，與蝦皮助手（USALE_LOCAL 前綴）可同時安裝互不干擾。
(() => {
  if (window !== window.top) return;

  const MARK_ID = "orderClassifyHelperReady";
  const SCRIPT_ID = "order-classify-page-helper-script";
  const REQUEST_TYPE = "ORDER_CLASSIFY_HELPER_REQUEST";
  const RESPONSE_TYPE = "ORDER_CLASSIFY_HELPER_RESPONSE";
  const PROGRESS_TYPE = "ORDER_CLASSIFY_HELPER_PROGRESS";
  const pending = new Map();

  // 擴充重載後，已注入頁面的舊 content script 會變成「孤兒」：它的擴充 context 失效，
  // 一呼叫 chrome.* 就丟 "Extension context invalidated"（而且是同步 throw，接不到 .catch）。
  // 這個 helper 判斷 context 還在不在，孤兒就別再呼叫。
  const extAlive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };

  function markReady() {
    if (document.documentElement.dataset[MARK_ID]) return;
    document.documentElement.dataset[MARK_ID] = "1";
  }

  function injectPageHelper() {
    if (document.getElementById(SCRIPT_ID)) return;
    const script = document.createElement("script");
    script.id = SCRIPT_ID;
    script.src = chrome.runtime.getURL("bridge/page.js");
    script.async = false;
    (document.documentElement || document.head || document.body).appendChild(script);
  }

  function callPageHelper(action, payload = {}) {
    return new Promise((resolve, reject) => {
      const requestId = `oc-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const timeoutId = window.setTimeout(() => {
        pending.delete(requestId);
        reject(new Error("OrderClassify page helper timeout."));
      }, 180000);

      pending.set(requestId, { resolve, reject, timeoutId });
      window.postMessage({ type: REQUEST_TYPE, requestId, action, payload }, "*");
    });
  }

  // 具名監聽器：偵測到孤兒（擴充已重載）就把自己移除，讓舊腳本徹底停止反應、不再有任何機會丟例外。
  function onPageMessage(event) {
    if (event.source !== window) return;
    // 擴充已重載 → 這支是孤兒：移除監聽器後就地退場（不 sendMessage、不再處理任何訊息）
    if (!extAlive()) { window.removeEventListener("message", onPageMessage); return; }
    const data = event.data;
    if (data?.type === PROGRESS_TYPE) {
      try {
        chrome.runtime.sendMessage({
          target: "order-classify-progress",
          action: data.action || "",
          step: data.step || "",
          detail: data.detail || "",
          at: data.at || Date.now()
        }).catch(() => {}); // 非同步失敗忽略
      } catch { window.removeEventListener("message", onPageMessage); } // 同步 throw＝剛失效 → 移除自己
      return;
    }

    if (!data || data.type !== RESPONSE_TYPE || !data.requestId) return;

    const item = pending.get(data.requestId);
    if (!item) return;

    window.clearTimeout(item.timeoutId);
    pending.delete(data.requestId);

    if (data.ok) {
      item.resolve(data.result);
      return;
    }

    item.reject(new Error(data.message || "OrderClassify page helper failed."));
  }
  window.addEventListener("message", onPageMessage);

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || message.target !== "order-classify-page-helper") return false;

    callPageHelper(message.action, message.payload || {})
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, message: error.message || "OrderClassify page helper failed." }));

    return true;
  });

  injectPageHelper();
  markReady();
})();
