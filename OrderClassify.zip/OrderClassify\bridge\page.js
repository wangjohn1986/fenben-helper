// OrderClassify/bridge/page.js — 分單助手的 MAIN world 引擎。
// 這顆引擎完整沿用 Shopee_Helper/dispatch/page.js（HELPER_VERSION 40，實戰驗證版），
// 只改了守衛旗標與 postMessage 訊息型別，讓本擴充與蝦皮助手可以同時安裝、
// 各自注入各自的引擎而不互相搶訊息。改引擎行為時請兩邊同步維護。
(() => {
  if (window.__ORDER_CLASSIFY_PAGE_HELPER__) return;
  window.__ORDER_CLASSIFY_PAGE_HELPER__ = true;

  // 引擎版本：每次改 page.js 行為時 +1（popup 會核對，不合就提示該分頁按 F5）
  // v10：scanByConfig 支援 options.limit（配單數量上限）＋ 每層回傳 txns（交易序號清單）
  // v11：downloadOrders 支援 payload.repaint（下載後重繪 ERP 主畫面，兩邊明細數一致）
  // v12：新增 classifyByLayers（UI 分層條件即時轉 ERP 代碼驅動分類）
  // v13：goods 條件支援（品項條碼 GoodUID／商品編號 GoodKey.ID 比對），可用商品編號/條碼驅動分類
  // v14：classifyByLayers 支援 shop 條件（蝦皮店鋪 0/1/2 號店 = TxnShopId）
  // v15：layerPoolCounts（獨立池數）＋ pullLayerBatch（撈批：排除/日期/排序/取N）＋ showTxnsInMainTable
  // v16：pullLayerBatch 支援「完整 config＋layerId」first-match 撈批（避免單層掃忽略高優先層先佔、與分類數對齊）
  // v17：撈批快取重用——同步剛算過的 lastScan（規則相同、5 分鐘內）直接拿來切批，免重掃，大幅加速「全部撈取」
  // v18：listStageQueues（列暫存區清單含群組）＋ stageTxnsToQueue（依交易序號置入暫存區，供批次卡「置入暫存區」）
  // v19：撈批/查看的 ERP 標題改為「(訂單 X / 明細 Y)」格式
  // v20：pullLayerBatch 支援精確時間截點 beforeTs（訂單成立時間 ≤ 截點）
  // v21：新增 amount 條件（訂單金額／商品總計區間比對，供 classifyByLayers 的 amountMin/amountMax 使用）
  // v22：renderLayerInMainTable 支援 payload.stockOrder（依儲位區標籤順序排序查看／列印的訂單列）
  // v23：classifyByLayers 支援 payload.source（讀新訂單或改讀指定暫存區，供「同步訂單」來源選擇用）
  // v24：uiLayersToEngineConfig 的 stock 條件改吃 L.stockMode（"all"＝只能是這些儲位；"any"＝至少一項符合），不再寫死 any
  // v25：readAllQueueReasons 依 ReasonOrderIdx 排序，暫存區清單/下拉順序跟 ERP 畫面一致
  // v26：classifyByLayers 支援 payload.independent（各層獨立比對、不 first-match，同一筆訂單可同時算進多層）
  // v27：修正 independent 模式下 ensureStockData 只抓「未被接走」訂單的儲位資料，導致已被其他層算過的
  //      訂單在後面用到 stock 條件的層永遠查無儲位資料、比對不到（漏單）的 bug
  // v28：stock 條件新增 stockMode "single"（訂單所有商品都要在同一個儲位區，且該區要在清單內，不能跨區）
  // v29：stockMode "single" 改用標籤前綴分組判斷同區/跨區（不是拿儲位代碼完全相等比較），
  //      這樣只打一個「2」標籤就能把 21/22 視為同一個大區
  // v30：stageScopes 搬單後偵測暫存區排序（ReasonOrderIdx）是否被 ERP 改動，有變動就還原回搬單前的位置
  // v31：新增 showAllInMainTable，把「同步訂單」整批來源資料畫到 ERP 主畫面，跟同步結果保持一致
  // v32：renderLayerInMainTable 改吃 payload.sortMode（"stock"／"date-asc"），支援依建立時間排序
  // v33：stock 條件標籤支援「+」合併多個前綴成同一組（例如 H1+H2），單區模式判斷同區時一併套用
  // v34：renderLayerInMainTable 新增 sortMode "freight"（依 ERP 配送下拉順序排序）
  // v35：修正 buildFreightOrderMap 沒有合併「[代收]」變體，導致同一家物流的代碼名次不同、排序時被拆散
  // v36：stock 條件新增 stockMode "cross"（跟 "single" 完全相反，專門接「單區」漏掉的跨區/清單外訂單）
  // v37：stockMode "cross" 改成自動判斷（開頭字元分區偵測跨區），不用再手動複製一份一樣的儲位標籤清單
  // v38：修正 queryTxnStockAreaList 只要批次回應「非空」就直接採用的問題──改成要「這批筆數齊全」才採用，
  //      不齊就重試，最多 3 次；解決少數訂單穩定查不到儲位資料、被誤判成沒有儲位資訊的狀況
  // v39：暫時加入診斷 log（鎖定 TxnNumber 11346509），比對 GetTxnStockAreaList 跟 row 本身欄位的資料差異，
  //      問題排除後要整段刪掉
  // v40：修正「跨區」模式被 matchValues 開頭的「空值清單＝不符合」通用防呆擋住、永遠 0 筆的 bug
  //     （跨區的標籤清單本來就是空的，改成在該防呆之前先處理）
  // v41：sortRowsByStockOrder 加入第二層排序鍵——同一標籤內（例如都在 HA）再依「完整儲位代碼」
  //     自然排序（HA3→HA7、HA3-1L→HA3-1R），原本只排到標籤前綴、同標籤內不再細分
  // v42：修正 sortRowsByStockOrder 對「H1+H2」這類合併標籤 startsWith 比對永遠 false、
  //     導致該區被當「沒命中」排到最後（置底）的 bug——改成拆 '+' 子前綴、命中任一即算命中
  // v43：renderLayerInMainTable 新增排序方式 "spec-asc"（依規格款數 OrderSpecCount 少到多，以訂單為單位）
  // v44：畫到 ERP 主畫面時的標籤數字（同步全部／查看層／查看暫存區）一律用「明細列數」而非訂單數，
  //     跟 ERP 原生「全部(N)」一致（不再出現同步後 611 vs ERP 911 的落差）
  // v45：跨區自動判斷的分區鍵改良——「字母+字母」代碼(HA/HB/HC/HD 重架區)歸同一區，
  //     讓 H1(一般) 與 HA(重架) 判為不同區＝跨區；HA/HB/HC/HD 彼此、H1/H2、21/22 仍同區
  // v46：renderLayerInMainTable 新增排序方式 "count-desc"（依訂單件數 OrderCount 多到少，以訂單為單位）
  // v47：商品/SKU 條件新增配對模式 goodsMode（any 任一符合／all 只能是這些／single 單品訂單），比照儲位區的多選配置
  // v48：「從父層暫存區讀取」(fanout) 改用獨立快照槽 fanoutScans（key＝父層暫存區名），不再蓋掉主快照 lastScan，
  //     讓 fanout 後上層卡片的查看/移入仍可用；查看/移入子分類時帶 fanoutKey 走該槽。搬單時主槽＋fanout 槽一起清。
  // v49：排序抽成共用 sortRowsForDisplay；showQueueInMainTable 支援 sortMode/stockOrder，
  //     讓「移入暫存區」後的暫存區畫面（及列印）照卡片選的排序（儲位/規格款數…），不再是 ERP 預設建立日期。
  // v50：showQueueInMainTable 支援 erpSortText，走 ERP server-side 排序（儲位排序用 SortText='儲位區資訊'，
  //     照實際儲位代碼分組），由伺服器排序 → 撐得到列印不跑掉。（ERP UI 沒開此欄排序鈕，但伺服器接受，實測有效）
  // v51：注入「訂單排序」工具列按鈕（置入暫存區後面）＋下拉「按儲存區排序(1-Z)」——依每張單最小儲位自然排序重畫目前檢視。
  // v52：修正——注入到「每一個」有置入暫存區的工具列(新訂單/各暫存區各有獨立 main-tbox)，之前只掛第一個(隱藏的)。
  // v53：下拉選單改掛 body＋fixed 定位(不被裁切)；排序加可見 toast 提示(成功/失敗都跳訊息，不再靜默)。
  // v54：出貨列印攔截——攔 GetPrintTxnInfo/GetPrintDetail，把請求 aKeyList 與回應清單依「訂單排序」快取的儲位順序重排，讓出貨單/條碼單照儲位印出(需先按訂單排序)。
  // v55：訂單排序後自動全選(input.chk_all_msg)，使用者不用手動勾選即可直接出貨列印。
  // v56：移除自動全選(使用者不要顯示勾勾)——不勾選印全部時列印一樣會呼叫 GetPrintTxnInfo/GetPrintDetail，攔截照樣重排。
  // v57：訂單排序按鈕改樣式——文字「🔢 排單順序 (分單助手)」、拿掉三角形、品牌藍底白字。
  // v58：按鈕固定置底(每次巡檢釘回置入暫存區後面、不再亂跑)、改自訂 class 避免 ERP 重排、文字只留「排單順序」(去 emoji/品牌字)。
  // v59：按鈕改用 MutationObserver 即時釘在工具列「最後一個位置」(置底)、ERP 重繪一改就立刻拉回；首次多跑幾次讓它盡快出現(不再等 3 秒)；共用單一下拉選單避免洩漏。
  // v60：排序完成提示改為「請勾選訂單後再出貨列印才會照此順序」(拿掉筆數、修正誤導文案)，並顯示 6 秒。
  // v61：排序後自動全選(input.chk_all_msg)，使用者不用手動勾選即可直接出貨列印；提示改為「已排序並自動全選，可直接出貨列印」。
  // v62：修正自動全選抓錯元素(改用訂單格線表頭 #chk_select_all)；提示改到螢幕正中央、顯示 3 秒後淡出。
  // v63：排序後改「每批 100 筆」呈現(一頁超過 100 筆列印會爆圖)；超過 100 筆時顯示分批面板(上一批/下一批)，每批自動全選，一批一批印。
  // v64：分批面板縮小、移到螢幕底部置中(避開 ERP 上方導覽列被遮擋)；停用的批次按鈕加 pointer-events:none。
  // v65：分批面板加 ✕ 手動關閉；切換檢視/暫存區時(偵測非自身觸發的 GetOrderListByViewOption)自動關閉面板並清除排序狀態。
  // v66：上線前清理——移除未使用的死碼(condSummary/invalidateQueueReasonCache/moveOutOrdersFromQueue/moveOutQueuesEntirely/renderBatchInMainTable/armHeaderSelfHeal/syncHeaderDropdowns/waitQueueNameInErp 及 lastPaint 機制)，行為不變。
  // v67：新增「規格款數」條件(scanByConfig field=spec 比對 OrderSpecCount 區間；uiLayersToEngineConfig 讀 specMin/specMax)。UI 端在 classify_common.js。
  const HELPER_VERSION = 67;

  const REQUEST_TYPE = "ORDER_CLASSIFY_HELPER_REQUEST";
  const RESPONSE_TYPE = "ORDER_CLASSIFY_HELPER_RESPONSE";
  const PROGRESS_TYPE = "ORDER_CLASSIFY_HELPER_PROGRESS";
  // 最近一次分類的結果快取：layerKeys = { layer1: [rowKey...], ... }
  // 供「點某一層 → 在 ERP 主畫面只顯示那幾筆」使用，避免每次點都重跑整個分類。
  let lastScan = null;
  // 兩段式「從父層暫存區讀取」(fanout) 用的獨立快照槽，key＝父層暫存區名稱。
  // 這樣 fanout 不會蓋掉主快照 lastScan（新訂單那份），上層卡片的查看/移入才不會因為 fanout 而失效。
  // 任何搬單（移入/移出）都會把主快照與這裡一起清掉（資料變了），靠下一次分類/fanout 重建。
  const fanoutScans = new Map();
  // 分單助手（測試版）：①下載的訂單快照（②就從這批篩選）；②最近一次篩選結果（送暫存區用）
  let lastDownload = null;
  let lastFilter = null;
  let lastT3 = null; // ③分類：最近一次分類結果 { sourceQueue, perLayer:{layerId:[TxnKey...]}, at }

  function findOrderFrameWindow() {
    const directMatch = /Order_Entry/.test(location.href) || window.m_TabMgnt?.getCurrentTab?.()?.m_order_view_option;
    if (directMatch) return window;

    const frame = document.querySelector("#inner_frame_1");
    const frameWindow = frame?.contentWindow;
    if (frameWindow?.m_TabMgnt?.getCurrentTab?.()?.m_order_view_option) return frameWindow;
    return null;
  }

  function cloneNewOrderOption(sourceOption) {
    const option = JSON.parse(JSON.stringify(sourceOption));
    option.Status = 0;
    option.CurrentPgNo = 0;
    option.FilterText = "";
    option.SortText = "";
    option.SortExcludeText = "";
    option.FilterFlag = "";
    option.FilterExcludeFlag = "";
    option.FilterArgs = [];
    option.TabListFilter = [];
    option.AmountFilter = null;
    option.SrchText = "";
    option.QueueReasonId = -1;
    option.PackagingAreaId = -1;
    return option;
  }

  // 暫存區檢視的查詢選項：Status=-1（暫存模式）＋ QueueReasonId 指定哪個暫存區（ERP 用字串）。
  // 與 ERP 右上角「暫存區」檢視送出的選項一致（實機攔截確認）。
  function cloneQueueViewOption(sourceOption, reasonId) {
    const option = cloneNewOrderOption(sourceOption);
    option.Status = -1;
    option.QueueReasonId = String(reasonId);
    return option;
  }

  // 「同步訂單」的訂單來源：預設新訂單分頁，也可以指定改讀某個暫存區（例如「分單助手」群組的「未分類」）。
  // source 沒給／type 不是 "queue" → 走原本的新訂單查詢；否則找該暫存區 ReasonID，改用暫存區查詢選項。
  async function resolveScanBaseOption(pageWindow, currentTab, source) {
    const raw = currentTab.m_order_view_option;
    if (!source || source.type !== "queue" || !source.name) {
      return { option: cloneNewOrderOption(raw) };
    }
    const settingWin = findQueueSettingWindow() || pageWindow;
    const su = settingWin?.Mallbic?.U?.Sale?.Ajax?.SettingUtil;
    if (!su?.GetAllQueueReason) return { option: null, error: "USale 暫存區 API 不可用。" };
    const map = await loadQueueReasonMap(su);
    const reasonId = map.get(String(source.name));
    if (reasonId === undefined) return { option: null, error: `找不到暫存區「${source.name}」。` };
    return { option: cloneQueueViewOption(raw, reasonId) };
  }

  function normalizeRows(listData) {
    if (Array.isArray(listData)) return listData;
    if (!listData || typeof listData !== "object") return [];
    if (Array.isArray(listData.rows)) return listData.rows;
    if (Array.isArray(listData.values)) return listData.values;
    return Object.values(listData).filter((item) => item && typeof item === "object");
  }

  function buildRowKey(row, index) {
    // 同一交易序號可能拆成多個出貨單位（TxnPart/TxnShopId 不同、各有獨立 TxnKey），
    // 必須用 TxnKeyStr 當 key。若用交易序號去重，匯入時只會送出第一個單位的 TxnKey，
    // 同交易的其他單位明細會被留在新訂單（實測 1180→509→401 像剝洋蔥）。
    return row?.TxnKeyStr || [
      row?.TxnNumber,
      row?.TxnNum,
      row?.OrderNumber,
      row?.OrderNo,
      row?.TxnPart,
      row?.TxnSys,
      row?.TxnShopId
    ]
      .filter((value) => value !== undefined && value !== null && value !== "")
      .join("|") ||
      JSON.stringify(row?.OrderList?.[0] || row || index);
  }

  function rowsToKeyMap(rows) {
    return normalizeRows(rows).reduce((map, row, index) => {
      const key = buildRowKey(row, index);
      if (!map.has(key)) map.set(key, row);
      return map;
    }, new Map());
  }

  // ③分類：從訂單明細列取「品項條碼」。實測 USALE：品項條碼＝GoodUID（如 "B321-B04"），商品編號＝GoodKey.ID（如 "B321"）。
  function itemCode(it) {
    if (!it || typeof it !== "object") return "";
    const v = it.GoodUID ?? it.GoodKey?.ID ?? it.GoodSN ?? it.GoodNumber ?? it.GoodCode ?? it.Barcode ?? "";
    return String(v || "").trim().toUpperCase();
  }
  // 條碼 code（如 B022-001）是否符合使用者輸入清單（可為商品編號 B022 或完整品項條碼 B022-001）
  function goodsMatch(code, list) {
    const pfx = code.split("-")[0];
    return list.some((v) => v === code || v === pfx || code.startsWith(v + "-"));
  }

  function normalizeReasonList(raw) {
    if (!raw || typeof raw !== "object") return [];
    if (Array.isArray(raw)) return raw;
    if (Array.isArray(raw.keys) && Array.isArray(raw.values)) {
      return raw.keys.map((key, index) => ({
        ReasonID: key,
        ...(raw.values[index] || {})
      }));
    }
    return Object.values(raw).filter((item) => item && typeof item === "object");
  }

  function normalizeStockAreas(value) {
    return Array.isArray(value) ? value : [];
  }

  // 物流方式（FMethod 代碼）在 ERP 配送下拉裡的順序，供「依照物流方式排序」用。
  // 讀法比照 getRuleOptions 抓配送下拉的做法：找含「宅配通」選項的那個 <select>，
  // 而且要跟 getRuleOptions 一樣把「同名」與「[代收]」合併成同一組再給順序——
  // 同一家物流（例如 7-11／7-11[代收]）在下拉裡不一定相鄰，如果直接依 DOM 出現順序給每個代碼各自的名次，
  // 同一家物流的一般單跟代收單會拿到不同名次，排序時就會被拆開、混在別家物流中間（看起來像沒排序一樣）。
  function buildFreightOrderMap(pageWindow) {
    const map = new Map(); // 原始代碼 -> 名次（同一家物流的所有代碼共用同一個名次）
    try {
      const sel = Array.from(pageWindow.document.querySelectorAll("select"))
        .find((s) => Array.from(s.options).some((o) => /宅配通/.test(o.textContent || "")));
      if (!sel) return map;
      const baseRank = new Map(); // 物流名稱（去掉 [代收]）-> 名次
      let idx = 0;
      Array.from(sel.options).forEach((o) => {
        const v = String(o.value);
        const t = (o.textContent || "").trim();
        if (!v || v === "-1" || !t) return;
        const base = t.replace(/\[代收\]$/, "").trim();
        if (!baseRank.has(base)) { baseRank.set(base, idx); idx += 1; }
        map.set(v, baseRank.get(base));
      });
    } catch { /* 找不到下拉就回傳空 map，呼叫端自行處理找不到順序的情況 */ }
    return map;
  }

  // 每個出貨單位的儲位區代碼（'-' 前的值，大寫），供依「儲位區資訊」條件的標籤順序排序用
  function stockAreaTokens(stockAreaMap, key) {
    return normalizeStockAreas(stockAreaMap?.[key])
      .map((a) => String(a?.LocationName || "").trim().toUpperCase().split("-")[0])
      .filter(Boolean);
  }

  // 每個出貨單位的「完整」儲位代碼（含 '-' 後的細分，大寫），供同一標籤內的第二層排序用。
  // 例如 "HA3-1L"、"HA7-1L"（stockAreaTokens 只回首段 "HA3"／"HA7"，這裡保留整串）。
  function stockAreaFullCodes(stockAreaMap, key) {
    return normalizeStockAreas(stockAreaMap?.[key])
      .map((a) => String(a?.LocationName || "").trim().toUpperCase())
      .filter(Boolean);
  }

  // 自然排序比較：讓數字段以數值大小比較（HA3 在 HA7 前、HA3 在 HA10 前，而不是字典序把 HA10 排到 HA3 前）。
  function naturalCompare(a, b) {
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" });
  }

  // 依 stockOrder（儲位區標籤，依優先順序排列）把 rows 重新排序：
  // 主鍵＝「命中 stockOrder 最前面那個標籤」的名次（沿用標籤前綴比對，與分類一致），沒命中的排最後；
  // 次鍵＝命中該標籤的完整儲位代碼中最靠前的一個（自然排序），讓同一標籤內（例如都在 HA）
  // 進一步依完整代碼往下排：HA3 → HA7，且 HA3-1L → HA3-1R。同主次鍵維持原相對順序（穩定排序）。
  // stockAreaMap 沒有就現查（只查這批 keys，範圍小很快）。
  async function sortRowsByStockOrder(orderUtil, rows, keys, stockOrder, stockMap) {
    let map = stockMap || lastScan?.stockAreaMap;
    if (!map) {
      const txnKeys = rows.map((r) => r?.TxnKey).filter(Boolean);
      map = await queryTxnStockAreaList(orderUtil, txnKeys);
    }
    const order = (stockOrder || []).map((v) => String(v).trim().toUpperCase()).filter(Boolean);
    // 每個標籤可能是「H1+H2」這種合併標籤（H1、H2 視為同一區）：拆成多個子前綴，
    // 儲位代碼命中「任一子前綴」就算命中這個標籤。沒拆的話 startsWith("H1+H2") 永遠 false，
    // 該區會被當成「沒命中」排到最後（H 區跑到 P 後面置底就是這個原因）。
    const orderParts = order.map((tag) => tag.split("+").map((s) => s.trim()).filter(Boolean));
    const keyInfo = (rowKey) => {
      const prefixes = stockAreaTokens(map, rowKey);      // 首段代碼，例如 ["HA7","HA3"]
      const fulls = stockAreaFullCodes(map, rowKey);      // 完整代碼，例如 ["HA7-1L","HA3-1R"]
      for (let i = 0; i < orderParts.length; i += 1) {
        const subs = orderParts[i];
        if (prefixes.some((t) => subs.some((s) => t.startsWith(s)))) {
          // 這張單在此標籤下可能有多個儲位，取最靠前的完整代碼代表它，讓同標籤內能再細排
          const matched = fulls.filter((t) => subs.some((s) => t.startsWith(s))).sort(naturalCompare);
          return { rank: i, sub: matched[0] || "" };
        }
      }
      return { rank: order.length, sub: "" }; // 沒命中任何標籤 → 排最後
    };
    return rows
      .map((row, i) => ({ row, ...keyInfo(keys[i]) }))
      .sort((a, b) => a.rank - b.rank || naturalCompare(a.sub, b.sub))
      .map((x) => x.row);
  }

  // 依 sortMode 把明細列排序，供「查看層」「暫存區顯示」「列印」共用（回傳排序後的 rows）。
  //   stock ＝依儲位標籤順序（需 stockOrder；stockMap 沒有就現查）；date-asc ＝建立時間舊到新；
  //   spec-asc ＝規格款數少到多（以訂單為單位）；count-desc ＝訂單件數多到少（以訂單為單位）；
  //   freight ＝依 ERP 配送下拉順序分組；其餘＝不特別排序。
  async function sortRowsForDisplay(pageWindow, orderUtil, rows, keys, sortMode, stockOrder, stockMap) {
    if (sortMode === "stock") {
      const order = Array.isArray(stockOrder) ? stockOrder : [];
      return order.length ? await sortRowsByStockOrder(orderUtil, rows, keys, order, stockMap) : rows;
    }
    if (sortMode === "date-asc") {
      const dateOf = (row) => {
        const t = new Date(row?.DateConfirm || row?.DateCreation || NaN).getTime();
        return Number.isFinite(t) ? t : Infinity;
      };
      return rows.map((row, i) => ({ row, i, date: dateOf(row) }))
        .sort((a, b) => a.date - b.date || a.i - b.i).map((x) => x.row);
    }
    if (sortMode === "spec-asc" || sortMode === "count-desc") {
      // 以「訂單」為單位：規格款數/件數是每張訂單一值（表頭列帶值、續列 0），同單明細列要綁在一起。
      const orders = new Map();
      rows.forEach((row, i) => {
        const txn = getTxnNumber(row) || String(keys[i]);
        if (!orders.has(txn)) orders.set(txn, { rows: [], val: 0, seq: orders.size });
        const o = orders.get(txn);
        o.rows.push(row);
        o.val += Number((sortMode === "spec-asc" ? row?.OrderSpecCount : row?.OrderCount) || 0);
      });
      const arr = Array.from(orders.values());
      arr.sort(sortMode === "spec-asc" ? (a, b) => a.val - b.val || a.seq - b.seq
        : (a, b) => b.val - a.val || a.seq - b.seq);
      return arr.flatMap((o) => o.rows);
    }
    if (sortMode === "freight") {
      const orderMap = buildFreightOrderMap(pageWindow);
      const rankOf = (row) => { const code = String(row?.FMethod ?? ""); return orderMap.has(code) ? orderMap.get(code) : Infinity; };
      return rows.map((row, i) => ({ row, i, rank: rankOf(row) }))
        .sort((a, b) => a.rank - b.rank || a.i - b.i).map((x) => x.row);
    }
    return rows;
  }

      function getTxnNumber(row) {
    return String(
      row?.TxnNumber ||
      row?.TxnNum ||
      row?.TxnKey?.TxnNum ||
      row?.OrderList?.[0]?.TxnNum ||
      ""
    ).trim();
  }

    function triggerRealClick(node) {
    if (!node) return false;
    // ⚠️ node 可能在子框架（Order_Entry iframe）：必須用「該節點所屬框架的 window」建立 MouseEvent，
    // 否則用頂層 window 的事件子框架收不到 → 切分頁/點擊無效（這就是讀到 0 筆、配送選項空的根因）
    const win = (node.ownerDocument && node.ownerDocument.defaultView) || window;
    ["mousedown", "mouseup", "click"].forEach((type) => {
      node.dispatchEvent(new win.MouseEvent(type, {
        bubbles: true,
        cancelable: true,
        view: win
      }));
    });
    return true;
  }

  function emitProgress(action, step, detail = "") {
    window.postMessage({
      type: PROGRESS_TYPE,
      action,
      step,
      detail,
      at: Date.now()
    }, "*");
  }

  function withCallbackTimeout(executor, ms, errorMessage) {
    return new Promise((resolve, reject) => {
      let finished = false;
      const timeoutId = window.setTimeout(() => {
        if (finished) return;
        finished = true;
        reject(new Error(errorMessage));
      }, ms);

      executor(
        (value) => {
          if (finished) return;
          finished = true;
          window.clearTimeout(timeoutId);
          resolve(value);
        },
        (error) => {
          if (finished) return;
          finished = true;
          window.clearTimeout(timeoutId);
          reject(error instanceof Error ? error : new Error(String(error || errorMessage)));
        }
      );
    });
  }

    function chunkArray(list, size) {
    const chunks = [];
    for (let index = 0; index < list.length; index += size) {
      chunks.push(list.slice(index, index + size));
    }
    return chunks;
  }

        function queryRows(orderUtil, baseOption, params) {
    return new Promise((resolve, reject) => {
      const option = JSON.parse(JSON.stringify(baseOption));
      if (params.tabListFilter) option.TabListFilter = params.tabListFilter;
      if (params.flag) option.FilterFlag = params.flag;

      withCallbackTimeout((done) => {
        orderUtil.GetOrderListByViewOption(option, false, false, done);
      }, 30000, "ERP 讀取訂單逾時").then((ret) => {
        if (ret?.error) {
          resolve({ total: 0, rows: [] });
          return;
        }
        const firstValue = ret?.value || {};
        const total = Number(firstValue?.TotalCount ?? 0);
        const firstRows = normalizeRows(firstValue?.ListData);
        // 注意：ERP 的 MaxPageNumber 其實是「每頁筆數」(100)，不是頁數，
        // 舊版把它當頁數塞進 Math.max，導致每次查詢都多打 ~95 個空白請求。
        // 正確頁數用 TotalPageNumber，並以 總數/每頁 自行推算當後備。
        const pageSize = firstRows.length || 100;
        const reportedPages = Number(firstValue?.TotalPageNumber ?? 0);
        const computedPages = pageSize > 0 ? Math.ceil(total / pageSize) : 0;
        const pageCount = Math.max(reportedPages, computedPages, total > 0 ? 1 : 0);

        if (pageCount <= 1) {
          resolve({
            cacheId: firstValue?.CacheID ?? null,
            total,
            rows: firstRows,
            raw: firstValue
          });
          return;
        }

        // 第 2 頁起並行抓（原本逐頁串行，5~11 頁時要等好幾秒）
        const pagePromises = [];
        for (let pageNo = 1; pageNo < pageCount; pageNo += 1) {
          pagePromises.push(
            withCallbackTimeout((pageResolve) => {
              const pageOption = JSON.parse(JSON.stringify(option));
              pageOption.CurrentPgNo = pageNo;
              orderUtil.GetOrderListByViewOption(pageOption, false, false, pageResolve);
            }, 20000, `ERP 讀取訂單第 ${pageNo + 1} 頁逾時`).then((pageRet) => {
              if (pageRet?.error) {
                return [];
              }
              return normalizeRows(pageRet?.value?.ListData);
            })
          );
        }

        Promise.all(pagePromises).then((pages) => {
          resolve({
            cacheId: firstValue?.CacheID ?? null,
            total,
            rows: firstRows.concat(...pages),
            raw: firstValue
          });
        }).catch(reject);
      }).catch(reject);
    });
  }

    async function queryTxnStockAreaList(orderUtil, txnKeys) {
    if (!txnKeys.length || !orderUtil?.GetTxnStockAreaList) {
      return {};
    }

    // 各批並行抓；「這批筆數不齊」也要重試（不是只有整批回空才重試）——實測發現伺服器偶爾會漏回批次
    // 裡的少數幾筆（不是整批空手而回，之前的寫法只要拿到任何資料就直接採用，漏掉的那幾筆永遠補不回來，
    // 每次同步都固定查不到儲位、被誤判成「沒有儲位資訊」）。最多重試 3 次，3 次後還是不齊就用拿到最多筆的那次。
    const chunks = chunkArray(txnKeys.filter(Boolean), 120);
    emitProgress("classify", "儲位資料", `${txnKeys.length} 筆／${chunks.length} 批並行`);
    const fetchChunk = async (chunk, index) => {
      let best = {};
      for (let attempt = 1; attempt <= 3; attempt += 1) {
        const partial = await withCallbackTimeout((resolve) => {
          orderUtil.GetTxnStockAreaList(chunk, resolve);
        }, 25000, `ERP 讀取儲位第 ${index + 1} 批逾時`).then((ret) => {
          if (ret?.error || !ret?.value?.keys || !ret?.value?.values) {
            return {};
          }
          const result = {};
          ret.value.keys.forEach((key, valueIndex) => {
            result[key] = Array.isArray(ret.value.values[valueIndex]) ? ret.value.values[valueIndex] : [];
          });
          return result;
        }).catch(() => ({}));
        if (Object.keys(partial).length > Object.keys(best).length) best = partial;
        if (Object.keys(partial).length >= chunk.length) return partial; // 這批都齊了才提早結束
        if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, 400));
      }
      return best; // 3 次都不齊，用拿到最多筆的那次，總比完全空手而回好
    };
    const parts = await Promise.all(chunks.map((chunk, index) => fetchChunk(chunk, index)));
    const mapped = {};
    parts.forEach((part) => Object.assign(mapped, part));
    return mapped;
  }

    async function readLiveOrderInfo() {
    const pageWindow = findOrderFrameWindow();
    if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };

    try {
      const orderUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.OrderUtil;
      const currentTab = pageWindow.m_TabMgnt?.getCurrentTab?.();
      if (!orderUtil?.GetOrderListByViewOption || !currentTab?.m_order_view_option) {
        return { ok: false, message: "USale order API not available." };
      }

      const option = cloneNewOrderOption(currentTab.m_order_view_option);
      return await new Promise((resolve) => {
        orderUtil.GetOrderListByViewOption(option, false, false, (ret) => {
          if (ret?.error || !ret?.value) {
            resolve({ ok: false, message: ret?.error?.Message || "Failed to load live ERP order info." });
            return;
          }
          resolve({
            ok: true,
            cacheId: ret.value.CacheID ?? null,
            total: Number(ret.value.TotalCount ?? 0)
          });
        });
      });
    } catch (error) {
      return { ok: false, message: error?.message || "Failed to read live ERP order info." };
    }
  }


  // 大批搬移：一次 400 筆減少往返；單批失敗自動退回 100 一批重試
  async function runChunkedMove(keys, executor) {
    const BIG = 400;
    const SMALL = 100;
    let moved = 0;
    for (let i = 0; i < keys.length; i += BIG) {
      const big = keys.slice(i, i + BIG);
      try {
        await executor(big);
        moved += big.length;
      } catch {
        for (let j = 0; j < big.length; j += SMALL) {
          const small = big.slice(j, j + SMALL);
          await executor(small); // 小批再失敗就往外拋
          moved += small.length;
        }
      }
    }
    return moved;
  }

  // 暫存區清單快取（10 分鐘 TTL）：匯入不必每次重抓
  let queueReasonCache = { at: 0, map: null };
  // 暫存區名稱 → ReasonID 對照（共用上面的快取）
  function loadQueueReasonMap(settingUtil) {
    if (queueReasonCache.map && Date.now() - queueReasonCache.at <= 600000) {
      return Promise.resolve(queueReasonCache.map);
    }
    return new Promise((resolve) => {
      settingUtil.GetAllQueueReason(false, (ret) => {
        if (ret?.error || !ret?.value) {
          resolve(new Map());
          return;
        }
        const map = new Map();
        normalizeReasonList(ret.value).forEach((item) => {
          const name = String(item?.ReasonText || item?.ReasonName || "").trim();
          if (name) map.set(name, item?.ReasonID || item?.ReasonId);
        });
        if (map.size) queueReasonCache = { at: Date.now(), map };
        resolve(map);
      });
    });
  }

  async function importOrdersToQueue(planGroups, cacheIdFromScan, opts = {}) {
    const pageWindow = findOrderFrameWindow();
    if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };

    try {
      const txnUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.TxnUtil;
      const settingUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.SettingUtil;
      const cacheId = cacheIdFromScan || "";
      if (!txnUtil?.MoveToOrderQueue || !settingUtil?.GetAllQueueReason) {
        return { ok: false, message: "USale queue import API not available." };
      }
      if (!cacheId) {
        return { ok: false, message: "Missing ERP CacheID for queue import." };
      }

      const reasonMap = await loadQueueReasonMap(settingUtil);

      // 各暫存區的搬移「並行」送出（最多 5 路同時）；失敗的區再逐一重試一次
      const jobs = [];
      for (const group of planGroups) {
        const reasonId = reasonMap.get(group.queueName);
        const txnKeys = Array.isArray(group.txnKeys) ? group.txnKeys.filter(Boolean) : [];
        if (!txnKeys.length) continue;
        if (!reasonId) throw new Error(`找不到暫存區：${group.queueName}`);
        jobs.push({ queueName: group.queueName, reasonId, txnKeys });
      }

      const moveGroup = (job) => runChunkedMove(job.txnKeys, (chunk) => new Promise((resolve, reject) => {
        txnUtil.MoveToOrderQueue(chunk, job.reasonId, cacheId, (ret) => {
          if (ret?.error) reject(new Error(ret.error.Message || `${job.queueName} move failed.`));
          else resolve();
        });
      }));

      const groups = [];
      let moved = 0;
      const failures = [];
      let cursor = 0;
      const POOL = 5;
      await Promise.all(Array.from({ length: Math.min(POOL, jobs.length) }, async () => {
        while (cursor < jobs.length) {
          const job = jobs[cursor];
          cursor += 1;
          try {
            const groupMoved = await moveGroup(job);
            moved += groupMoved;
            groups.push({ queueName: job.queueName, moved: groupMoved });
          } catch {
            failures.push(job);
          }
        }
      }));

      // 並行失敗的區，逐一重試一次（可能是伺服器不耐並發）
      for (const job of failures) {
        const groupMoved = await moveGroup(job); // 再失敗就往外拋
        moved += groupMoved;
        groups.push({ queueName: job.queueName, moved: groupMoved });
      }

      // 訂單已搬進暫存區，分類快取作廢。fanout 快照一律清（父層暫存區內容變了）；
      // 主快照 lastScan：只有「來源是新訂單」的搬單才需要清（新訂單少了那幾筆）。
      // 子分類搬單是「父層暫存區→子暫存區」，新訂單沒變 → keepMainScan=true 保留主快照，上層卡片查看/移入才不會壞。
      if (!opts.keepMainScan) lastScan = null;
      fanoutScans.clear();
      return { ok: true, moved, groups };
    } catch (error) {
      return { ok: false, message: error?.message || "Import failed." };
    }
  }

    function getRawListValue(orderUtil, option) {
    return new Promise((resolve) => {
      orderUtil.GetOrderListByViewOption(option, false, false, (ret) => resolve(ret?.value || null));
    });
  }

  // 確保 ERP 內部分頁停在「新訂單」；已在的話不等待（已在則零等待）
  async function ensureNewOrderTab(pageWindow) {
    try {
      const doc = pageWindow.document;
      const newOrderTab = Array.from(doc.querySelectorAll("li"))
        .find((item) => /新訂單/.test((item.innerText || "").trim()));
      if (newOrderTab && !/tag_selected/.test(newOrderTab.className || "")) {
        triggerRealClick(newOrderTab);
        await new Promise((resolve) => setTimeout(resolve, 1200));
      }
    } catch {
      // 切頁失敗就走後備流程
    }
  }

  // 把指定層（或分支）的訂單直接渲染到 ERP 主畫面（新訂單）的表格，只改畫面、不動任何訂單資料。
  // 速度策略：優先用分類時快取的訂單列＋模板（零查詢、近乎即時）；
  // 沒有快取（尚未分類或匯入/移出後已失效）才退回重新分類。
  async function renderLayerInMainTable(payload = {}) {
    const layerId = String(payload.layerId || "");
    const branchId = String(payload.branchId || "");
    const label = String(payload.label || "該層");

    const pageWindow = findOrderFrameWindow();
    if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };

    const orderUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.OrderUtil;
    const currentTab = pageWindow.m_TabMgnt?.getCurrentTab?.();
    if (!orderUtil?.GetOrderListByViewOption || !currentTab?.m_order_view_option || typeof currentTab.setTableData !== "function") {
      return { ok: false, message: "USale 主畫面 API 不可用。" };
    }

    await ensureNewOrderTab(pageWindow);

    // 快照模型：檢視用該卡片對應的那份快照。fanoutKey 有值＝子分類（用獨立槽的父層暫存區快照）；
    // 否則用主快照 lastScan（新訂單）。這樣 fanout 後上層卡片仍能查看（各用各的快照，不互相蓋掉）。
    const scan = payload.fanoutKey ? fanoutScans.get(String(payload.fanoutKey)) : lastScan;
    const lookupKeys = () => (branchId ? scan?.branchKeys?.[branchId] : scan?.layerKeys?.[layerId]);
    const keys = lookupKeys();
    if (!keys) {
      const hint = payload.fanoutKey ? "請按「↧ 從父層暫存區讀取」重新讀取。" : "請按「同步訂單」。";
      return { ok: false, message: `訂單快照已失效（ERP 頁面曾重新整理或已搬單）。${hint}` };
    }
    const keySet = new Set(keys.map((k) => String(k)));

    let filtered;
    let filteredKeys;
    let template;
    if (scan?.rowByKey && scan?.template) {
      // 快速路徑：直接用分類時的快取，不再重抓任何資料
      filtered = [];
      filteredKeys = [];
      for (const [key, row] of scan.rowByKey.entries()) {
        if (keySet.has(String(key))) { filtered.push(row); filteredKeys.push(String(key)); }
      }
      template = scan.template;
    } else {
      // 後備路徑：抓目前全部新訂單（含分頁），過濾出屬於該層的列
      const all = await queryRows(orderUtil, cloneNewOrderOption(currentTab.m_order_view_option), {});
      const allRows = normalizeRows(all.rows);
      filtered = [];
      filteredKeys = [];
      allRows.forEach((row, index) => {
        const key = String(buildRowKey(row, index));
        if (keySet.has(key)) { filtered.push(row); filteredKeys.push(key); }
      });
      template = all.raw || await getRawListValue(orderUtil, cloneNewOrderOption(currentTab.m_order_view_option));
    }
    if (!template) return { ok: false, message: "無法取得 ERP 列表模板。" };

    // 分類卡片的「排序方式」（查看／列印都是同一份 ListData，排序會一併套用）。共用 sortRowsForDisplay。
    filtered = await sortRowsForDisplay(pageWindow, orderUtil, filtered, filteredKeys, String(payload.sortMode || ""), payload.stockOrder, scan?.stockAreaMap);

    // 訂單數（與面板口徑一致）；ERP 列出的是明細列，數字會比較大
    const txns = new Set();
    filtered.forEach((row, i) => {
      txns.add(getTxnNumber(row) || String(buildRowKey(row, i)));
    });
    const orderCount = txns.size;

    const pageCache = Object.assign({}, template, {
      TotalCount: filtered.length,
      TotalPageNumber: 1,
      MaxPageNumber: 1,
      CurrentPgNo: 0,
      ListData: filtered
    });

    try {
      currentTab.m_order_view_option.CurrentPgNo = 0;
      currentTab.setTableData(pageCache);
    } catch (error) {
      return { ok: false, message: error?.message || "setTableData 失敗。" };
    }

    // setTableData 會把標題重繪成「目前搜尋條件：全部(N)」，延遲改寫成該層名稱
    const doc = pageWindow.document;
    const relabel = () => {
      // 「目前搜尋條件 :」(li.filter_title) 與其值「全部(N)」(li.filter_option) 是分開的兩個元素，
      // 而且頁面上有隱藏的樣板複本，要挑「可見」的那一組，改它的值節點。
      const titles = Array.from(doc.querySelectorAll("li.filter_title"));
      const visibleTitle = titles.find((t) => t.offsetParent || t.getClientRects().length) || titles[titles.length - 1];
      const option = visibleTitle?.nextElementSibling;
      const cls = option && typeof option.className === "string" ? option.className : "";
      if (!option || !/filter_option/.test(cls)) return;

      // 標籤太長會把同一行的功能列（發送訊息、新增備註…）擠到下一行而被蓋住。
      // 由長到短逐一嘗試，量到功能列仍在同一行才定案。
      const actionBtn = Array.from(doc.querySelectorAll("li"))
        .find((n) => (n.textContent || "").trim() === "發送訊息" && (n.offsetParent || n.getClientRects().length));
      const fitsSameLine = () => {
        if (!actionBtn || !visibleTitle) return true;
        const titleTop = visibleTitle.getBoundingClientRect().top;
        const btnTop = actionBtn.getBoundingClientRect().top;
        return Math.abs(btnTop - titleTop) < 15;
      };
      // 標籤數字用「明細列數」(filtered.length)，跟 ERP 原生一致；不用訂單數(orderCount)
      const candidates = [
        `${label}(${filtered.length})`,
        `${label.replace(/^第\d+層\s*/, "")}(${filtered.length})`,
        `(${filtered.length})`
      ];
      for (const text of candidates) {
        option.textContent = text;
        if (fitsSameLine()) break;
      }
    };
    setTimeout(relabel, 200);
    setTimeout(relabel, 600);

    return { ok: true, count: orderCount, units: filtered.length, label };
  }

  // 主畫面標題改寫（「目前搜尋條件」→ 自訂文字；量寬避免擠掉功能列）
  function relabelMainTable(pageWindow, text) {
    const doc = pageWindow.document;
    const relabel = () => {
      const titles = Array.from(doc.querySelectorAll("li.filter_title"));
      const visibleTitle = titles.find((t) => t.offsetParent || t.getClientRects().length) || titles[titles.length - 1];
      const option = visibleTitle?.nextElementSibling;
      const cls = option && typeof option.className === "string" ? option.className : "";
      if (!option || !/filter_option/.test(cls)) return;
      const actionBtn = Array.from(doc.querySelectorAll("li"))
        .find((n) => (n.textContent || "").trim() === "發送訊息" && (n.offsetParent || n.getClientRects().length));
      const fitsSameLine = () => {
        if (!actionBtn || !visibleTitle) return true;
        return Math.abs(actionBtn.getBoundingClientRect().top - visibleTitle.getBoundingClientRect().top) < 15;
      };
      const fallback = text.replace(/^[^(（]*/, "");
      for (const candidate of [text, fallback || text]) {
        option.textContent = candidate;
        if (fitsSameLine()) break;
      }
    };
    setTimeout(relabel, 200);
    setTimeout(relabel, 600);
  }

  // ===========================================================================
  // V2 規則引擎：吃「規則設定檔」執行樹狀篩選分類
  //   層 = 共同條件(AND) + 分流條件 + 分支(值複選=OR，各自出口)；由上往下，先接住先贏。
  //   分支沒接住 → fallback（若有設）→ 否則往下漏；漏到最底 = 剩餘（layerKeys.__rest）。
  //   條件積木：icon(ERP旗標查詢)、shop(TxnShopId)、freight(FMethod)、
  //            stock(儲位 '-' 前綴 startsWith；any=任一符合 / all=全部都在)、always(無條件)。
  // ===========================================================================
  async function scanByConfig(config, options = {}) {
    const pageWindow = findOrderFrameWindow();
    if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };

    try {
      const startedAt = Date.now();
      const includeQueuePlan = options?.includeQueuePlan !== false;
      const independent = options?.independent === true; // true：每筆計入所有符合的層（不 first-match），供「池數統計」
      const layers = (Array.isArray(config?.layers) ? config.layers : []).filter((l) => l && l.enabled !== false);
      emitProgress("classify", "開始分類", `規則層數 ${layers.length}`);

      const orderUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.OrderUtil;
      const currentTab = pageWindow.m_TabMgnt?.getCurrentTab?.();
      if (!orderUtil?.GetOrderListByViewOption || !currentTab?.m_order_view_option) {
        return { ok: false, message: "USale order API not available." };
      }

      const src = await resolveScanBaseOption(pageWindow, currentTab, options?.source);
      if (!src.option) return { ok: false, message: src.error || "無法建立查詢條件。" };
      const baseOption = src.option;
      const sourceLabel = options?.source?.type === "queue" ? `暫存區「${options.source.name}」` : "新訂單";
      emitProgress("classify", "抓取訂單", `讀取${sourceLabel}`);
      const allOrders = await queryRows(orderUtil, baseOption, {});
      let allRows = normalizeRows(allOrders.rows);

      // 配單數量上限（options.limit）：以「交易序號」為單位，只取最舊的 N 筆訂單進入分類（0／未給＝不限）。
      // 同一交易的所有出貨單位/明細列一起保留，避免拆單。
      const orderLimit = Number(options?.limit) > 0 ? Math.floor(options.limit) : 0;
      if (orderLimit > 0) {
        const dateOf = (r) => { const t = new Date(r?.DateConfirm || r?.DateCreation || NaN).getTime(); return Number.isFinite(t) ? t : Infinity; };
        const earliest = new Map();
        for (const r of allRows) {
          const txn = getTxnNumber(r); if (!txn) continue;
          const d = dateOf(r);
          if (!earliest.has(txn) || d < earliest.get(txn)) earliest.set(txn, d);
        }
        const keptTxns = new Set([...earliest.keys()].sort((a, b) => earliest.get(a) - earliest.get(b)).slice(0, orderLimit));
        allRows = allRows.filter((r) => keptTxns.has(getTxnNumber(r)));
        emitProgress("classify", "配單上限", `取最舊 ${keptTxns.size} 筆訂單（共 ${earliest.size}）`);
      }
      const allRowMap = rowsToKeyMap(allRows);

      // 每個出貨單位的明細列數
      const txnDetailCount = new Map();
      for (const r of allRows) {
        const k = String(buildRowKey(r, 0));
        if (k) txnDetailCount.set(k, (txnDetailCount.get(k) || 0) + 1);
      }

      // 規格款數以「訂單」為單位：ERP 的 OrderSpecCount 是表頭列帶值、續列為 0，
      // 同一交易序號取最大值＝該訂單的規格款數（拆單的續列才不會被判成 0）。
      const specByTxn = new Map();
      for (const r of allRows) {
        const t = getTxnNumber(r);
        if (t == null || t === "") continue;
        const v = Number(r?.OrderSpecCount || 0);
        if (v > (specByTxn.get(t) || 0)) specByTxn.set(t, v);
      }

      // 圖示(旗標)：每組不同的旗標清單做一次 ERP 旗標查詢，得到符合的 key 集合
      const normalizeSig = (values) => (Array.isArray(values) ? values.map(String) : []).join(",");
      const iconSets = new Map();
      layers.forEach((layer) => {
        (layer.conditions || []).forEach((c) => {
          if (c.field === "icon") iconSets.set(normalizeSig(c.values), null);
        });
        if (layer.branchField === "icon") {
          (layer.branches || []).forEach((b) => iconSets.set(normalizeSig(b.values), null));
        }
      });
      iconSets.delete("");
      for (const sig of iconSets.keys()) {
        emitProgress("classify", "旗標查詢", `FLAG:${sig}`);
        const ret = await queryRows(orderUtil, baseOption, { flag: `FLAG:${sig}` });
        const set = new Set();
        for (const [key] of rowsToKeyMap(ret.rows).entries()) set.add(key);
        iconSets.set(sig, set);
      }

      // 儲位資料：延後到第一個用到儲位的層才抓。
      // first-match 模式下只抓「還沒被前面層接走」的訂單（已被接走的後面用不到，省查詢）；
      // independent 模式下每一層都要能各自判斷「每一筆」訂單，不能只抓還沒被接走的，否則已經被前面層
      // 算過的訂單會因為查無儲位資料而被判定「沒有 tokens」，導致這裡永遠比對不到（曾經真的這樣漏單）。
      let stockAreaMap = null;
      const ensureStockData = async () => {
        if (stockAreaMap) return;
        const pendingKeys = [];
        for (const [key, row] of allRowMap.entries()) {
          if (independent || !assigned.has(key)) pendingKeys.push(row.TxnKey);
        }
        stockAreaMap = await queryTxnStockAreaList(orderUtil, pendingKeys);
      };

      const tokensCache = new Map();
      const stockTokens = (key) => {
        if (tokensCache.has(key)) return tokensCache.get(key);
        const tokens = normalizeStockAreas(stockAreaMap?.[key])
          .map((a) => String(a?.LocationName || "").trim().toUpperCase().split("-")[0])
          .filter(Boolean);
        tokensCache.set(key, tokens);
        return tokens;
      };

      const matchValues = (field, stockMode, goodsMode, values, key, row) => {
        if (field === "always") return true;
        if (field === "amount") {
          // 訂單金額（商品總計，不含運費）區間比對：values = { min, max }，任一留空＝不限制那一邊
          const amt = Number(row?.GoodTxnTotal || 0);
          const min = values && values.min !== undefined && values.min !== null && values.min !== "" ? Number(values.min) : null;
          const max = values && values.max !== undefined && values.max !== null && values.max !== "" ? Number(values.max) : null;
          if (min !== null && !(amt >= min)) return false;
          if (max !== null && !(amt <= max)) return false;
          return true;
        }
        if (field === "spec") {
          // 規格款數區間比對（以訂單為單位，用 specByTxn；避免拆單續列 OrderSpecCount=0 被誤判）
          const n = specByTxn.get(getTxnNumber(row)) || 0;
          const min = values && values.min !== undefined && values.min !== null && values.min !== "" ? Number(values.min) : null;
          const max = values && values.max !== undefined && values.max !== null && values.max !== "" ? Number(values.max) : null;
          if (min !== null && !(n >= min)) return false;
          if (max !== null && !(n <= max)) return false;
          return true;
        }
        // 跨區模式是自動判斷、標籤清單本來就是空的，必須在「空清單＝不符合」的通用防呆之前先處理，
        // 否則永遠在進到跨區邏輯前就被擋掉（曾經因此所有訂單都判 0 筆）
        if (field === "stock" && stockMode === "cross") {
          const tokens = stockTokens(key);
          if (!tokens.length) return false;
          // 跨區＝訂單商品的儲位分散在 2 個以上不同的「自然分區」。分區鍵：
          //  - 開頭是「字母＋字母」(例如 HA、HB…重架區) → 首字母＋"@"，讓 HA/HB/HC/HD 全歸同一大區（彼此不跨）；
          //  - 其餘（H1/H2 的字母+數字、21/22 的純數字、單一字母 A…）→ 用第一個字元。
          // 效果：H1(→H) 與 HA(→H@) 屬不同區＝跨區；HA 與 HB 同區、H1 與 H2 同區、21 與 22 同區、2 與 3 不同區。
          const zoneKey = (t) => {
            const s = String(t);
            return /^[A-Za-z][A-Za-z]/.test(s) ? s.charAt(0) + "@" : s.charAt(0);
          };
          return new Set(tokens.map(zoneKey)).size >= 2;
        }
        const list = Array.isArray(values) ? values.map(String) : [];
        if (!list.length) return false;
        if (field === "icon") {
          return iconSets.get(list.join(","))?.has(key) || false;
        }
        if (field === "shop") {
          return list.includes(String(row?.TxnShopId ?? row?.TxnKey?.TxnShopId ?? ""));
        }
        if (field === "freight") {
          return list.includes(String(row?.FMethod ?? ""));
        }
        if (field === "stock") {
          const tokens = stockTokens(key);
          if (!tokens.length) return false;
          // 標籤可以用「+」合併多個前綴成同一組，例如 "H1+H2"：H1、H2 視為同一區，
          // 但不會像單打「H」那樣連 HA1/HA2/HB1…HD2 也一起抓進來。
          const expand = (v) => String(v).split("+").map((p) => p.trim()).filter(Boolean);
          const hit = (t) => list.some((v) => expand(v).some((p) => t.startsWith(p)));
          if (stockMode === "single") {
            // 訂單所有商品都要落在「同一個標籤」代表的區（不能跨區）。
            // 用標籤前綴分組，不是拿儲位代碼完全相等比較：例如標籤只打「2」，21 跟 22 都歸在同一組＝同區；
            // 分開打「21」「22」兩個標籤，21 跟 22 就是不同組＝跨區；打「H1+H2」合併成一個標籤，H1、H2 就是同一組。
            const groups = tokens.map((t) => list.find((v) => expand(v).some((p) => t.startsWith(p))));
            if (groups.some((g) => g === undefined)) return false; // 有商品的儲位不在清單內任何一個標籤裡
            return new Set(groups).size === 1;
          }
          return stockMode === "all" ? tokens.every(hit) : tokens.some(hit);
        }
        if (field === "goods") {
          // 商品/SKU 配對（輸入 B321 命中 B321-xx；輸入 B321-B04 為精準）。三種模式：
          //  any（預設）＝訂單任一品項在清單內就算（可以還有清單外的商品）
          //  all         ＝訂單所有品項都要在清單內（不能有清單外的商品）
          //  single      ＝訂單只有「一種」商品且在清單內（單品訂單）
          const items = Array.isArray(row?.OrderList) ? row.OrderList : [];
          if (!items.length) return false;
          if (goodsMode === "all") return items.every((it) => goodsMatch(itemCode(it), list));
          if (goodsMode === "single") {
            const codes = new Set(items.map((it) => itemCode(it)).filter(Boolean));
            return codes.size === 1 && goodsMatch([...codes][0], list);
          }
          return items.some((it) => goodsMatch(itemCode(it), list)); // any
        }
        return false;
      };

      const assigned = new Map();
      const layerKeys = {};
      const branchKeys = {};
      const queuePlan = [];
      // 顯示計數：訂單＝不同「交易序號」數、明細＝明細列數；
      // 搬移/檢視仍以出貨單位（TxnKeyStr）為準（同交易可拆多個出貨單位）。
      const branchTxnSets = {};
      const layerTxnSets = {};

      const layerResults = layers.map((layer, index) => {
        const branches = (layer.branches || []).map((b) => ({
          id: String(b.id || `${layer.id}_b${index}`),
          label: b.label || b.queue || "",
          queue: b.queue || "",
          count: 0,
          detailCount: 0
        }));
        const fallback = layer.fallback?.queue
          ? { id: `${layer.id}__rest`, label: layer.fallback.label || "其餘", queue: layer.fallback.queue, count: 0, detailCount: 0, isFallback: true }
          : null;
        return { id: layer.id, name: layer.name || `第${index + 1}層`, branches, fallback };
      });

      for (let li = 0; li < layers.length; li += 1) {
        const layer = layers[li];
        const usesStock = layer.branchField === "stock" || (layer.conditions || []).some((c) => c.field === "stock");
        if (usesStock) await ensureStockData();
        const res = layerResults[li];
        layerKeys[layer.id] = [];
        layerTxnSets[layer.id] = new Set();
        res.branches.forEach((b) => { branchKeys[b.id] = []; branchTxnSets[b.id] = new Set(); });
        if (res.fallback) { branchKeys[res.fallback.id] = []; branchTxnSets[res.fallback.id] = new Set(); }

        for (const [key, row] of allRowMap.entries()) {
          if (!independent && assigned.has(key)) continue; // independent：允許同一筆被多層計入（池子重疊）
          const condOk = (layer.conditions || []).every((c) =>
            matchValues(c.field, c.stockMode || layer.stockMode, c.goodsMode, c.values, key, row));
          if (!condOk) continue;

          let target = null;
          const branchList = layer.branches || [];
          for (let bi = 0; bi < branchList.length; bi += 1) {
            if (matchValues(layer.branchField, layer.stockMode, undefined, branchList[bi].values, key, row)) {
              target = res.branches[bi];
              break;
            }
          }
          if (!target && res.fallback) target = res.fallback;
          if (!target) continue; // 分支沒接住 → 往下漏

          assigned.set(key, layer.id);
          const detail = txnDetailCount.get(String(key)) || 0;
          const txnNo = getTxnNumber(row) || String(key);
          target.detailCount += detail;
          branchTxnSets[target.id].add(txnNo);
          layerTxnSets[layer.id].add(txnNo);
          layerKeys[layer.id].push(key);
          branchKeys[target.id].push(key);
          if (includeQueuePlan && target.queue) {
            queuePlan.push({
              txnKey: row?.TxnKey,
              txnKeyStr: key,
              txnNumber: getTxnNumber(row),
              detailCount: detail,
              queueName: target.queue,
              layerId: layer.id,
              branchId: target.id
            });
          }
        }
      }

      const layersOut = layerResults.map((res) => {
        const branches = (res.fallback ? [...res.branches, res.fallback] : res.branches).map((b) => ({
          ...b,
          count: branchTxnSets[b.id]?.size || 0
        }));
        return {
          id: res.id,
          name: res.name,
          count: layerTxnSets[res.id]?.size || 0,
          detailCount: branches.reduce((s, b) => s + b.detailCount, 0),
          txns: [...(layerTxnSets[res.id] || [])], // 該層的交易序號清單（供卡片記錄/查看）
          branches
        };
      });

      // 訂單數 = 不同交易序號數；明細 = ERP 明細列數
      const allTxnSet = new Set();
      for (const [key, row] of allRowMap.entries()) {
        allTxnSet.add(getTxnNumber(row) || String(key));
      }
      const orderCount = allTxnSet.size;
      const detailCount = orderLimit > 0 ? allRows.length : (Number.isFinite(allOrders.total) ? allOrders.total : allRows.length);
      const classified = assigned.size;
      const unassignedKeys = [];
      for (const key of allRowMap.keys()) {
        if (!assigned.has(key)) unassignedKeys.push(key);
      }
      layerKeys.__rest = unassignedKeys;

      const scanObj = {
        layerKeys,
        branchKeys,
        rowByKey: allRowMap,
        template: allOrders.raw || null,
        cacheId: allOrders.cacheId ?? null,
        configSig: JSON.stringify(config?.layers || []), // 撈批重用：規則相同即可直接切批
        stockAreaMap: stockAreaMap || null, // 有查過儲位資料才會有值；供「查看」依儲位標籤順序排序時重用，免重查
        at: Date.now()
      };
      // fanoutKey 有值＝這是「從父層暫存區讀取」，存進獨立槽、不動主快照 lastScan（上層卡片仍可查看/移入）；
      // 否則是一般同步，寫進主快照。
      if (options.fanoutKey) fanoutScans.set(String(options.fanoutKey), scanObj);
      else lastScan = scanObj;

      emitProgress("classify", "完成", `分類完成，耗時 ${Math.round((Date.now() - startedAt) / 1000)} 秒`);

      return {
        ok: true,
        engine: "config",
        cacheId: allOrders.cacheId ?? null,
        detailCount,
        orderCount,
        total: orderCount,
        classified,
        unclassified: unassignedKeys.length,
        layers: layersOut,
        queuePlan
      };
    } catch (error) {
      return { ok: false, message: error?.message || "Unknown scan error." };
    }
  }

  // 暫存區管理共用：SettingUtil 不限訂單頁，top 或任一 frame 有就能用
  function findQueueSettingWindow() {
    try { if (window.Mallbic?.U?.Sale?.Ajax?.SettingUtil?.AddQueueReason) return window; } catch { /* ignore */ }
    for (const f of document.querySelectorAll("iframe")) {
      try { if (f.contentWindow?.Mallbic?.U?.Sale?.Ajax?.SettingUtil?.AddQueueReason) return f.contentWindow; } catch { /* ignore */ }
    }
    return null;
  }

  function readAllQueueReasons(su) {
    return new Promise((resolve) => {
      su.GetAllQueueReason(false, (ret) => {
        const list = normalizeReasonList(ret?.value).map((it) => ({
          id: it?.ReasonID ?? it?.ReasonId,
          name: String(it?.ReasonText || it?.ReasonName || "").trim(),
          group: String(it?.ReasonGroup || "").trim(),
          count: Number(it?.STxnCount ?? 0),
          orderIdx: Number(it?.ReasonOrderIdx ?? 0),
          needInv: it?.NeedInvRequire !== false
        }));
        // 依 ERP 自己的排序欄位（ReasonOrderIdx）排序，讓下拉清單順序跟 ERP 畫面上看到的一致
        list.sort((a, b) => a.orderIdx - b.orderIdx);
        resolve(list);
      });
    });
  }

  function toQueueList(items) {
    return items.filter((it) => it.name).map((it) => ({ name: it.name, group: it.group }));
  }


  // 把 popup 的扁平 UI 分層（標籤）用「即時 ERP 對照」轉成 scanByConfig 的層 config（每層 conditions AND + always 單分支）。
  function uiLayersToEngineConfig(w, uiLayers) {
    // 圖示名稱 → flag 值（ERP 自己的 mapTxnIconType）
    const nameToFlag = {};
    try {
      const en = w.AjaxEnum?.TxnIconType || {};
      for (const k in en) {
        const v = en[k]; if (typeof v !== "number") continue;
        let nm = ""; try { nm = w.mapTxnIconType(v) || ""; } catch { /* ignore */ }
        if (nm) nameToFlag[nm] = String(v);
      }
    } catch { /* ignore */ }
    // 配送 label → [FMethod 代碼]（合併 [代收]）
    const labelToFreight = {};
    try {
      let sel = null;
      for (const f of [w, ...Array.from(w.frames || [])]) {
        try { const s = Array.from(f.document.querySelectorAll("select")).find((s) => Array.from(s.options).some((o) => /宅配通/.test(o.textContent || ""))); if (s) { sel = s; break; } } catch { /* ignore */ }
      }
      if (sel) Array.from(sel.options).forEach((o) => {
        const t = (o.textContent || "").trim(); const v = String(o.value);
        if (!t || v === "-1" || /^配送\s*\(/.test(t)) return;
        const base = t.replace(/\[代收\]$/, "").trim();
        (labelToFreight[base] = labelToFreight[base] || []).push(v);
      });
    } catch { /* ignore */ }
    return (uiLayers || []).map((L, i) => {
      const conditions = [];
      const icons = (L.icons || []).map((n) => nameToFlag[n]).filter(Boolean);
      if (icons.length) conditions.push({ field: "icon", values: icons });
      const fr = [];
      (L.delivery || []).forEach((lb) => (labelToFreight[lb] || []).forEach((c) => fr.push(c)));
      if (fr.length) conditions.push({ field: "freight", values: fr });
      const sh = (L.shops || []).map((s) => String(s || "").replace(/[^0-9]/g, "")).filter((s) => s !== "");
      if (sh.length) conditions.push({ field: "shop", values: sh });
      const st = (L.storage || []).map((s) => String(s || "").trim().toUpperCase()).filter(Boolean);
      // stockMode "any"＝至少一項在這些儲位就算，可以還有別的；"all"＝訂單只能是這些儲位、不能有別的（可跨多區，只要都在清單內）；
      // "single"＝訂單所有商品都要在同一個儲位區，且那個區要在清單內（不能跨區）；"cross"＝跟 single 完全相反，專接單區漏掉的
      const stockModeIn = ["all", "single", "cross"].includes(L.stockMode) ? L.stockMode : "any";
      // "cross" 是自動判斷（不看標籤清單），就算沒設任何儲位標籤也要照樣加這個條件；其他模式沒設標籤就不加條件
      if (st.length || stockModeIn === "cross") conditions.push({ field: "stock", values: st, stockMode: stockModeIn });
      const gd = (L.codes || []).map((c) => String(c || "").trim().toUpperCase()).filter(Boolean);
      // goodsMode "any"＝任一品項在清單內就算；"all"＝訂單只能是這些商品；"single"＝訂單只有一種商品且在清單內
      const goodsModeIn = ["all", "single"].includes(L.goodsMode) ? L.goodsMode : "any";
      if (gd.length) conditions.push({ field: "goods", values: gd, goodsMode: goodsModeIn });
      // 訂單金額（商品總計）區間：payload.amountMin / amountMax 任一有值就加條件
      const amtMin = L.amountMin !== undefined && L.amountMin !== null && L.amountMin !== "" ? Number(L.amountMin) : null;
      const amtMax = L.amountMax !== undefined && L.amountMax !== null && L.amountMax !== "" ? Number(L.amountMax) : null;
      if (amtMin !== null || amtMax !== null) conditions.push({ field: "amount", values: { min: amtMin, max: amtMax } });
      // 規格款數區間：payload.specMin / specMax 任一有值就加條件
      const specMin = L.specMin !== undefined && L.specMin !== null && L.specMin !== "" ? Number(L.specMin) : null;
      const specMax = L.specMax !== undefined && L.specMax !== null && L.specMax !== "" ? Number(L.specMax) : null;
      if (specMin !== null || specMax !== null) conditions.push({ field: "spec", values: { min: specMin, max: specMax } });
      const id = "UI" + i;
      const name = L.name || `第${i + 1}層`;
      return { id, name, conditions, branchField: "always", branches: [{ id: id + "_b", label: name, values: [], queue: "" }] };
    });
  }

  const actions = {
    // 動作前先確保 ERP 停在新訂單頁（已在則零等待）；查詢都走 cloneNewOrderOption，與畫面狀態無關。
    async refresh() {
      const w = findOrderFrameWindow();
      if (w) await ensureNewOrderTab(w);
      return readLiveOrderInfo();
    },
    // UI 驅動分類：吃 popup 傳來的扁平分層（圖示/配送/儲位「標籤」），用即時 ERP 對照轉成代碼後組 config 跑 scanByConfig。
    // payload = { layers:[{name, icons:[名稱], delivery:[名稱], storage:[區碼], codes:[...]}], limit }
    async classifyByLayers(payload = {}) {
      const w = findOrderFrameWindow();
      if (!w) return { ok: false, message: "目前不在 USale 訂單頁。" };
      await ensureNewOrderTab(w);
      const uiLayers = Array.isArray(payload.layers) ? payload.layers : [];
      if (!uiLayers.length) return { ok: false, message: "沒有可用的分層條件。" };
      const layers = uiLayersToEngineConfig(w, uiLayers);
      // payload.source：{ type: "new" }（預設，讀新訂單）或 { type: "queue", name }（改讀指定暫存區）
      const source = payload?.source?.type === "queue" && payload.source.name
        ? { type: "queue", name: String(payload.source.name) }
        : { type: "new" };
      // payload.independent：true＝每一層各自獨立比對，同一筆訂單符合多層就每層都算（不 first-match、不互斥）。
      // 預設 false（維持舊行為：由上往下 first-match，一筆訂單只會算進最先接住它的那一層）。
      const independent = payload?.independent === true;
      // payload.fanoutKey：有值＝「從父層暫存區讀取」，結果存進獨立快照槽（不蓋主快照 lastScan）
      const res = await scanByConfig({ version: 1, name: "UI規則", layers }, {
        includeQueuePlan: false,
        limit: Number(payload.limit) > 0 ? Math.floor(payload.limit) : 0,
        source,
        independent,
        fanoutKey: payload.fanoutKey ? String(payload.fanoutKey) : null
      });
      if (res && res.ok) res.warnings = [];
      return res;
    },



    async showLayerInMainTable(payload) {
      // renderLayerInMainTable 內建輕量切頁檢查，已在新訂單頁時零等待。
      return renderLayerInMainTable(payload || {});
    },
    // 把「同步訂單」剛剛抓到的整批來源資料（不管有沒有命中任何分類）直接畫到 ERP 主畫面，
    // 讓 ERP 畫面上看到的訂單列表跟這次同步的資料一致，不用另外點哪張卡片的「查看」。
    async showAllInMainTable(payload = {}) {
      const pageWindow = findOrderFrameWindow();
      if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };
      const currentTab = pageWindow.m_TabMgnt?.getCurrentTab?.();
      if (!currentTab?.m_order_view_option || typeof currentTab.setTableData !== "function") {
        return { ok: false, message: "USale 主畫面 API 不可用。" };
      }
      if (!lastScan?.rowByKey || !lastScan?.template) {
        return { ok: false, message: "訂單快照已失效（ERP 頁面曾重新整理）。請按「同步訂單」。" };
      }
      await ensureNewOrderTab(pageWindow);
      const rows = [...lastScan.rowByKey.values()];
      const pageCache = Object.assign({}, lastScan.template, {
        TotalCount: rows.length, TotalPageNumber: 1, MaxPageNumber: 1, CurrentPgNo: 0, ListData: rows
      });
      try {
        currentTab.m_order_view_option.CurrentPgNo = 0;
        currentTab.setTableData(pageCache);
      } catch (error) {
        return { ok: false, message: error?.message || "setTableData 失敗。" };
      }
      const txns = new Set();
      rows.forEach((row, i) => txns.add(getTxnNumber(row) || String(buildRowKey(row, i))));
      // 標籤數字用「明細列數」(rows.length)，跟 ERP 原生「全部(N)」一致；不用訂單數(txns.size)
      const labelText = `${String(payload.label || "同步訂單")}(${rows.length})`;
      relabelMainTable(pageWindow, labelText);
      return { ok: true, count: txns.size, units: rows.length };
    },
    // 暫存：把分支（或整層所有分支）的快照訂單放入各自設定的暫存區
    async stageScopes(payload) {
      const w = findOrderFrameWindow();
      if (w) await ensureNewOrderTab(w);
      const groups = Array.isArray(payload?.groups) ? payload.groups : [];
      // fanoutKey 有值＝移入子分類（來源是父層暫存區那份快照）；否則用主快照 lastScan
      const scan = payload.fanoutKey ? fanoutScans.get(String(payload.fanoutKey)) : lastScan;
      if (!scan?.rowByKey) {
        const hint = payload.fanoutKey ? "請按「↧ 從父層暫存區讀取」重新讀取。" : "請按「同步訂單」。";
        return { ok: false, message: `訂單快照已失效（ERP 頁面曾重新整理或已搬單）。${hint}` };
      }
      const planGroups = [];
      const txns = new Set();
      for (const g of groups) {
        const queueName = String(g?.queueName || "").trim();
        const keys = scan.branchKeys?.[String(g?.branchId || "")] || [];
        if (!keys.length) continue;
        if (!queueName) return { ok: false, message: `「${g?.label || g?.branchId}」尚未設定暫存區，請到設定頁選擇。` };
        const txnKeys = [];
        keys.forEach((k) => {
          const row = scan.rowByKey.get(String(k));
          if (row?.TxnKey) txnKeys.push(row.TxnKey);
          const t = getTxnNumber(row);
          if (t) txns.add(t);
        });
        if (txnKeys.length) planGroups.push({ queueName, txnKeys });
      }
      if (!planGroups.length) return { ok: true, moved: 0, orders: 0, groups: [] };
      let cacheId = (scan?.cacheId && Date.now() - (scan.at || 0) < 240000) ? scan.cacheId : null;
      if (!cacheId) {
        const liveInfo = await readLiveOrderInfo();
        if (!liveInfo?.ok || !liveInfo.cacheId) return liveInfo;
        cacheId = liveInfo.cacheId;
      }

      // 搬單前先記住目標暫存區目前的排序位置（ReasonOrderIdx）：
      // 實測發現搬入訂單後，ERP 有時會把該暫存區在下拉選單裡的位置跳到最後面（原因不明，
      // 手動在 ERP 操作不會這樣，只有透過這裡的 API 搬單才會），這裡搬完後盡量把排序改回去，不影響員工原本排好的順序。
      const settingWin = findQueueSettingWindow();
      const su = settingWin?.Mallbic?.U?.Sale?.Ajax?.SettingUtil;
      const queueNamesInvolved = [...new Set(planGroups.map((g) => g.queueName))];
      let orderSnapshot = null;
      if (su?.GetAllQueueReason) {
        try {
          const before = await readAllQueueReasons(su);
          orderSnapshot = new Map(before.filter((it) => queueNamesInvolved.includes(it.name)).map((it) => [it.name, it]));
        } catch { /* 讀不到快照就放棄還原排序，不影響搬單本身 */ }
      }

      // 子分類搬單（有 fanoutKey）＝父層暫存區→子暫存區，新訂單沒變 → 保留主快照，讓上層卡片查看/移入仍可用
      const ret = await importOrdersToQueue(planGroups, cacheId, { keepMainScan: !!payload.fanoutKey });
      if (ret?.ok) ret.orders = txns.size;

      if (ret?.ok && su?.UpdateQueueReason && orderSnapshot) {
        try {
          const after = await readAllQueueReasons(su);
          for (const item of after) {
            const before = orderSnapshot.get(item.name);
            if (!before || item.orderIdx === before.orderIdx) continue;
            await new Promise((resolve) => {
              su.UpdateQueueReason({
                ReasonID: item.id,
                ReasonText: item.name,
                ReasonGroup: item.group,
                NeedInvRequire: before.needInv,
                ReasonOrderIdx: before.orderIdx
              }, resolve);
            });
          }
        } catch { /* 還原排序失敗不影響搬單結果，靜默略過 */ }
      }

      return ret;
    },
    // 把指定暫存區目前的內容顯示在 ERP 主畫面（即時查詢，不依賴快照）
    async showQueueInMainTable(payload) {
      const queueName = String(payload?.queueName || "").trim();
      if (!queueName) return { ok: false, message: "尚未設定暫存區名稱。" };
      const pageWindow = findOrderFrameWindow();
      if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };
      const orderUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.OrderUtil;
      const settingUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.SettingUtil;
      const currentTab = pageWindow.m_TabMgnt?.getCurrentTab?.();
      if (!orderUtil?.GetOrderListByViewOption || !settingUtil?.GetAllQueueReason ||
          !currentTab?.m_order_view_option || typeof currentTab.setTableData !== "function") {
        return { ok: false, message: "USale 主畫面 API 不可用。" };
      }
      await ensureNewOrderTab(pageWindow);
      const reasonMap = await loadQueueReasonMap(settingUtil);
      const reasonId = reasonMap.get(queueName);
      if (!reasonId) return { ok: false, message: `找不到暫存區：${queueName}（請到設定頁建立）。` };
      const qOpt = cloneQueueViewOption(currentTab.m_order_view_option, reasonId);
      // payload.erpSortText：走 ERP server-side 排序（設 SortText 再查，例如「儲位區資訊」照儲位代碼分組）。
      // 這種排序是伺服器排的，會一路帶到「列印」不會跑掉；其餘（client-side）只排畫面、列印可能回到預設。
      if (payload?.erpSortText) { qOpt.SortText = payload.erpSortText; qOpt.Order = payload.erpSortOrder != null ? payload.erpSortOrder : 1; }
      const ret = await queryRows(orderUtil, qOpt, {});
      if (!ret.raw) return { ok: false, message: "無法取得 ERP 列表模板。" };
      let rows = normalizeRows(ret.rows);
      // client-side 排序（畫面用）：只有「沒走 ERP 原生排序」時才做，避免重覆排。
      const sortMode = String(payload?.sortMode || "");
      if (!payload?.erpSortText && sortMode) {
        const rowKeys = rows.map((r, i) => String(buildRowKey(r, i)));
        rows = await sortRowsForDisplay(pageWindow, orderUtil, rows, rowKeys, sortMode, payload?.stockOrder, null);
      }
      const txns = new Set();
      rows.forEach((r, i) => txns.add(getTxnNumber(r) || String(buildRowKey(r, i))));
      const pageCache = Object.assign({}, ret.raw, {
        TotalCount: rows.length,
        TotalPageNumber: 1,
        MaxPageNumber: 1,
        CurrentPgNo: 0,
        ListData: rows
      });
      try {
        currentTab.m_order_view_option.CurrentPgNo = 0;
        currentTab.setTableData(pageCache);
      } catch (error) {
        return { ok: false, message: error?.message || "setTableData 失敗。" };
      }
      // 標籤數字用「明細列數」(rows.length)，跟 ERP 原生一致；不用訂單數(txns.size)
      const labelText = `${queueName}(${rows.length})`;
      relabelMainTable(pageWindow, labelText);
      return { ok: true, count: txns.size, units: rows.length };
    },
    // 全部暫存區目前的訂單數（STxnCount；實機驗證＝該區訂單數）
    async getQueueCounts() {
      const w = findOrderFrameWindow() || findQueueSettingWindow();
      const su = w?.Mallbic?.U?.Sale?.Ajax?.SettingUtil;
      if (!su?.GetAllQueueReason) return { ok: false, message: "USale API 不可用。" };
      const items = await readAllQueueReasons(su);
      const counts = {};
      items.forEach((it) => { if (it.name) counts[it.name] = Number(it.count || 0); });
      return { ok: true, counts };
    },
    // 設定頁用：抓規則編輯器需要的選項清單（圖示/配送/店鋪/暫存區），全部即時取自 ERP
    async getRuleOptions() {
      const pageWindow = findOrderFrameWindow();
      if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };
      const out = { ok: true, icons: [], freights: [], shops: [], queues: [] };

      // 圖示（旗標）：AjaxEnum.TxnIconType 列舉 + mapTxnIconType 取中文名
      try {
        const en = pageWindow.AjaxEnum?.TxnIconType || {};
        for (const key in en) {
          const val = en[key];
          if (typeof val !== "number") continue;
          let name = "";
          try { name = pageWindow.mapTxnIconType(val) || ""; } catch { /* ignore */ }
          if (name) out.icons.push({ value: String(val), label: name });
        }
        out.icons.sort((a, b) => Number(a.value) - Number(b.value));
      } catch { /* ignore */ }

      // 配送：讀 ERP 配送下拉，同名與 [代收] 成對合併（一個選項對應多個代號）
      // 注意：配送下拉只在「新訂單」檢視渲染，找不到就先切過去再抓
      try {
        const findSel = () => Array.from(pageWindow.document.querySelectorAll("select"))
          .find((s) => Array.from(s.options).some((o) => /宅配通/.test(o.textContent || "")));
        let sel = findSel();
        if (!sel) {
          await ensureNewOrderTab(pageWindow);
          await new Promise((resolve) => setTimeout(resolve, 600));
          sel = findSel();
        }
        if (sel) {
          const merged = new Map();
          Array.from(sel.options).forEach((o) => {
            const v = String(o.value);
            const t = (o.textContent || "").trim();
            if (!t || v === "-1") return;
            const base = t.replace(/\[代收\]$/, "").trim();
            if (!merged.has(base)) merged.set(base, []);
            merged.get(base).push(v);
          });
          out.freights = Array.from(merged.entries()).map(([label, values]) => ({ label, values }));
        }
      } catch { /* ignore */ }

      // 店鋪：從目前訂單收集 TxnShopId（保底 0/1/2）
      try {
        const orderUtil = pageWindow.Mallbic?.U?.Sale?.Ajax?.OrderUtil;
        const currentTab = pageWindow.m_TabMgnt?.getCurrentTab?.();
        if (orderUtil?.GetOrderListByViewOption && currentTab?.m_order_view_option) {
          const ret = await new Promise((resolve) => {
            orderUtil.GetOrderListByViewOption(cloneNewOrderOption(currentTab.m_order_view_option), false, false, resolve);
          });
          const ids = new Set(["0", "1", "2"]);
          normalizeRows(ret?.value?.ListData).forEach((r) => {
            const s = r?.TxnShopId ?? r?.TxnKey?.TxnShopId;
            if (s !== undefined && s !== null) ids.add(String(s));
          });
          out.shops = Array.from(ids).sort((a, b) => Number(a) - Number(b)).map((id) => ({ value: id, label: `${id}號店` }));
        }
      } catch { /* ignore */ }

      // 暫存區清單（含群組，設定頁用群組過濾）：
      // SettingUtil 常不在訂單 frame，沿用正版作法（findOrderFrameWindow || findQueueSettingWindow）找它，
      // 否則只看訂單 frame 會抓不到 → 下拉空白。
      try {
        const queueWin = findOrderFrameWindow() || findQueueSettingWindow();
        const settingUtil = queueWin?.Mallbic?.U?.Sale?.Ajax?.SettingUtil;
        if (settingUtil?.GetAllQueueReason) {
          out.queues = toQueueList(await readAllQueueReasons(settingUtil));
        }
      } catch { /* ignore */ }

      return out;
    },

    // 設定頁用：從「庫存管理 > 儲位管理」主檔抓全部儲位名稱，回傳 '-' 前的區域代碼清單。
    // 參數值取自 ERP 自己的 StockLocationTab 預設（warehouse 0=全部、area 0、排序欄 2、順序 1）。
    async getStockAreaCodes() {
      const findGoodWindow = () => {
        try { if (window.Mallbic?.U?.Sale?.Ajax?.GoodUtil?.InitStockLocations) return window; } catch { /* ignore */ }
        for (const f of document.querySelectorAll("iframe")) {
          try { if (f.contentWindow?.Mallbic?.U?.Sale?.Ajax?.GoodUtil?.InitStockLocations) return f.contentWindow; } catch { /* ignore */ }
        }
        return null;
      };
      const w = findGoodWindow();
      if (!w) return { ok: false, message: "USale 儲位管理 API 不可用。" };
      const gu = w.Mallbic.U.Sale.Ajax.GoodUtil;

      try {
        const first = await new Promise((resolve) => {
          gu.InitStockLocations(50, "", 0, 0, 2, 1, resolve);
        });
        if (first?.error) {
          return { ok: false, message: first.error.Message || "讀取儲位主檔失敗。" };
        }
        const v = first.value || {};
        const cacheId = v.CacheID;
        let rows = normalizeRows(v.ListData);
        // 只抓 ERP 回報的真實頁數（TotalPageNumber）；多抓不存在的頁會等很久
        const pages = Number(v.TotalPageNumber || 1);

        const getPage = (p) => new Promise((resolve) => {
          gu.GetStockLocationsAt(cacheId, p, (ret) => {
            resolve(ret?.error ? [] : normalizeRows(ret?.value?.ListData ?? ret?.value));
          });
        });
        const rest = await Promise.all(Array.from({ length: Math.max(pages - 1, 0) }, (_, i) => getPage(i + 1)));
        rest.forEach((rs) => { rows = rows.concat(rs); });

        const prefixes = new Set();
        rows.forEach((r) => {
          const token = String(r?.LocationName || "").trim().toUpperCase().split("-")[0];
          if (token) prefixes.add(token);
        });
        return { ok: true, locations: rows.length, prefixes: Array.from(prefixes).sort() };
      } catch (error) {
        return { ok: false, message: error?.message || "讀取儲位主檔失敗。" };
      }
    },












    // ③分類：把某層分到的訂單顯示在 ERP 主畫面（只畫面、不動資料）
    async showT3Layer(payload = {}) {
      const layerId = String(payload?.layerId || "");
      if (!lastT3 || !lastT3.layerRows || !Array.isArray(lastT3.layerRows[layerId])) return { ok: false, message: "沒有可顯示的訂單，請先按「重新分類」。" };
      const rows = lastT3.layerRows[layerId];
      const pageWindow = findOrderFrameWindow();
      if (!pageWindow) return { ok: false, message: "目前不在 USale 訂單頁。" };
      const currentTab = pageWindow.m_TabMgnt?.getCurrentTab?.();
      if (!currentTab?.m_order_view_option || typeof currentTab.setTableData !== "function") return { ok: false, message: "USale 主畫面 API 不可用。" };
      await ensureNewOrderTab(pageWindow);
      const pageCache = Object.assign({}, lastT3.template || {}, { TotalCount: rows.length, TotalPageNumber: 1, MaxPageNumber: 1, CurrentPgNo: 0, ListData: rows });
      currentTab.m_order_view_option.CurrentPgNo = 0;
      currentTab.setTableData(pageCache);
      try { relabelMainTable(pageWindow, `${lastT3.names?.[layerId] || "該層"} (${rows.length})`); } catch (e) { /* ignore */ }
      return { ok: true, count: rows.length };
    },

    // 版本握手：popup 用來確認此分頁跑的引擎夠新
    async ping() {
      return { ok: true, version: HELPER_VERSION };
    },
  };

  // ERP 原生「置入/移出暫存區」掛鉤：使用者在 ERP 手動搬移成功後，
  // 發 queue-changed 通知側欄即時刷新暫存(N)（我們自己的暫存動作走同一條 API 也會觸發，無妨）
  function armQueueChangeNotify() {
    const hookTxnUtil = (txnUtil) => {
      if (!txnUtil || txnUtil.__orderClassifyQueueNotify) return;
      ["MoveToOrderQueue", "MoveOutOrderQueue"].forEach((name) => {
        const orig = txnUtil[name];
        if (typeof orig !== "function") return;
        txnUtil[name] = function (...args) {
          const cbIndex = args.findIndex((a) => typeof a === "function");
          if (cbIndex >= 0) {
            const cb = args[cbIndex];
            args[cbIndex] = function (ret) {
              try { if (!ret?.error) emitProgress("queue-changed", name, ""); } catch { /* ignore */ }
              return cb.apply(this, arguments);
            };
          }
          return orig.apply(this, args);
        };
      });
      txnUtil.__orderClassifyQueueNotify = true;
    };
    try {
      // 每個 frame 有自己的 TxnUtil（不同 JS 世界），全部都掛，不挑頁
      [window, ...Array.from(window.frames)].forEach((f) => {
        try { hookTxnUtil(f.Mallbic?.U?.Sale?.Ajax?.TxnUtil); } catch { /* ignore */ }
      });
    } catch { /* ignore */ }
  }
  // ERP 模組是動態載入/可能重載的：每 5 秒巡一次，把還沒掛鉤的補上（冪等、零查詢）
  window.setInterval(armQueueChangeNotify, 5000);
  armQueueChangeNotify();

  // ── 「訂單排序」工具列按鈕（注入到 ERP 訂單頁工具列，置入暫存區後面）──
  // 依「每張單最小的儲位代碼」自然排序（1…9、A…Z，數字在前）重畫目前檢視；跨區單取最小儲位當代表。
  // 只改畫面順序、不動任何訂單，同時建立儲位順序快取(ocStockRank)供「出貨列印」攔截重排使用。
  // 出貨流程：先按此鈕排序 → 勾選訂單 → 出貨列印(貨/條)，出貨單/條碼單即照儲位順序印出。
  // 「訂單排序」當下建立的儲位順序快取：Map(各種訂單 id → 該單最小儲位 token)，供「出貨列印」攔截重排使用。
  let ocStockRank = null;
  // 排序後的全域結果與分批狀態：{ rows:已排序全部, raw:頁面範本, size:每批筆數(100), batch:目前批次 }
  // ERP 一頁塞超過 100 筆列印會爆圖，故排序後仍以「每批 100 筆」呈現，使用者一批一批印。
  let ocSorted = null;
  let ocMySortQuerying = false; // 為 true 時代表是「排單順序」自己在查訂單，不觸發分批面板自動關閉

  // 關閉分批面板並清除排序狀態（手動 ✕ 或切換檢視時呼叫）
  function ocCloseBatchPanel() {
    ocSorted = null;
    try {
      const docs = [];
      const walk = (win) => { try { docs.push(win.document); for (let i = 0; i < win.frames.length; i += 1) { try { walk(win.frames[i]); } catch { /* ignore */ } } } catch { /* ignore */ } };
      walk(window);
      for (const doc of docs) { const p = doc.getElementById("oc-batch-panel"); if (p) p.style.display = "none"; }
    } catch { /* ignore */ }
  }

  // 排序後自動按下 ERP 訂單格線表頭「全選」(#chk_select_all)，讓使用者不必手動勾選就能直接出貨列印。
  // 全選會讓 getSelTxnKeys() 依畫面(已排序)順序回傳全部，出貨列印即照儲位順序。
  function ocSelectAllRows(w) {
    try {
      const cands = Array.from(w.document.querySelectorAll("#chk_select_all, input.chk_all_msg"));
      const box = cands.find((c) => c.getBoundingClientRect().width > 0) || cands[0];
      if (!box) return false;
      if (!box.checked) box.click();  // ERP 表頭全選會勾選當前畫面(已排序)所有列
      return !!box.checked;
    } catch { return false; }
  }

  // 在 ERP 訂單頁角落顯示一則短暫提示（成功/失敗都看得到，不再靜默）
  // 螢幕正中央提示，顯示 ms 毫秒(預設 3 秒)後淡出
  function ocToast(msg, isError, ms) {
    try {
      const w = findOrderFrameWindow() || window;
      const doc = w.document;
      let box = doc.getElementById("oc-toast");
      if (!box) { box = doc.createElement("div"); box.id = "oc-toast"; doc.body.appendChild(box); }
      box.textContent = msg;
      box.style.cssText = "position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:2147483647;padding:18px 32px;border-radius:14px;font-size:19px;font-weight:700;color:#fff;box-shadow:0 10px 40px rgba(0,0,0,.35);text-align:center;pointer-events:none;transition:opacity .6s ease;background:" + (isError ? "#d70015" : "#0071e3") + ";";
      box.style.display = "block";
      // 強制 reflow 後再設 opacity=1，確保淡入/淡出動畫生效
      void box.offsetWidth;
      box.style.opacity = "1";
      if (box.__t) w.clearTimeout(box.__t);
      if (box.__t2) w.clearTimeout(box.__t2);
      const dur = ms || (isError ? 5000 : 3000);
      box.__t = w.setTimeout(() => { box.style.opacity = "0"; }, dur);                       // 顯示 dur 後開始淡出
      box.__t2 = w.setTimeout(() => { try { box.style.display = "none"; } catch { /* ignore */ } }, dur + 700); // 淡出結束再隱藏
    } catch { /* ignore */ }
  }

  async function sortDisplayByStock() {
    try {
      const w = findOrderFrameWindow();
      if (!w) { ocToast("找不到訂單頁框架", true); return; }
      const orderUtil = w.Mallbic?.U?.Sale?.Ajax?.OrderUtil;
      const currentTab = w.m_TabMgnt?.getCurrentTab?.();
      if (!orderUtil?.GetOrderListByViewOption || !currentTab?.m_order_view_option || typeof currentTab.setTableData !== "function") { ocToast("此檢視不支援排序", true); return; }
      ocToast("排序中…");
      const opt = JSON.parse(JSON.stringify(currentTab.m_order_view_option));
      opt.CurrentPgNo = 0;
      ocMySortQuerying = true;                 // 標記：接下來的訂單查詢是我自己排序用的，別誤觸自動關閉
      let all;
      try { all = await queryRows(orderUtil, opt, {}); } finally { ocMySortQuerying = false; }
      if (!all.raw) { ocToast("讀取訂單失敗", true); return; }
      const rows = normalizeRows(all.rows);
      if (!rows.length) { ocToast("目前沒有訂單可排序", true); return; }
      const keys = rows.map((r, i) => String(buildRowKey(r, i)));
      const stockMap = await queryTxnStockAreaList(orderUtil, rows.map((r) => r?.TxnKey).filter(Boolean));
      const orders = new Map();
      rows.forEach((row, i) => {
        const txn = getTxnNumber(row) || keys[i];
        if (!orders.has(txn)) orders.set(txn, { rows: [], min: null, seq: orders.size });
        const o = orders.get(txn);
        o.rows.push(row);
        stockAreaTokens(stockMap, keys[i]).forEach((tk) => { if (o.min === null || naturalCompare(tk, o.min) < 0) o.min = tk; });
      });
      // 建立「儲位順序」快取供列印攔截用：把每張單的各種 id（交易序號/TxnNum/TxnKeyStr）都指向該單最小儲位 token
      ocStockRank = new Map();
      rows.forEach((row, i) => {
        const o = orders.get(getTxnNumber(row) || keys[i]);
        const tok = o ? o.min : null;
        if (tok == null) return;
        [getTxnNumber(row), row?.TxnNum, row?.TxnKey?.TxnNum, keys[i]].forEach((id) => { if (id != null && String(id)) ocStockRank.set(String(id), tok); });
      });
      const sorted = Array.from(orders.values())
        .sort((a, b) => {
          if (a.min === null && b.min === null) return a.seq - b.seq;
          if (a.min === null) return 1;
          if (b.min === null) return -1;
          return naturalCompare(a.min, b.min) || a.seq - b.seq;
        })
        .flatMap((o) => o.rows);
      // 存全域排序結果，並以每批 100 筆呈現（超過 100 筆一頁列印會爆圖）
      ocSorted = { rows: sorted, raw: all.raw, size: 100, batch: 0 };
      ocRenderBatch(0);
    } catch (err) { ocToast("排序失敗：" + (err && err.message ? err.message : err), true); }
  }

  // 顯示第 n 批（每批 ocSorted.size 筆）：塞成一頁、自動全選、更新分批面板與提示
  function ocRenderBatch(n) {
    try {
      const s = ocSorted; if (!s || !s.rows) return;
      const size = s.size || 100;
      const total = s.rows.length;
      const batches = Math.max(1, Math.ceil(total / size));
      n = Math.max(0, Math.min(n, batches - 1));
      s.batch = n;
      const w = findOrderFrameWindow(); if (!w) return;
      const tab = w.m_TabMgnt?.getCurrentTab?.(); if (!tab) return;
      const slice = s.rows.slice(n * size, n * size + size);
      const pageCache = Object.assign({}, s.raw, { TotalCount: slice.length, TotalPageNumber: 1, MaxPageNumber: 1, CurrentPgNo: 0, ListData: slice });
      tab.m_order_view_option.CurrentPgNo = 0;
      tab.setTableData(pageCache);
      relabelMainTable(w, `依儲位排序(${total}筆/第${n + 1}批)`);
      const allSel = ocSelectAllRows(w);
      ocRenderBatchPanel(w, n, batches, total, size);
      const from = n * size + 1, to = n * size + slice.length;
      if (batches > 1) ocToast(`第 ${n + 1}/${batches} 批（${from}–${to} 筆）已排序並全選 ✔ 印完點「下一批」`);
      else ocToast(allSel ? "已依儲位排序並自動全選 ✔ 可直接出貨列印" : "已依儲位排序 ✔ 請勾選訂單後再出貨列印");
    } catch { /* ignore */ }
  }

  // 分批導覽小面板（只有超過 1 批時顯示）：◀ 上一批 ｜ 第 x/y 批 ｜ 下一批 ▶
  function ocRenderBatchPanel(w, batchIdx, batches, total, size) {
    try {
      const doc = w.document;
      let panel = doc.getElementById("oc-batch-panel");
      if (batches <= 1) { if (panel) panel.style.display = "none"; return; }
      if (!panel) {
        panel = doc.createElement("div");
        panel.id = "oc-batch-panel";
        // 小尺寸、置於螢幕底部置中（避開 ERP 上方導覽列，不被遮擋）
        panel.style.cssText = "position:fixed;bottom:14px;left:50%;transform:translateX(-50%);z-index:2147483646;display:flex;align-items:center;gap:6px;background:#0071e3;color:#fff;padding:4px 6px;border-radius:8px;box-shadow:0 3px 12px rgba(0,0,0,.28);font-size:12px;font-weight:600;white-space:nowrap;";
        const mk = (txt) => { const b = doc.createElement("button"); b.textContent = txt; b.style.cssText = "all:unset;cursor:pointer;padding:3px 8px;border-radius:5px;background:rgba(255,255,255,.22);color:#fff;font-weight:700;font-size:12px;"; return b; };
        const prev = mk("◀ 上一批"), label = doc.createElement("span"), next = mk("下一批 ▶"), close = mk("✕");
        label.id = "oc-batch-label";
        label.style.cssText = "padding:0 4px;";
        close.title = "關閉分批";
        close.style.background = "rgba(255,255,255,.12)";
        prev.onclick = (e) => { e.stopPropagation(); if (ocSorted && ocSorted.batch > 0) ocRenderBatch(ocSorted.batch - 1); };
        next.onclick = (e) => { e.stopPropagation(); if (ocSorted) ocRenderBatch(ocSorted.batch + 1); };
        close.onclick = (e) => { e.stopPropagation(); ocCloseBatchPanel(); };
        panel.appendChild(prev); panel.appendChild(label); panel.appendChild(next); panel.appendChild(close);
        doc.body.appendChild(panel);
        panel.__prev = prev; panel.__next = next; panel.__label = label;
      }
      panel.style.display = "flex";
      const from = batchIdx * size + 1, to = Math.min(total, (batchIdx + 1) * size);
      panel.__label.textContent = `第 ${batchIdx + 1}/${batches} 批 · ${from}–${to}/${total}`;
      panel.__prev.style.opacity = batchIdx <= 0 ? "0.4" : "1";
      panel.__prev.style.pointerEvents = batchIdx <= 0 ? "none" : "auto";
      panel.__next.style.opacity = batchIdx >= batches - 1 ? "0.4" : "1";
      panel.__next.style.pointerEvents = batchIdx >= batches - 1 ? "none" : "auto";
    } catch { /* ignore */ }
  }

  // ── 出貨列印順序修正 ───────────────────────────────────────────────
  // ERP「出貨列印」會向伺服器重抓資料（GetPrintTxnInfo/GetPrintDetail）並照建立時間排列，
  // 完全忽略畫面排序與勾選順序。這裡攔截這兩個 AjaxPro 方法：把「請求的 aKeyList」與
  // 「回應的清單」都依『訂單排序』當下快取的儲位順序(ocStockRank)重排，讓出貨單/條碼單照儲位印出。
  // 需先按過「訂單排序」建立快取；沒快取則不動作（維持 ERP 原順序）。
  function ocRankToken(id) { try { return ocStockRank ? ocStockRank.get(String(id)) : undefined; } catch { return undefined; } }
  function ocItemTxn(it) {
    if (!it || typeof it !== "object") return "";
    return String(it.TxnNum ?? it.TxnNumber ?? it.TxnKey?.TxnNum ?? it.TxnKeyStr ?? it.Key?.TxnNum ?? "");
  }
  // 依儲位 token 穩定排序（無 token 者維持原相對順序、排到最後）
  function ocSortByToken(arr, getId) {
    const idx = new Map(arr.map((x, i) => [x, i]));
    arr.sort((a, b) => {
      const ta = ocRankToken(getId(a)), tb = ocRankToken(getId(b));
      if (ta == null && tb == null) return idx.get(a) - idx.get(b);
      if (ta == null) return 1;
      if (tb == null) return -1;
      return naturalCompare(ta, tb) || (idx.get(a) - idx.get(b));
    });
  }
  function ocReorderKeyList(arg) {
    try { if (arg && Array.isArray(arg.aKeyList) && arg.aKeyList.length > 1) ocSortByToken(arg.aKeyList, (k) => k?.TxnNum ?? k?.TxnNumber); } catch { /* ignore */ }
  }
  function ocReorderPrintResult(name, res) {
    try {
      let list = null;
      const cand = (res && typeof res === "object") ? (res.value !== undefined ? res.value : res) : null;
      if (Array.isArray(cand)) list = cand;
      else if (cand && typeof cand === "object") { for (const k of Object.keys(cand)) { if (Array.isArray(cand[k]) && cand[k].length && typeof cand[k][0] === "object") { list = cand[k]; break; } } }
      // 診斷：記下結構（欄位名、能否對到 TxnNum、快取大小）——供首次列印回報，不含個資
      try {
        const it0 = list && list[0];
        const diag = { name, rankSize: ocStockRank ? ocStockRank.size : 0, listLen: list ? list.length : 0, itemKeys: it0 ? Object.keys(it0).slice(0, 60) : null, txnSample: it0 ? ocItemTxn(it0) : "", tokenHit: it0 ? (ocRankToken(ocItemTxn(it0)) ?? null) : null };
        window.top.localStorage.setItem("__ocReorderDiag", JSON.stringify(diag));
      } catch { /* ignore */ }
      if (!ocStockRank || !ocStockRank.size || !list || list.length < 2) return;
      ocSortByToken(list, ocItemTxn);
    } catch { /* ignore */ }
  }
  // 在所有同源框架的 OrderUtil 掛上攔截（冪等；框架動態載入故定時補掛）
  function armPrintReorder() {
    try {
      const wins = [];
      const walk = (w) => { try { wins.push(w); for (let i = 0; i < w.frames.length; i += 1) { try { walk(w.frames[i]); } catch { /* ignore */ } } } catch { /* ignore */ } };
      walk(window);
      for (const w of wins) {
        let OU; try { OU = w.Mallbic?.U?.Sale?.Ajax?.OrderUtil; } catch { continue; }
        if (!OU) continue;
        ["GetPrintTxnInfo", "GetPrintDetail"].forEach((nm) => {
          const orig = OU[nm];
          if (typeof orig !== "function" || orig.__ocReorder) return;
          OU[nm] = function () {
            const args = Array.from(arguments);
            try { ocReorderKeyList(args[0]); } catch { /* ignore */ }
            const ci = args.findIndex((a) => typeof a === "function");
            if (ci >= 0) { const cb = args[ci]; args[ci] = function (res) { try { ocReorderPrintResult(nm, res); } catch { /* ignore */ } return cb.apply(this, arguments); }; }
            return orig.apply(this, args);
          };
          OU[nm].__ocReorder = true;
        });
        // 攔 GetOrderListByViewOption：若「不是排單順序自己在查」卻重查了訂單清單＝使用者換了檢視/暫存區 → 自動收掉分批面板
        const glv = OU.GetOrderListByViewOption;
        if (typeof glv === "function" && !glv.__ocNavWatch) {
          OU.GetOrderListByViewOption = function () {
            try { if (ocSorted && !ocMySortQuerying) ocCloseBatchPanel(); } catch { /* ignore */ }
            return glv.apply(this, arguments);
          };
          OU.GetOrderListByViewOption.__ocNavWatch = true;
        }
      }
    } catch { /* ignore */ }
  }

  function ocCloseSortMenus(doc) { try { doc.querySelectorAll(".oc-sort-menu").forEach((m) => { m.style.display = "none"; }); } catch { /* ignore */ } }

  // 每個 document 共用一個下拉選單（掛在 body、fixed 定位，避免被工具列/表格容器裁切；共用避免重複建造）
  function ocGetSortMenu(doc) {
    if (doc.__ocSortMenuEl && doc.body && doc.body.contains(doc.__ocSortMenuEl)) return doc.__ocSortMenuEl;
    const menu = doc.createElement("div");
    menu.className = "oc-sort-menu";
    menu.style.cssText = "position:fixed;z-index:2147483647;background:#fff;border:1px solid #ccc;box-shadow:0 4px 16px rgba(0,0,0,.25);border-radius:6px;min-width:180px;display:none;padding:4px 0;text-align:left;";
    const addItem = (label, onClick) => {
      const it = doc.createElement("div");
      it.textContent = label;
      it.style.cssText = "padding:8px 14px;cursor:pointer;white-space:nowrap;font-size:13px;color:#333;";
      it.onmouseenter = () => { it.style.background = "#eef4ff"; };
      it.onmouseleave = () => { it.style.background = ""; };
      it.onclick = (e) => { e.stopPropagation(); menu.style.display = "none"; onClick(); };
      menu.appendChild(it);
    };
    addItem("按儲存區排序(1-Z)", sortDisplayByStock);
    doc.body.appendChild(menu);
    doc.__ocSortMenuEl = menu;
    return menu;
  }

  // 建立「排單順序」按鈕（自訂 class，不套 ERP 的 tool_btn，避免 ERP 工具列腳本重排它）
  function ocCreateSortButton(doc) {
    const li = doc.createElement("li");
    li.className = "oc-sort-btn";
    li.textContent = "排單順序";
    li.style.cssText = "position:relative;display:inline-block;vertical-align:top;margin:0 4px;padding:5px 12px;border-radius:6px;background:#0071e3;color:#fff;font-weight:600;font-size:13px;line-height:18px;cursor:pointer;list-style:none;";
    li.onclick = (e) => {
      e.stopPropagation();
      const menu = ocGetSortMenu(doc);
      const willOpen = menu.style.display === "none";
      ocCloseSortMenus(doc);
      if (!willOpen) return;
      const r = li.getBoundingClientRect();
      menu.style.top = Math.round(r.bottom + 2) + "px";
      menu.style.left = Math.round(r.left) + "px";
      menu.style.display = "block";
    };
    return li;
  }

  // 把按鈕釘在工具列「最後一個位置」(置底)。已在最後就不動（避免 MutationObserver 觸發自己造成迴圈）。
  function ocPinSortButton(ul) {
    const doc = ul.ownerDocument;
    if (!ul.querySelector("li.op_into_queue")) return;   // 只掛在有「置入暫存區」的工具列
    let li = ul.querySelector("li.oc-sort-btn");
    if (!li) li = ocCreateSortButton(doc);
    if (li !== ul.lastElementChild) ul.appendChild(li);  // 固定置底
    // 掛一次 MutationObserver：ERP 一改動工具列就「立刻」把按鈕拉回最後（免等輪詢、不亂跑）
    if (!ul.__ocObserved) {
      ul.__ocObserved = true;
      try {
        const MO = (doc.defaultView && doc.defaultView.MutationObserver) || MutationObserver;
        new MO(() => {
          if (!ul.querySelector("li.op_into_queue")) return;
          let b = ul.querySelector("li.oc-sort-btn");
          if (!b) b = ocCreateSortButton(doc);
          if (b !== ul.lastElementChild) ul.appendChild(b);
        }).observe(ul, { childList: true });
      } catch { /* ignore */ }
    }
  }

  // 掃描所有同源框架、把每個有「置入暫存區」的 main-tbox 都掛上按鈕（各檢視/暫存區工具列各自獨立）
  function injectOrderSortButton() {
    try {
      const docs = [];
      const walk = (win) => { try { docs.push(win.document); for (let i = 0; i < win.frames.length; i += 1) { try { walk(win.frames[i]); } catch { /* ignore */ } } } catch { /* ignore */ } };
      walk(window);
      for (const doc of docs) {
        Array.from(doc.querySelectorAll("ul.main-tbox")).forEach((ul) => { try { ocPinSortButton(ul); } catch { /* ignore */ } });
        if (!doc.__ocSortClose) { doc.addEventListener("click", () => ocCloseSortMenus(doc)); doc.__ocSortClose = true; }
      }
    } catch { /* ignore */ }
  }
  // 首次快速多跑幾次讓按鈕盡快出現；之後每秒巡一次補上新載入的工具列（位置由各 ul 的 observer 即時維持）
  [0, 200, 500, 1000].forEach((t) => window.setTimeout(injectOrderSortButton, t));
  window.setInterval(injectOrderSortButton, 1000);
  // 出貨列印攔截：把列印資料流依儲位順序重排（每 3 秒補掛新載入的框架，冪等）
  window.setInterval(armPrintReorder, 3000);
  armPrintReorder();

  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.type !== REQUEST_TYPE || !data.requestId) return;

    const action = actions[data.action];
    if (!action) {
      window.postMessage({
        type: RESPONSE_TYPE,
        requestId: data.requestId,
        ok: false,
        message: `Unknown action: ${data.action}`
      }, "*");
      return;
    }

    try {
      const result = await action(data.payload || {});
      window.postMessage({
        type: RESPONSE_TYPE,
        requestId: data.requestId,
        ok: true,
        result
      }, "*");
    } catch (error) {
      window.postMessage({
        type: RESPONSE_TYPE,
        requestId: data.requestId,
        ok: false,
        message: error?.message || "USale page helper action failed."
      }, "*");
    }
  });
})();
